"""Integration tests for end-to-end pipeline over real research papers."""

import pytest
from src.pipeline import RAGPipeline
import config


class TestPipelineIntegration:
    @pytest.fixture(scope="class")
    def pipeline(self):
        p = RAGPipeline()
        if not p.is_indexed():
            p.ingest(force_rebuild=False)
        return p

    def test_pipeline_is_indexed(self, pipeline):
        assert pipeline.is_indexed() is True
        status = pipeline.get_status()
        assert status["indexed_chunks"] > 0
        assert status["manifest_exists"] is True

    def test_query_retrieval_transformer_encoder(self, pipeline):
        q = "What are the two sub-layers in each encoder layer of the Transformer model?"
        res = pipeline.query(question=q, top_k=3, use_reranker=False)

        assert len(res.citations) >= 1
        top_paper = res.citations[0].paper_title
        assert "Attention Is All You Need" in top_paper

        # Check page number is accurate (Vaswani et al. Section 3.1 is on page 3)
        assert res.citations[0].page_number in [2, 3, 4]

    def test_query_retrieval_rag_components(self, pipeline):
        q = "What are the main components of a RAG model, and how do they interact?"
        res = pipeline.query(question=q, top_k=3, use_reranker=False)

        assert len(res.citations) >= 1
        retrieved_titles = [c.paper_title for c in res.citations]
        assert any("Retrieval-Augmented Generation" in t for t in retrieved_titles)
