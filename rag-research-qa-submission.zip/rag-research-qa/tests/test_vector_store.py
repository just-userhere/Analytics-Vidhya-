"""Unit tests for vector store, similarity search, and persistence consistency."""

import pytest
import numpy as np
from pathlib import Path
from src.vector_store import VectorStore
from src.chunking import Chunk


def create_dummy_chunk(chunk_id: str, text: str, page: int = 1) -> Chunk:
    return Chunk(
        chunk_id=chunk_id,
        paper_id="paper_1",
        paper_title="Paper One",
        authors="Author A",
        filename="paper_1.pdf",
        page_number=page,
        chunk_index=0,
        text=text,
        section_heading="Section 1",
        char_count=len(text),
        word_count=len(text.split()),
        content_hash="hash123"
    )


class TestVectorStore:
    def test_add_and_search_vectors(self):
        store = VectorStore(dimension=4)
        c1 = create_dummy_chunk("c1", "Transformer encoder layer", page=1)
        c2 = create_dummy_chunk("c2", "Dense passage retrieval", page=2)

        # Normalized 4-dimensional vectors
        v1 = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32)
        v2 = np.array([0.0, 1.0, 0.0, 0.0], dtype=np.float32)
        embeddings = np.stack([v1, v2])

        store.add_chunks([c1, c2], embeddings)
        assert store.size() == 2

        # Search with vector closest to v1
        q_vec = np.array([0.9, 0.1, 0.0, 0.0], dtype=np.float32)
        q_vec = q_vec / np.linalg.norm(q_vec)
        results = store.search(q_vec, top_k=2)

        assert len(results) == 2
        top_meta, top_score = results[0]
        assert top_meta["chunk_id"] == "c1"
        assert top_score > 0.8

    def test_save_and_load_persistence(self, tmp_path):
        store = VectorStore(dimension=4)
        c1 = create_dummy_chunk("c1", "Attention mechanism")
        v1 = np.array([[0.5, 0.5, 0.5, 0.5]], dtype=np.float32)
        v1 = v1 / np.linalg.norm(v1)
        store.add_chunks([c1], v1)

        idx_file = tmp_path / "index.bin"
        meta_file = tmp_path / "metadata.json"
        store.save(idx_file, meta_file)

        new_store = VectorStore(dimension=4)
        new_store.load(idx_file, meta_file)
        assert new_store.size() == 1
        assert new_store.chunks_metadata[0]["chunk_id"] == "c1"

    def test_consistency_check_raises_error(self, tmp_path):
        """Validates that VectorStore strictly rejects mismatched index and metadata."""
        store = VectorStore(dimension=4)
        c1 = create_dummy_chunk("c1", "Text 1")
        c2 = create_dummy_chunk("c2", "Text 2")
        vecs = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], dtype=np.float32)
        store.add_chunks([c1, c2], vecs)

        idx_file = tmp_path / "index.bin"
        meta_file = tmp_path / "metadata.json"
        store.save(idx_file, meta_file)

        # Corrupt metadata file by deleting one chunk
        import json
        with open(meta_file, "r") as f:
            data = json.load(f)
        data = data[:1]  # Only 1 chunk in metadata, but 2 vectors in index
        with open(meta_file, "w") as f:
            json.dump(data, f)

        new_store = VectorStore(dimension=4)
        with pytest.raises(ValueError, match="consistency violation"):
            new_store.load(idx_file, meta_file)

    def test_search_empty_store(self):
        store = VectorStore(dimension=4)
        q_vec = np.array([1, 0, 0, 0], dtype=np.float32)
        results = store.search(q_vec, top_k=5)
        assert results == []
