"""Unit tests for BM25, hybrid retrieval, RRF, and query expansion."""

import pytest
import numpy as np
from src.retrieval import (
    BM25Retriever,
    HybridRetriever,
    tokenize_for_bm25,
    normalize_and_expand_query
)
from src.vector_store import VectorStore
from src.embeddings import EmbeddingGenerator
from src.chunking import Chunk


def make_chunk(cid: str, text: str, page: int = 1) -> Chunk:
    return Chunk(
        chunk_id=cid,
        paper_id="paper_test",
        paper_title="Test Title",
        authors="Test Author",
        filename="test.pdf",
        page_number=page,
        chunk_index=0,
        text=text,
        section_heading="Section 1",
        char_count=len(text),
        word_count=len(text.split()),
        content_hash=f"hash_{cid}"
    )


class TestBM25Retriever:
    def test_bm25_search_returns_relevant_chunk(self):
        retriever = BM25Retriever()
        chunks = [
            {"chunk_id": "c1", "text": "The transformer architecture uses multi-head self-attention.", "paper_id": "p1", "paper_title": "T1", "filename": "f1.pdf", "page_number": 1},
            {"chunk_id": "c2", "text": "Dense passage retrieval uses dual encoders for open-domain QA.", "paper_id": "p2", "paper_title": "T2", "filename": "f2.pdf", "page_number": 2},
            {"chunk_id": "c3", "text": "Random background text about solar systems and galaxies.", "paper_id": "p3", "paper_title": "T3", "filename": "f3.pdf", "page_number": 3},
        ]
        retriever.fit(chunks)
        results = retriever.search("multi-head self-attention", top_k=2)

        assert len(results) >= 1
        top_meta, score = results[0]
        assert top_meta["chunk_id"] == "c1"
        assert score > 0

    def test_empty_query(self):
        retriever = BM25Retriever()
        retriever.fit([{"chunk_id": "c1", "text": "Sample text", "paper_id": "p1", "paper_title": "T1", "filename": "f1.pdf", "page_number": 1}])
        assert retriever.search("", top_k=5) == []


class TestQueryExpansion:
    def test_rag_expansion(self):
        expanded = normalize_and_expand_query("How does RAG work?")
        assert "retrieval-augmented generation" in expanded.lower()

    def test_dpr_expansion(self):
        expanded = normalize_and_expand_query("Explain DPR models")
        assert "dense passage retrieval" in expanded.lower()


class TestHybridRetriever:
    def test_hybrid_retrieval_rrf_combination(self):
        dim = 384
        store = VectorStore(dimension=dim)
        embed_gen = EmbeddingGenerator(dimension=dim)
        bm25 = BM25Retriever()

        c1 = make_chunk("c1", "Positional encoding allows model to use sequence order")
        c2 = make_chunk("c2", "Few-shot learning enables in-context inference")

        embed_gen.fit_fallback([c1.text, c2.text])
        vecs = embed_gen.embed_texts([c1.text, c2.text])

        store.add_chunks([c1, c2], vecs)
        bm25.fit([c1.to_dict(), c2.to_dict()])

        hybrid = HybridRetriever(
            vector_store=store,
            embedding_generator=embed_gen,
            bm25_retriever=bm25,
            rrf_k=60
        )

        passages = hybrid.retrieve("positional encoding sequence", top_k=2, use_reranker=False)
        assert len(passages) >= 1
        assert passages[0].chunk_id == "c1"
        assert passages[0].page_number == 1
        assert passages[0].rrf_score > 0
