"""Unit tests for citation attribution and verification."""

import pytest
from src.citations import CitationManager, Citation
from src.retrieval import RetrievedPassage


def make_passage(idx: int, title: str, page: int, text: str) -> RetrievedPassage:
    return RetrievedPassage(
        chunk_id=f"chunk_{idx}",
        paper_id="paper_id",
        paper_title=title,
        authors="Author et al.",
        filename=f"{title.lower().replace(' ', '_')}.pdf",
        page_number=page,
        chunk_index=idx,
        section_heading="Section 1",
        text=text,
        final_score=0.95
    )


class TestCitationManager:
    def test_build_citations_preserves_page_and_title(self):
        p1 = make_passage(1, "Attention Is All You Need", 3, "The encoder is composed of a stack of 6 identical layers.")
        citations = CitationManager.build_citations([p1])

        assert len(citations) == 1
        c = citations[0]
        assert c.citation_id == 1
        assert c.paper_title == "Attention Is All You Need"
        assert c.page_number == 3
        assert "stack of 6 identical layers" in c.excerpt

    def test_extract_cited_indices(self):
        text = "The Transformer uses self-attention [1] and feed-forward networks [2]. Other works [3, 4] confirm this."
        indices = CitationManager.extract_cited_indices(text)
        assert indices == [1, 2, 3, 4]

    def test_verify_citations_grounding(self):
        p1 = make_passage(1, "Paper 1", 2, "Evidence text 1")
        p2 = make_passage(2, "Paper 2", 5, "Evidence text 2")
        citations = CitationManager.build_citations([p1, p2])

        answer_grounded = "According to [1], we observe evidence."
        verification = CitationManager.verify_citations(answer_grounded, citations)
        assert verification["is_fully_grounded"] is True
        assert verification["all_cited_indices"] == [1]

        answer_ungrounded = "According to [99], something else happened."
        bad_verification = CitationManager.verify_citations(answer_ungrounded, citations)
        assert bad_verification["is_fully_grounded"] is False
        assert 99 in bad_verification["unsupported_citations"]
