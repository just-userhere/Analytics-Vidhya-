"""Automated tests verifying technical concept coverage in retrieved evidence for the 5 sample questions."""

import pytest
from src.pipeline import RAGPipeline
import config


@pytest.fixture(scope="module")
def pipeline():
    p = RAGPipeline()
    assert p.is_indexed(), "Pipeline should be indexed with research papers"
    return p


class TestConceptCoverage:
    def test_q1_rag_components_coverage(self, pipeline):
        q = "What are the main components of a RAG model, and how do they interact?"
        res = pipeline.query(q, top_k=6, use_reranker=True)
        evidence = res.evidence_block.lower()

        # Target paper check
        assert any("Retrieval-Augmented Generation" in c.paper_title for c in res.citations)

        # Core components check
        assert "retriever" in evidence
        assert "generator" in evidence
        assert ("dpr" in evidence) or ("dense passage retrieval" in evidence)
        assert "bart" in evidence
        assert ("marginalize" in evidence) or ("parametric" in evidence)

    def test_q2_transformer_sublayers_coverage(self, pipeline):
        q = "What are the two sub-layers in each encoder layer of the Transformer model?"
        res = pipeline.query(q, top_k=6, use_reranker=True)
        evidence = res.evidence_block.lower()

        assert any("Attention Is All You Need" in c.paper_title for c in res.citations)
        assert "multi-head" in evidence or "self-attention" in evidence
        assert "feed-forward" in evidence or "feed forward" in evidence
        assert "residual" in evidence
        assert "layer normalization" in evidence

    def test_q3_positional_encoding_coverage(self, pipeline):
        q = "Explain how positional encoding is implemented in Transformers and why it is necessary."
        res = pipeline.query(q, top_k=6, use_reranker=True)
        evidence = res.evidence_block.lower()

        assert any("Attention Is All You Need" in c.paper_title for c in res.citations)
        assert "sinusoid" in evidence or "sine" in evidence or "cosine" in evidence
        assert "frequencies" in evidence
        assert "recurrence" in evidence or "convolution" in evidence

    def test_q4_multihead_attention_coverage(self, pipeline):
        q = "Describe the concept of multi-head attention in the Transformer architecture. Why is it beneficial?"
        res = pipeline.query(q, top_k=6, use_reranker=True)
        evidence = res.evidence_block.lower()

        assert any("Attention Is All You Need" in c.paper_title for c in res.citations)
        assert "queries" in evidence
        assert "keys" in evidence
        assert "values" in evidence
        assert ("linear projections" in evidence) or ("jointly attend" in evidence) or ("subspaces" in evidence)

    def test_q5_gpt3_few_shot_coverage(self, pipeline):
        q = "What is few-shot learning, and how does GPT-3 implement it during inference?"
        res = pipeline.query(q, top_k=6, use_reranker=True)
        evidence = res.evidence_block.lower()

        assert any("Language Models are Few-Shot Learners" in c.paper_title for c in res.citations)
        assert "demonstrations" in evidence
        assert ("context window" in evidence) or ("context" in evidence)
        assert ("in-context" in evidence) or ("in-context learning" in evidence)
        assert ("gradient updates" in evidence) or ("weight updates" in evidence) or ("fine-tuning" in evidence)
