"""Unit tests for text chunker and metadata preservation."""

import pytest
from src.chunking import TextChunker, Chunk
from src.document_loader import DocumentPage


def create_sample_page(page_num: int = 1, text: str = None) -> DocumentPage:
    if text is None:
        text = (
            "The dominant sequence transduction models are based on complex recurrent or convolutional neural networks. "
            "We propose a new simple network architecture, the Transformer, based solely on attention mechanisms. "
            "Experiments on two machine translation tasks show these models to be superior in quality while being more parallelizable. "
            "Our model establishes a new state of the art on English-to-German and English-to-French translation tasks. "
            "The Transformer allows for significantly more parallelization and can reach a new state of the art in translation quality after being trained for as little as twelve hours."
        )
    return DocumentPage(
        paper_id="attention_is_all_you_need",
        paper_title="Attention Is All You Need",
        authors="Vaswani et al.",
        filename="attention_is_all_you_need.pdf",
        page_number=page_num,
        total_pages=15,
        text=text,
        section_candidates=["1 Introduction"]
    )


class TestTextChunker:
    def test_chunk_page_preserves_metadata(self):
        chunker = TextChunker(chunk_size=300, chunk_overlap=50)
        page = create_sample_page(page_num=2)
        chunks = chunker.chunk_page(page)

        assert len(chunks) >= 1
        first_chunk = chunks[0]
        assert first_chunk.paper_id == "attention_is_all_you_need"
        assert first_chunk.paper_title == "Attention Is All You Need"
        assert first_chunk.page_number == 2
        assert first_chunk.filename == "attention_is_all_you_need.pdf"
        assert first_chunk.section_heading == "1 Introduction"
        assert first_chunk.content_hash is not None
        assert len(first_chunk.content_hash) > 0

    def test_chunk_size_and_overlap_parameters(self):
        with pytest.raises(ValueError, match="strictly less than"):
            TextChunker(chunk_size=100, chunk_overlap=150)

    def test_empty_page_handling(self):
        chunker = TextChunker()
        empty_page = create_sample_page(text="   ")
        chunks = chunker.chunk_page(empty_page)
        assert len(chunks) == 0

    def test_short_text_below_minimum_length(self):
        chunker = TextChunker(min_chunk_length=80)
        short_page = create_sample_page(text="Too short.")
        chunks = chunker.chunk_page(short_page)
        assert len(chunks) == 0

    def test_deduplication(self):
        chunker = TextChunker()
        p1 = create_sample_page(page_num=1)
        p2 = create_sample_page(page_num=2)  # Identical text
        chunks = chunker.chunk_documents([p1, p2], deduplicate=True)
        # Should deduplicate identical content
        single_page_chunks = chunker.chunk_page(p1)
        assert len(chunks) == len(single_page_chunks)
