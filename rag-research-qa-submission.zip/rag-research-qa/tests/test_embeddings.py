"""Unit tests for embedding generator and vector dimensionality."""

import numpy as np
import pytest
from src.embeddings import EmbeddingGenerator


class TestEmbeddingGenerator:
    def test_embedding_dimensions_and_normalization(self):
        generator = EmbeddingGenerator(dimension=384)
        texts = [
            "Attention Is All You Need introduces the Transformer.",
            "Retrieval-Augmented Generation models combine parametric and non-parametric memory."
        ]
        embeddings = generator.embed_texts(texts)

        assert isinstance(embeddings, np.ndarray)
        assert embeddings.shape == (2, 384)
        assert embeddings.dtype == np.float32

        # Check L2 normalization (norm should be ~1.0)
        norms = np.linalg.norm(embeddings, axis=1)
        for n in norms:
            assert np.isclose(n, 1.0, atol=1e-3)

    def test_query_embedding_shape(self):
        generator = EmbeddingGenerator(dimension=384)
        vec = generator.embed_query("What is multi-head attention?")
        assert isinstance(vec, np.ndarray)
        assert vec.shape == (384,)
        norm = np.linalg.norm(vec)
        assert np.isclose(norm, 1.0, atol=1e-3)

    def test_empty_texts_input(self):
        generator = EmbeddingGenerator(dimension=384)
        embeddings = generator.embed_texts([])
        assert embeddings.shape == (0, 384)
