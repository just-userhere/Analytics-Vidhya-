"""Unit and integration tests for document loader and text extraction."""

import pytest
from pathlib import Path

from src.document_loader import (
    DocumentLoader,
    DocumentPage,
    normalize_whitespace,
    extract_section_candidates
)
import config


class TestWhitespaceNormalization:
    def test_normalize_basic_whitespace(self):
        text = "Hello    world \t from \n\n\n\n python!  "
        cleaned = normalize_whitespace(text)
        assert "    " not in cleaned
        assert cleaned == "Hello world from\n\npython!"

    def test_hyphen_word_reconstruction(self):
        text = "trans-\nformer architecture"
        cleaned = normalize_whitespace(text)
        assert "transformer architecture" in cleaned

    def test_empty_string(self):
        assert normalize_whitespace("") == ""
        assert normalize_whitespace("   \n\t  ") == ""


class TestSectionExtraction:
    def test_extract_numbered_heading(self):
        text = "1 Introduction\nThis is introductory text.\n3.2 Multi-Head Attention\nDetails here."
        candidates = extract_section_candidates(text)
        assert any("1 Introduction" in c for c in candidates)
        assert any("3.2 Multi-Head Attention" in c for c in candidates)

    def test_extract_abstract(self):
        text = "Abstract\nWe propose a new model."
        candidates = extract_section_candidates(text)
        assert any("Abstract" in c for c in candidates)


class TestDocumentLoader:
    def test_load_valid_paper(self):
        loader = DocumentLoader(paper_registry=config.RESEARCH_PAPERS)
        pdf_path = config.PAPERS_DIR / "attention_is_all_you_need.pdf"
        assert pdf_path.exists(), "PDF should exist in data/papers/"

        pages = loader.load_pdf(pdf_path)
        assert len(pages) == 15
        assert pages[0].page_number == 1
        assert pages[0].paper_title == "Attention Is All You Need"
        assert pages[0].filename == "attention_is_all_you_need.pdf"
        assert len(pages[0].text) > 100

    def test_load_nonexistent_file(self):
        loader = DocumentLoader()
        with pytest.raises(FileNotFoundError):
            loader.load_pdf("nonexistent_paper.pdf")

    def test_load_invalid_file_extension(self, tmp_path):
        loader = DocumentLoader()
        txt_file = tmp_path / "test.txt"
        txt_file.write_text("not a pdf")
        with pytest.raises(ValueError, match="Invalid PDF"):
            loader.load_pdf(txt_file)

    def test_load_empty_file(self, tmp_path):
        loader = DocumentLoader()
        empty_pdf = tmp_path / "empty.pdf"
        empty_pdf.touch()
        with pytest.raises(ValueError, match="empty"):
            loader.load_pdf(empty_pdf)
