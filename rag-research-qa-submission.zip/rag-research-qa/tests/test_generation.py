"""Unit tests for answer generation with mocked LLM and edge cases."""

import pytest
from src.generation import AnswerGenerator
from src.retrieval import RetrievedPassage


class MockLLMClient:
    def __init__(self, response_text: str):
        self.response_text = response_text
        self.last_prompt = None

    def generate(self, prompt: str) -> str:
        self.last_prompt = prompt
        return self.response_text


def make_passage(text: str, page: int = 1) -> RetrievedPassage:
    return RetrievedPassage(
        chunk_id="chunk_test",
        paper_id="attention",
        paper_title="Attention Is All You Need",
        authors="Vaswani et al.",
        filename="attention_is_all_you_need.pdf",
        page_number=page,
        chunk_index=0,
        section_heading="3.1 Encoder",
        text=text,
        final_score=0.9
    )


class TestAnswerGenerator:
    def test_mock_llm_generation(self):
        mock_text = "The encoder contains two sub-layers: multi-head self-attention and a feed-forward network [1]."
        mock_client = MockLLMClient(mock_text)
        generator = AnswerGenerator(llm_client=mock_client)

        p = make_passage("Each layer has two sub-layers: multi-head self-attention and feed-forward.")
        res = generator.generate("What are the two sub-layers in each encoder layer?", [p])

        assert res.is_live_llm is True
        assert res.answer == mock_text
        assert 1 in res.cited_indices
        assert res.is_fully_grounded is True
        assert "EVIDENCE BLOCK [1]" in mock_client.last_prompt

    def test_insufficient_evidence_when_no_passages(self):
        generator = AnswerGenerator()
        res = generator.generate("Unknown question?", [])

        assert "do not contain sufficient evidence" in res.answer
        assert len(res.citations) == 0
        assert res.is_fully_grounded is True

    def test_unconfigured_api_key_graceful_mode(self):
        # Generator without API key and without mock client
        generator = AnswerGenerator(api_key="")
        p = make_passage("Positional encodings have the same dimension d_model as the embeddings.")
        res = generator.generate("Explain positional encoding.", [p])

        assert res.is_live_llm is False
        assert "GEMINI_API_KEY is not configured" in res.answer
        assert len(res.citations) == 1
        assert res.citations[0].page_number == 1
