"""Streamlit Web Application: Research Paper RAG Assistant."""

import sys
import os
import time
from pathlib import Path
import streamlit as st

# Ensure project root is in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

# Ensure UTF-8 output on Windows
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

import config
from src.pipeline import RAGPipeline
from src.citations import CitationManager

# Configure Streamlit page
st.set_page_config(
    page_title="Research Paper RAG Assistant",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for polished, professional academic interface
st.markdown("""
<style>
    .main-header {
        font-size: 2.3rem;
        font-weight: 700;
        color: #1E3A8A;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #4B5563;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 8px;
        padding: 12px 16px;
        margin-bottom: 8px;
    }
    .citation-card {
        background-color: #F0FDF4;
        border-left: 4px solid #16A34A;
        padding: 12px 16px;
        border-radius: 4px;
        margin-top: 8px;
        margin-bottom: 12px;
    }
    .evidence-box {
        background-color: #F1F5F9;
        border-radius: 6px;
        padding: 10px 14px;
        font-family: monospace;
        font-size: 0.85rem;
    }
    .sample-q-btn {
        text-align: left;
        margin-bottom: 6px;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_resource(show_spinner="Initializing RAG Pipeline and loading indexes...")
def get_pipeline():
    """Initializes and caches the RAG pipeline."""
    p = RAGPipeline()
    if not p.is_indexed():
        p.ingest(force_rebuild=False)
    return p


def main():
    pipeline = get_pipeline()
    status = pipeline.get_status()

    # --- SIDEBAR ---
    with st.sidebar:
        st.title("⚙️ System Control")

        st.subheader("🔑 Gemini LLM Settings")
        env_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY") or ""
        api_key_input = st.text_input(
            "Gemini API Key",
            value=env_key,
            type="password",
            help="Enter your Google Gemini API key to enable live LLM generation. If left blank, system runs in verified evidence mode."
        )

        model_options = ["gemini-2.5-flash", "gemini-1.5-flash", "gemini-1.5-pro", "gemini-2.0-flash"]
        selected_model = st.selectbox("Gemini Model", options=model_options, index=0)

        st.divider()

        st.subheader("🔍 Retrieval Configuration")
        top_k = st.slider("Top Passages (Top-K)", min_value=1, max_value=10, value=config.DEFAULT_TOP_K)
        use_reranker = st.toggle("Enable Cross-Encoder Reranker", value=False, help="Reranks top candidate passages if neural cross-encoder model is present.")

        st.divider()

        st.subheader("📊 Collection Status")
        st.markdown(f"**Indexed Chunks:** `{status['indexed_chunks']}`")
        st.markdown(f"**Embedding Model:** `{status['embedding_model']}`")
        st.markdown(f"**Vector Store:** `{'FAISS' if status['is_faiss_active'] else 'NumPy Flat Cosine'}`")
        st.markdown(f"**LLM Generation:** `{'Active (API Key detected)' if (api_key_input and len(api_key_input) > 5) else 'Evidence Mode (No Key)'}`")

        with st.expander("📚 Registered Research Papers", expanded=False):
            for pid, pmeta in config.RESEARCH_PAPERS.items():
                st.markdown(f"• **{pmeta['title']}**\n  *({pmeta['short_authors']}, {pmeta['year']})* — `{pmeta['filename']}`")

        st.divider()

        if st.button("🔄 Rebuild Knowledge Base", help="Forces complete re-parsing, chunking, and indexing of all PDFs."):
            with st.spinner("Rebuilding knowledge base..."):
                start_t = time.time()
                manifest = pipeline.ingest(force_rebuild=True)
                st.cache_resource.clear()
                st.success(f"Rebuilt index with {manifest['total_chunks']} chunks in {manifest['ingestion_duration_seconds']}s!")
                st.rerun()

    # --- MAIN CONTENT AREA ---
    st.markdown('<div class="main-header">📚 Research Paper RAG Assistant</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-header">Retrieval-Augmented Question Answering grounded in peer-reviewed AI research literature with verifiable source attribution.</div>',
        unsafe_allow_html=True
    )

    # Information Alert
    if not (api_key_input and len(api_key_input) > 5):
        st.info(
            "💡 **Running in Grounded Evidence Mode**: A Gemini API key was not detected. "
            "The system will execute full hybrid retrieval (BM25 + Semantic + RRF), extract exact page numbers, "
            "and verify citations directly from the authentic papers. To enable live LLM answer synthesis, enter your `GEMINI_API_KEY` in the sidebar."
        )

    # Sample Questions Section
    st.markdown("##### 💡 Suggested Research Questions:")
    sample_col1, sample_col2 = st.columns(2)

    sample_questions = [
        "What are the main components of a RAG model, and how do they interact?",
        "What are the two sub-layers in each encoder layer of the Transformer model?",
        "Explain how positional encoding is implemented in Transformers and why it is necessary.",
        "Describe the concept of multi-head attention in the Transformer architecture. Why is it beneficial?",
        "What is few-shot learning, and how does GPT-3 implement it during inference?"
    ]

    # Session state for query input
    if "user_question" not in st.session_state:
        st.session_state.user_question = ""

    with sample_col1:
        if st.button("1️⃣ " + sample_questions[0], key="btn_q1", use_container_width=True):
            st.session_state.user_question = sample_questions[0]
        if st.button("2️⃣ " + sample_questions[1], key="btn_q2", use_container_width=True):
            st.session_state.user_question = sample_questions[1]
        if st.button("3️⃣ " + sample_questions[2], key="btn_q3", use_container_width=True):
            st.session_state.user_question = sample_questions[2]

    with sample_col2:
        if st.button("4️⃣ " + sample_questions[3], key="btn_q4", use_container_width=True):
            st.session_state.user_question = sample_questions[3]
        if st.button("5️⃣ " + sample_questions[4], key="btn_q5", use_container_width=True):
            st.session_state.user_question = sample_questions[4]
        if st.button("🧹 Clear Chat / Reset", key="btn_clear", use_container_width=True):
            st.session_state.user_question = ""
            if "last_result" in st.session_state:
                del st.session_state["last_result"]
            st.rerun()

    # Query Input Box
    query_text = st.text_input(
        "Ask a technical question about the indexed papers:",
        value=st.session_state.user_question,
        placeholder="e.g., What are the two sub-layers in each encoder layer of the Transformer model?",
        key="input_query"
    )

    ask_button = st.button("🚀 Ask Question", type="primary", use_container_width=False)

    if ask_button and query_text.strip():
        with st.spinner("Retrieving evidence across research papers and generating grounded response..."):
            start_time = time.time()
            effective_key = api_key_input.strip() if (api_key_input and len(api_key_input.strip()) > 5) else None

            result = pipeline.query(
                question=query_text.strip(),
                top_k=top_k,
                use_reranker=use_reranker,
                api_key=effective_key,
                model_name=selected_model
            )
            elapsed_time = round(time.time() - start_time, 2)
            st.session_state.last_result = result
            st.session_state.elapsed_time = elapsed_time

    # Render Results if available in session state
    if "last_result" in st.session_state:
        res = st.session_state.last_result
        elapsed = st.session_state.get("elapsed_time", 0.0)

        st.markdown("---")
        st.markdown(f"### 📝 Answer ({elapsed}s)")

        # Render generated answer in clean markdown card
        st.markdown(res.answer)

        # Source Attribution Section
        st.markdown("### 📌 Verified Source Citations")
        if res.citations:
            for c in res.citations:
                sec_text = f" | Section: **{c.section_heading}**" if c.section_heading else ""
                with st.expander(
                    f"[{c.citation_id}] {c.paper_title} ({c.authors}) — PDF Page {c.page_number} (Score: {c.relevance_score:.4f})",
                    expanded=(c.citation_id == 1)
                ):
                    st.markdown(f"**Source Document:** `{c.filename}` | **PDF Page:** `{c.page_number}`{sec_text}")
                    st.markdown("**Exact Supporting Excerpt:**")
                    st.markdown(f"> *\"{c.excerpt}\"*")
        else:
            st.warning("No citations available for this query.")

        # Diagnostics Tab
        with st.expander("🛠️ Retrieval Diagnostics & Evidence Inspector", expanded=False):
            st.markdown(f"**Model Engine:** `{res.model_name}` | **Live LLM:** `{res.is_live_llm}`")
            st.markdown(f"**Inline Citations Extracted:** `{res.cited_indices}`")
            st.markdown(f"**Grounded Verification Status:** `{'PASSED' if res.is_fully_grounded else 'UNGROUNDED CLAIMS DETECTED'}`")
            st.markdown("**Raw Formatted Evidence Block sent to LLM:**")
            st.text_area("Evidence Context", value=res.evidence_block, height=220, disabled=True)


if __name__ == "__main__":
    main()
