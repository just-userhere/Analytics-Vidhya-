"""CLI script to ingest research papers and rebuild knowledge base indexes."""

import sys
import os
import argparse
import logging
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# Ensure UTF-8 output on Windows terminal
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

import config
from src.pipeline import RAGPipeline

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("ingest_documents")


def main():
    parser = argparse.ArgumentParser(description="Ingest research paper PDFs into vector and BM25 indexes.")
    parser.add_argument("--papers-dir", type=str, default=str(config.PAPERS_DIR), help="Path to research papers PDF directory.")
    parser.add_argument("--rebuild", action="store_true", help="Force rebuild existing indexes.")
    parser.add_argument("--chunk-size", type=int, default=config.CHUNK_SIZE, help="Characters per chunk.")
    parser.add_argument("--chunk-overlap", type=int, default=config.CHUNK_OVERLAP, help="Characters overlap between chunks.")
    args = parser.parse_args()

    print("=" * 70)
    print("RESEARCH PAPER RAG ASSISTANT - INGESTION PIPELINE")
    print("=" * 70)
    print(f"Source Directory: {args.papers_dir}")
    print(f"Chunk Size:       {args.chunk_size} chars")
    print(f"Chunk Overlap:    {args.chunk_overlap} chars")
    print(f"Force Rebuild:    {args.rebuild}")
    print("-" * 70)

    papers_path = Path(args.papers_dir)
    if not papers_path.exists():
        print(f"Error: Directory not found: {papers_path}")
        sys.exit(1)

    pdf_files = list(papers_path.glob("*.pdf"))
    print(f"Found {len(pdf_files)} PDF files in {papers_path}:")
    for pdf in pdf_files:
        print(f"  • {pdf.name} ({pdf.stat().st_size:,} bytes)")

    if not pdf_files:
        print("Error: No PDF files found to ingest.")
        sys.exit(1)

    print("-" * 70)
    print("Processing documents and building indexes...")

    pipeline = RAGPipeline(
        chunk_size=args.chunk_size,
        chunk_overlap=args.chunk_overlap
    )

    manifest = pipeline.ingest(papers_dir=args.papers_dir, force_rebuild=args.rebuild)

    print("=" * 70)
    print("INGESTION COMPLETED SUCCESSFULLY!")
    print("=" * 70)
    print(f"Total Pages Extracted: {manifest['total_pages']}")
    print(f"Total Chunks Created:  {manifest['total_chunks']}")
    print(f"Time Taken:            {manifest['ingestion_duration_seconds']}s")
    print("Papers Breakdown:")
    for title, count in manifest["papers_indexed"].items():
        print(f"  • {title}: {count} pages")
    print(f"Index Files Saved:")
    print(f"  • FAISS Vector Index: {config.INDEX_FILE}")
    print(f"  • Chunk Metadata:     {config.METADATA_FILE}")
    print(f"  • BM25 Index:         {config.BM25_FILE}")
    print(f"  • Index Manifest:     {config.MANIFEST_FILE}")
    print("=" * 70)


if __name__ == "__main__":
    main()
