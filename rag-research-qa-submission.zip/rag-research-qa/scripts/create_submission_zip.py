"""Script to create the final submission zip package."""

import os
import zipfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
WORKSPACE_ROOT = PROJECT_ROOT.parent
ZIP_OUT = WORKSPACE_ROOT / "rag-research-qa-submission.zip"

EXCLUDE_PATTERNS = [
    ".git",
    ".pytest_cache",
    "__pycache__",
    ".env",
    ".env.local",
    "venv",
    ".venv",
    ".DS_Store",
    "Thumbs.db",
    "*.pyc",
    "*.log"
]

def should_exclude(rel_path: str) -> bool:
    parts = rel_path.replace("\\", "/").split("/")
    for p in parts:
        if p in [".pytest_cache", "__pycache__", ".git", "venv", ".venv"]:
            return True
        if p.startswith(".env") and not p.endswith(".example"):
            return True
        if p.endswith(".pyc") or p.endswith(".log"):
            return True
    return False

print(f"Creating submission package at: {ZIP_OUT}")

with zipfile.ZipFile(ZIP_OUT, "w", zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(PROJECT_ROOT):
        for f in files:
            full_path = Path(root) / f
            rel_path = full_path.relative_to(PROJECT_ROOT)
            rel_str = str(rel_path)

            if should_exclude(rel_str):
                continue

            arcname = f"rag-research-qa/{rel_str.replace('\\', '/')}"
            zipf.write(full_path, arcname=arcname)
            print(f"  Added: {arcname} ({full_path.stat().st_size:,} bytes)")

print(f"\nFinal zip package created successfully: {ZIP_OUT} ({ZIP_OUT.stat().st_size:,} bytes)")
