import urllib.request
import os
import sys

papers = [
    {
        "id": "attention_is_all_you_need",
        "title": "Attention Is All You Need",
        "authors": "Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin",
        "year": 2017,
        "url": "https://arxiv.org/pdf/1706.03762.pdf",
        "filename": "attention_is_all_you_need.pdf"
    },
    {
        "id": "language_models_few_shot_learners",
        "title": "Language Models are Few-Shot Learners",
        "authors": "Tom B. Brown, Benjamin Mann, Nick Ryder, Melanie Subbiah, Jared Kaplan, Prafulla Dhariwal, et al.",
        "year": 2020,
        "url": "https://arxiv.org/pdf/2005.14165.pdf",
        "filename": "language_models_few_shot_learners.pdf"
    },
    {
        "id": "retrieval_augmented_generation",
        "title": "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks",
        "authors": "Patrick Lewis, Ethan Perez, Aleksandara Piktus, Fabio Petroni, Vladimir Karpukhin, Naman Goyal, et al.",
        "year": 2020,
        "url": "https://arxiv.org/pdf/2005.11401.pdf",
        "filename": "retrieval_augmented_generation.pdf"
    },
    {
        "id": "dense_passage_retrieval",
        "title": "Dense Passage Retrieval for Open-Domain Question Answering",
        "authors": "Vladimir Karpukhin, Barlas Oguz, Sewon Min, Patrick Lewis, Ledell Wu, Sergey Edunov, Danqi Chen, Wen-tau Yih",
        "year": 2020,
        "url": "https://arxiv.org/pdf/2004.04906.pdf",
        "filename": "dense_passage_retrieval.pdf"
    }
]

dest_dir = os.path.join(os.path.dirname(__file__), "..", "data", "papers")
os.makedirs(dest_dir, exist_ok=True)

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}

for paper in papers:
    dest_path = os.path.join(dest_dir, paper["filename"])
    if os.path.exists(dest_path) and os.path.getsize(dest_path) > 100000:
        print(f"Already exists: {paper['filename']} ({os.path.getsize(dest_path)} bytes)")
        continue
    print(f"Downloading {paper['title']} from {paper['url']}...")
    req = urllib.request.Request(paper["url"], headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as response, open(dest_path, "wb") as out_file:
            data = response.read()
            out_file.write(data)
        print(f"Saved {paper['filename']} ({len(data)} bytes)")
    except Exception as e:
        print(f"Error downloading {paper['filename']}: {e}")
