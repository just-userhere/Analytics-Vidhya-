import json
import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('data/processed/chunks_metadata.json', 'r', encoding='utf-8') as f:
    chunks = json.load(f)

print(f"Total indexed chunks: {len(chunks)}")

def search_chunks(paper_id, keywords):
    print(f"\n=== Searching {paper_id} for {keywords} ===")
    matches = []
    for c in chunks:
        if c['paper_id'] == paper_id:
            text_low = c['text'].lower()
            matched = [k for k in keywords if k.lower() in text_low]
            if len(matched) >= 2:
                matches.append((len(matched), c, matched))
    matches.sort(key=lambda x: x[0], reverse=True)
    for count, c, matched in matches[:5]:
        print(f"[{count}/{len(keywords)} matches: {matched}] Page {c['page_number']} (Sec: {c['section_heading']})")
        print(f"  Excerpt: {c['text'][:180]}...\n")

search_chunks("attention_is_all_you_need", ["multi-head", "attention", "subspaces", "linear projections", "queries", "keys", "values", "scaled dot-product"])
search_chunks("attention_is_all_you_need", ["positional encoding", "sinusoid", "sine", "cosine", "frequencies", "order of sequence", "recurrence", "convolution"])
search_chunks("language_models_few_shot_learners", ["few-shot", "demonstrations", "context window", "prompt", "in-context learning", "gradient updates", "weight updates"])
search_chunks("retrieval_augmented_generation", ["retriever", "generator", "DPR", "BART", "parametric", "non-parametric", "marginalize"])
