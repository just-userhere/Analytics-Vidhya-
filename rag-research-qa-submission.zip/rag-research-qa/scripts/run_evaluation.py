"""Evaluation script to test the 5 mandatory research questions against the indexed papers."""

import sys
import os
import json
import logging
from pathlib import Path
from typing import Dict, List, Any

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

import config
from src.pipeline import RAGPipeline
from src.citations import CitationManager

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("evaluation")

MANDATORY_QUESTIONS = [
    {
        "id": "q1",
        "question": "What are the main components of a RAG model, and how do they interact?",
        "target_paper": "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks",
        "expected_concepts": ["retriever", "generator", "DPR", "BART", "parametric", "non-parametric", "marginalize"]
    },
    {
        "id": "q2",
        "question": "What are the two sub-layers in each encoder layer of the Transformer model?",
        "target_paper": "Attention Is All You Need",
        "expected_concepts": ["multi-head self-attention", "feed-forward", "residual", "layer normalization", "sub-layers"]
    },
    {
        "id": "q3",
        "question": "Explain how positional encoding is implemented in Transformers and why it is necessary.",
        "target_paper": "Attention Is All You Need",
        "expected_concepts": ["sinusoid", "sine", "cosine", "frequencies", "order of the sequence", "recurrence", "convolution"]
    },
    {
        "id": "q4",
        "question": "Describe the concept of multi-head attention in the Transformer architecture. Why is it beneficial?",
        "target_paper": "Attention Is All You Need",
        "expected_concepts": ["jointly attend", "representation subspaces", "linear projections", "queries", "keys", "values", "scaled dot-product"]
    },
    {
        "id": "q5",
        "question": "What is few-shot learning, and how does GPT-3 implement it during inference?",
        "target_paper": "Language Models are Few-Shot Learners",
        "expected_concepts": ["demonstrations", "context window", "prompt", "in-context learning", "gradient updates", "weight updates"]
    }
]


def run_evaluation(pipeline: RAGPipeline) -> Dict[str, Any]:
    """Runs all 5 mandatory questions, validates retrieval grounding, and records outputs."""
    results = []
    print("=" * 80)
    print("RUNNING MANDATORY 5-QUESTION EVALUATION OVER ACTUAL INDEXED RESEARCH PAPERS")
    print("=" * 80)

    for item in MANDATORY_QUESTIONS:
        qid = item["id"]
        q_text = item["question"]
        expected_paper = item["target_paper"]
        expected_concepts = item["expected_concepts"]

        print(f"\nEvaluating Question {qid.upper()}:")
        print(f"  Q: {q_text}")
        print(f"  Expected Target Paper: {expected_paper}")

        # Execute query through hybrid retrieval pipeline
        res = pipeline.query(question=q_text, top_k=config.DEFAULT_TOP_K)

        # Inspect retrieved passages
        retrieved_papers = [c.paper_title for c in res.citations]
        paper_match = any(expected_paper.lower() in p.lower() for p in retrieved_papers)

        # Check concept recall in retrieved evidence
        evidence_text = res.evidence_block.lower()
        matched_concepts = [c for c in expected_concepts if c.lower() in evidence_text]
        concept_recall = len(matched_concepts) / len(expected_concepts)

        top_citation = res.citations[0] if res.citations else None
        top_page = top_citation.page_number if top_citation else None
        top_paper = top_citation.paper_title if top_citation else None

        print(f"  Top Match: [{top_paper}] - PDF Page {top_page}")
        print(f"  Target Paper Retrieved in Top-5: {'YES' if paper_match else 'NO'}")
        print(f"  Concept Recall in Evidence: {len(matched_concepts)}/{len(expected_concepts)} ({concept_recall*100:.1f}%)")
        print(f"  Concepts Found: {matched_concepts}")

        # Verification record
        record = {
            "id": qid,
            "question": q_text,
            "target_paper": expected_paper,
            "target_paper_retrieved": paper_match,
            "top_citation": {
                "paper_title": top_paper,
                "authors": top_citation.authors if top_citation else "",
                "pdf_page": top_page,
                "excerpt": top_citation.excerpt if top_citation else "",
                "relevance_score": top_citation.relevance_score if top_citation else 0.0
            } if top_citation else None,
            "all_citations": [c.to_dict() for c in res.citations],
            "expected_concepts": expected_concepts,
            "matched_concepts": matched_concepts,
            "concept_recall_pct": round(concept_recall * 100, 1),
            "generated_answer": res.answer,
            "is_live_llm": res.is_live_llm,
            "model_name": res.model_name
        }
        results.append(record)

    total_questions = len(results)
    target_hits = sum(1 for r in results if r["target_paper_retrieved"])
    avg_recall = sum(r["concept_recall_pct"] for r in results) / total_questions

    summary = {
        "total_questions": total_questions,
        "target_paper_retrieval_accuracy": f"{target_hits}/{total_questions} ({target_hits/total_questions*100:.1f}%)",
        "average_concept_recall": f"{avg_recall:.1f}%",
        "results": results
    }

    # Save JSON report
    report_json_path = config.REPORTS_DIR / "evaluation_results.json"
    with open(report_json_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print("\n" + "=" * 80)
    print("EVALUATION SUMMARY")
    print("=" * 80)
    print(f"Target Paper Retrieval Accuracy: {summary['target_paper_retrieval_accuracy']}")
    print(f"Average Technical Concept Recall: {summary['average_concept_recall']}")
    print(f"Evaluation report saved to: {report_json_path}")
    print("=" * 80)

    return summary


if __name__ == "__main__":
    p = RAGPipeline()
    if not p.is_indexed():
        print("Indexes not found. Ingesting first...")
        p.ingest(force_rebuild=False)
    run_evaluation(p)
