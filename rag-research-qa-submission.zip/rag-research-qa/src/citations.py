"""Source attribution and citation formatting engine."""

import re
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional, Any

from src.retrieval import RetrievedPassage


@dataclass
class Citation:
    """Verifiable citation linking generated claims to exact research paper sources."""
    citation_id: int          # 1-based reference index [1], [2], etc.
    paper_id: str
    paper_title: str
    authors: str
    filename: str
    page_number: int          # 1-based PDF page number
    section_heading: Optional[str]
    excerpt: str              # Verifiable excerpt from the paper
    relevance_score: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def formatted_badge(self) -> str:
        """Returns readable markdown badge string."""
        sec_info = f", Section: {self.section_heading}" if self.section_heading else ""
        return f"[{self.citation_id}] **{self.paper_title}** ({self.authors}) — PDF Page {self.page_number}{sec_info}"


class CitationManager:
    """Manages formatting, mapping, and verification of citations."""

    @staticmethod
    def build_citations(passages: List[RetrievedPassage]) -> List[Citation]:
        """Creates an ordered list of verified citations from retrieved passages."""
        citations: List[Citation] = []
        for idx, passage in enumerate(passages, start=1):
            # Extract a concise, meaningful excerpt (around 250-350 chars)
            clean_text = passage.text.strip().replace("\n", " ")
            if len(clean_text) > 350:
                # Truncate at sentence or word boundary
                truncated = clean_text[:350].rsplit(" ", 1)[0] + "..."
            else:
                truncated = clean_text

            citations.append(Citation(
                citation_id=idx,
                paper_id=passage.paper_id,
                paper_title=passage.paper_title,
                authors=passage.authors,
                filename=passage.filename,
                page_number=passage.page_number,
                section_heading=passage.section_heading,
                excerpt=truncated,
                relevance_score=passage.final_score
            ))
        return citations

    @staticmethod
    def format_evidence_block(passages: List[RetrievedPassage]) -> str:
        """Formats retrieved passages into a structured evidence prompt for the LLM."""
        if not passages:
            return "No relevant passages found."

        evidence_lines = []
        for idx, p in enumerate(passages, start=1):
            heading = f" | Section: {p.section_heading}" if p.section_heading else ""
            header = f"--- EVIDENCE BLOCK [{idx}] ---"
            meta = f"Paper: \"{p.paper_title}\" | Authors: {p.authors} | File: {p.filename} | PDF Page: {p.page_number}{heading}"
            body = p.text.strip()
            evidence_lines.append(f"{header}\n{meta}\nContent:\n{body}\n")

        return "\n".join(evidence_lines)

    @staticmethod
    def extract_cited_indices(answer_text: str) -> List[int]:
        """Extracts all citation numbers used in answer (e.g. [1], [2], [1, 3])."""
        # Matches patterns like [1], [2], [1, 2], [1-3]
        matches = re.findall(r'\[([0-9,\s\-]+)\]', answer_text)
        indices = set()
        for m in matches:
            parts = m.split(',')
            for p in parts:
                p = p.strip()
                if '-' in p:
                    subparts = p.split('-')
                    if len(subparts) == 2 and subparts[0].isdigit() and subparts[1].isdigit():
                        start, end = int(subparts[0]), int(subparts[1])
                        for i in range(start, end + 1):
                            indices.add(i)
                elif p.isdigit():
                    indices.add(int(p))
        return sorted(list(indices))

    @staticmethod
    def verify_citations(answer_text: str, available_citations: List[Citation]) -> Dict[str, Any]:
        """Verifies that all citations referenced in the text actually exist in the retrieved set."""
        cited_indices = CitationManager.extract_cited_indices(answer_text)
        valid_indices = {c.citation_id for c in available_citations}

        grounded_citations = [c for c in available_citations if c.citation_id in cited_indices]
        ungrounded_indices = [i for i in cited_indices if i not in valid_indices]

        return {
            "all_cited_indices": cited_indices,
            "valid_citations_count": len(grounded_citations),
            "unsupported_citations": ungrounded_indices,
            "is_fully_grounded": len(ungrounded_indices) == 0 and len(cited_indices) > 0,
            "grounded_citations": [c.to_dict() for c in grounded_citations]
        }
