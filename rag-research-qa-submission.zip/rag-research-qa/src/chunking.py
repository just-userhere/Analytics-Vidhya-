"""Text chunking module with metadata preservation, semantic sentence splitting, and overlap."""

import re
import hashlib
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional, Any

from src.document_loader import DocumentPage


@dataclass
class Chunk:
    """Represents a text chunk with complete provenance metadata."""
    chunk_id: str
    paper_id: str
    paper_title: str
    authors: str
    filename: str
    page_number: int  # 1-based PDF page number
    chunk_index: int  # Sequential index within the page/paper
    text: str
    section_heading: Optional[str]
    char_count: int
    word_count: int
    content_hash: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class TextChunker:
    """Splits DocumentPages into structured, overlapping chunks."""

    def __init__(
        self,
        chunk_size: int = 800,
        chunk_overlap: int = 150,
        min_chunk_length: int = 80
    ):
        if chunk_overlap >= chunk_size:
            raise ValueError(f"chunk_overlap ({chunk_overlap}) must be strictly less than chunk_size ({chunk_size})")

        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.min_chunk_length = min_chunk_length

    def _split_into_sentences(self, text: str) -> List[str]:
        """Splits text into sentences while handling abbreviations and decimals."""
        if not text:
            return []
        # Pattern looks for sentence terminators (. ! ?) followed by whitespace and capital letter
        # while avoiding decimal numbers (e.g. 3.14) or abbreviations (e.g. et al., Fig.)
        sentence_end = re.compile(r'(?<=[.!?])\s+(?=[A-Z0-9"\'\(\[])')
        sentences = sentence_end.split(text)
        return [s.strip() for s in sentences if s.strip()]

    def chunk_page(self, page: DocumentPage) -> List[Chunk]:
        """Chunks a single DocumentPage, preserving metadata and section context."""
        text = page.text.strip()
        if not text or len(text) < self.min_chunk_length:
            return []

        # Find best section heading on this page if available
        current_heading = page.section_candidates[0] if page.section_candidates else None

        sentences = self._split_into_sentences(text)
        if not sentences:
            return []

        chunks: List[Chunk] = []
        current_chunk_sentences: List[str] = []
        current_char_len = 0
        chunk_idx = 0

        for sentence in sentences:
            sentence_len = len(sentence)

            # If adding this sentence exceeds chunk_size and we already have content
            if current_char_len + sentence_len + 1 > self.chunk_size and current_chunk_sentences:
                chunk_text = " ".join(current_chunk_sentences).strip()
                if len(chunk_text) >= self.min_chunk_length:
                    chunk_id = f"{page.paper_id}_p{page.page_number}_c{chunk_idx}"
                    content_hash = hashlib.sha256(chunk_text.encode('utf-8')).hexdigest()[:16]

                    chunks.append(Chunk(
                        chunk_id=chunk_id,
                        paper_id=page.paper_id,
                        paper_title=page.paper_title,
                        authors=page.authors,
                        filename=page.filename,
                        page_number=page.page_number,
                        chunk_index=chunk_idx,
                        text=chunk_text,
                        section_heading=current_heading,
                        char_count=len(chunk_text),
                        word_count=len(chunk_text.split()),
                        content_hash=content_hash
                    ))
                    chunk_idx += 1

                # Calculate overlap: retain the last few sentences whose combined length <= chunk_overlap
                overlap_sentences: List[str] = []
                overlap_len = 0
                for s in reversed(current_chunk_sentences):
                    if overlap_len + len(s) + 1 <= self.chunk_overlap:
                        overlap_sentences.insert(0, s)
                        overlap_len += len(s) + 1
                    else:
                        break

                current_chunk_sentences = overlap_sentences + [sentence]
                current_char_len = sum(len(s) + 1 for s in current_chunk_sentences)
            else:
                current_chunk_sentences.append(sentence)
                current_char_len += sentence_len + 1

        # Final remaining chunk
        if current_chunk_sentences:
            chunk_text = " ".join(current_chunk_sentences).strip()
            if len(chunk_text) >= self.min_chunk_length:
                chunk_id = f"{page.paper_id}_p{page.page_number}_c{chunk_idx}"
                content_hash = hashlib.sha256(chunk_text.encode('utf-8')).hexdigest()[:16]

                chunks.append(Chunk(
                    chunk_id=chunk_id,
                    paper_id=page.paper_id,
                    paper_title=page.paper_title,
                    authors=page.authors,
                    filename=page.filename,
                    page_number=page.page_number,
                    chunk_index=chunk_idx,
                    text=chunk_text,
                    section_heading=current_heading,
                    char_count=len(chunk_text),
                    word_count=len(chunk_text.split()),
                    content_hash=content_hash
                ))

        return chunks

    def chunk_documents(self, pages: List[DocumentPage], deduplicate: bool = True) -> List[Chunk]:
        """Chunks a list of DocumentPages with optional hash deduplication."""
        all_chunks: List[Chunk] = []
        seen_hashes = set()

        for page in pages:
            page_chunks = self.chunk_page(page)
            for c in page_chunks:
                if deduplicate:
                    if c.content_hash in seen_hashes:
                        continue
                    seen_hashes.add(c.content_hash)
                all_chunks.append(c)

        return all_chunks
