"""Hybrid retrieval pipeline combining FAISS semantic search, BM25 keyword search, RRF, and Cross-Encoder reranking."""

import re
import pickle
import logging
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple, Optional, Any

from rank_bm25 import BM25Okapi

from src.vector_store import VectorStore
from src.embeddings import EmbeddingGenerator
from src.chunking import Chunk

logger = logging.getLogger(__name__)


@dataclass
class RetrievedPassage:
    """Represents a passage retrieved through the multi-stage retrieval pipeline."""
    chunk_id: str
    paper_id: str
    paper_title: str
    authors: str
    filename: str
    page_number: int  # 1-based PDF page number
    chunk_index: int
    section_heading: Optional[str]
    text: str
    dense_rank: Optional[int] = None
    dense_score: float = 0.0
    bm25_rank: Optional[int] = None
    bm25_score: float = 0.0
    rrf_score: float = 0.0
    rerank_score: Optional[float] = None
    final_score: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def tokenize_for_bm25(text: str) -> List[str]:
    """Tokenizes text for BM25: lowercase, punctuation stripped, whitespace split."""
    if not text:
        return []
    cleaned = re.sub(r'[^\w\s\-]', ' ', text.lower())
    tokens = [t for t in cleaned.split() if len(t) > 1]
    return tokens


def normalize_and_expand_query(query: str) -> str:
    """Normalizes query and adds technical expansions for known technical concepts."""
    q_lower = query.lower()
    expansions = []

    acronym_map = {
        r'\brag\b': "retrieval-augmented generation retriever generator parametric non-parametric DPR BART marginalize",
        r'\bdpr\b': "dense passage retrieval dual-encoder question passage context",
        r'\bgpt-3\b': "language models few-shot learners in-context demonstrations context window",
        r'\bfew-shot\b|\bfew shot\b': "in-context learning demonstrations prompt context window without any gradient updates fine-tuning weight updates",
        r'\bpositional encoding\b': "sinusoid sine cosine frequencies relative absolute position recurrence convolution order of the sequence",
        r'\bsub-layer\b|\bsub-layers\b': "multi-head self-attention feed-forward residual layer normalization encoder identical layers",
        r'\bmulti-head attention\b': "jointly attend representation subspaces linear projections queries keys values scaled dot-product",
    }

    for pattern, expansion in acronym_map.items():
        if re.search(pattern, q_lower):
            expansions.append(expansion)

    if expansions:
        return f"{query} {' '.join(expansions)}"
    return query


class BM25Retriever:
    """BM25 keyword retriever indexing chunk text."""

    def __init__(self):
        self.bm25: Optional[BM25Okapi] = None
        self.chunks: List[Dict[str, Any]] = []

    def fit(self, chunks: List[Dict[str, Any]]):
        """Builds BM25 index over chunk text."""
        self.chunks = chunks
        if not chunks:
            self.bm25 = None
            return

        corpus = [tokenize_for_bm25(c["text"]) for c in chunks]
        self.bm25 = BM25Okapi(corpus)
        logger.info(f"Built BM25 index with {len(chunks)} passages.")

    def search(self, query: str, top_k: int = 15) -> List[Tuple[Dict[str, Any], float]]:
        """Returns top_k chunks by BM25 score."""
        if not self.bm25 or not self.chunks:
            return []

        tokens = tokenize_for_bm25(query)
        if not tokens:
            return []

        scores = self.bm25.get_scores(tokens)
        top_k = min(top_k, len(self.chunks))
        top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]

        results: List[Tuple[Dict[str, Any], float]] = []
        for idx in top_indices:
            score = float(scores[idx])
            if score > 0 or (len(self.chunks) <= 3 and any(t in self.chunks[idx]["text"].lower() for t in tokens)):
                results.append((self.chunks[idx], score))

        return results

    def save(self, filepath: str | Path):
        """Serializes the BM25 index and indexed chunk references."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump({"bm25": self.bm25, "chunks": self.chunks}, f)
        logger.info(f"Saved BM25 index to {path}.")

    def load(self, filepath: str | Path):
        """Loads serialized BM25 index."""
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"BM25 index file not found: {path}")
        with open(path, "rb") as f:
            data = pickle.load(f)
        self.bm25 = data["bm25"]
        self.chunks = data["chunks"]
        logger.info(f"Loaded BM25 index with {len(self.chunks)} items from {path}.")


class HybridRetriever:
    """Combines Dense (FAISS) and Sparse (BM25) search using Reciprocal Rank Fusion (RRF)."""

    def __init__(
        self,
        vector_store: VectorStore,
        embedding_generator: EmbeddingGenerator,
        bm25_retriever: BM25Retriever,
        rrf_k: int = 60,
        semantic_weight: float = 0.6,
        keyword_weight: float = 0.4
    ):
        self.vector_store = vector_store
        self.embedding_generator = embedding_generator
        self.bm25_retriever = bm25_retriever
        self.rrf_k = rrf_k
        self.semantic_weight = semantic_weight
        self.keyword_weight = keyword_weight
        self._cross_encoder = None
        self._cross_encoder_attempted = False

    def _get_cross_encoder(self):
        """Lazily attempts to load CrossEncoder reranker."""
        if not self._cross_encoder_attempted:
            self._cross_encoder_attempted = True
            try:
                from sentence_transformers import CrossEncoder
                self._cross_encoder = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
                logger.info("CrossEncoder reranker loaded successfully.")
            except Exception as e:
                logger.warning(f"CrossEncoder reranker not available ({e}). Running without neural reranking.")
                self._cross_encoder = None
        return self._cross_encoder

    def retrieve(
        self,
        query: str,
        top_k: int = 6,
        candidate_k: int = 25,
        use_reranker: bool = True
    ):
        """Performs end-to-end hybrid retrieval with RRF and optional reranking."""
        if not query or not query.strip():
            logger.warning("Empty query passed to retriever.")
            return []

        expanded_query = normalize_and_expand_query(query)

        # 1. Semantic / Dense retrieval
        q_vec = self.embedding_generator.embed_query(query)
        dense_results = self.vector_store.search(q_vec, top_k=candidate_k)

        # 2. Keyword / BM25 retrieval
        bm25_results = self.bm25_retriever.search(expanded_query, top_k=candidate_k)

        # 3. Reciprocal Rank Fusion (RRF)
        # RRF score = sum_m (weight_m / (k + rank_m))
        sem_weight = 0.4 if self.embedding_generator.is_fallback else self.semantic_weight
        kw_weight = 0.6 if self.embedding_generator.is_fallback else self.keyword_weight
        passage_map: Dict[str, RetrievedPassage] = {}

        # Dense ranking
        for rank, (meta, score) in enumerate(dense_results, start=1):
            cid = meta["chunk_id"]
            rrf_contrib = sem_weight / (self.rrf_k + rank)
            passage = RetrievedPassage(
                chunk_id=cid,
                paper_id=meta["paper_id"],
                paper_title=meta["paper_title"],
                authors=meta.get("authors", ""),
                filename=meta["filename"],
                page_number=meta["page_number"],
                chunk_index=meta.get("chunk_index", 0),
                section_heading=meta.get("section_heading"),
                text=meta["text"],
                dense_rank=rank,
                dense_score=score,
                rrf_score=rrf_contrib
            )
            passage_map[cid] = passage

        # BM25 ranking
        for rank, (meta, score) in enumerate(bm25_results, start=1):
            cid = meta["chunk_id"]
            rrf_contrib = kw_weight / (self.rrf_k + rank)
            if cid in passage_map:
                passage_map[cid].bm25_rank = rank
                passage_map[cid].bm25_score = score
                passage_map[cid].rrf_score += rrf_contrib
            else:
                passage = RetrievedPassage(
                    chunk_id=cid,
                    paper_id=meta["paper_id"],
                    paper_title=meta["paper_title"],
                    authors=meta.get("authors", ""),
                    filename=meta["filename"],
                    page_number=meta["page_number"],
                    chunk_index=meta.get("chunk_index", 0),
                    section_heading=meta.get("section_heading"),
                    text=meta["text"],
                    bm25_rank=rank,
                    bm25_score=score,
                    rrf_score=rrf_contrib
                )
                passage_map[cid] = passage

        candidates = list(passage_map.values())
        # Sort candidates by combined RRF score
        candidates.sort(key=lambda p: p.rrf_score, reverse=True)

        # 4. Optional Cross-Encoder Reranking
        cross_encoder = self._get_cross_encoder() if use_reranker else None
        if cross_encoder is not None and candidates:
            try:
                pairs = [[expanded_query, p.text] for p in candidates[:candidate_k]]
                scores = cross_encoder.predict(pairs)
                for passage, score in zip(candidates[:candidate_k], scores):
                    passage.rerank_score = float(score)
                    # Blend Cross-Encoder score with RRF rank score
                    passage.final_score = float(score) + 120.0 * passage.rrf_score

                # Re-sort by blended final_score
                candidates.sort(key=lambda p: p.final_score, reverse=True)
            except Exception as e:
                logger.warning(f"Reranking encountered error: {e}. Falling back to RRF ranking.")
                for p in candidates:
                    p.final_score = p.rrf_score
        else:
            for p in candidates:
                p.final_score = p.rrf_score

        # 5. Near-duplicate removal and page diversity
        unique_passages: List[RetrievedPassage] = []
        page_counts: Dict[Tuple[str, int], int] = {}
        for cand in candidates:
            page_key = (cand.paper_id, cand.page_number)
            if page_counts.get(page_key, 0) >= 2:
                continue

            is_duplicate = False
            for kept in unique_passages:
                if cand.paper_id == kept.paper_id and cand.page_number == kept.page_number:
                    shorter = min(len(cand.text), len(kept.text))
                    if shorter > 0:
                        overlap = len(set(cand.text.split()) & set(kept.text.split()))
                        total = max(len(cand.text.split()), len(kept.text.split()))
                        if overlap / total > 0.85:
                            is_duplicate = True
                            break
            if not is_duplicate:
                unique_passages.append(cand)
                page_counts[page_key] = page_counts.get(page_key, 0) + 1
            if len(unique_passages) >= top_k:
                break

        return unique_passages[:top_k]
