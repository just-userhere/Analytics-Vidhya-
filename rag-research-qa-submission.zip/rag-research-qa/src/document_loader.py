"""Document loader module using PyMuPDF for page-by-page extraction and metadata preservation."""

import os
import re
import logging
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Dict, Optional, Any

import pymupdf

logger = logging.getLogger(__name__)


@dataclass
class DocumentPage:
    """Represents text and metadata extracted from a single PDF page."""
    paper_id: str
    paper_title: str
    authors: str
    filename: str
    page_number: int  # 1-based PDF page number
    total_pages: int
    text: str
    section_candidates: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def normalize_whitespace(text: str) -> str:
    """Normalizes whitespace while preserving paragraph breaks and math formulas."""
    if not text:
        return ""
    # Replace non-breaking spaces and exotic space characters
    text = text.replace("\u00a0", " ").replace("\u200b", "")
    # Normalize Windows CRLF to standard LF
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Fix hyphens at end of lines for wrapped words: e.g. "trans-\nformer" -> "transformer"
    text = re.sub(r'(\b\w+)-\n(\w+\b)', r'\1\2', text)
    # Collapse multiple blank lines to a double newline
    text = re.sub(r'\n{3,}', '\n\n', text)
    # Collapse multiple horizontal spaces to a single space
    lines = [re.sub(r'[ \t]+', ' ', line).strip() for line in text.split("\n")]
    return "\n".join(lines).strip()


def extract_section_candidates(text: str) -> List[str]:
    """Identifies probable section headings (e.g. '1 Introduction', '3.2 Attention')."""
    candidates = []
    heading_pattern = re.compile(
        r'^(?:[0-9]+(?:\.[0-9]+)*\s+[A-Z][A-Za-z0-9\s,\-:]{2,60}|(?:Abstract|Introduction|Background|Conclusion|References|Related Work|Architecture))\b',
        re.MULTILINE
    )
    for match in heading_pattern.finditer(text):
        cand = match.group().strip()
        if cand and len(cand) < 80:
            candidates.append(cand)
    return candidates


class DocumentLoader:
    """Loads and validates PDF documents, extracting page-by-page content."""

    def __init__(self, paper_registry: Optional[Dict[str, Dict[str, Any]]] = None):
        self.paper_registry = paper_registry or {}

    def _resolve_paper_metadata(self, filename: str) -> Dict[str, Any]:
        """Resolves paper title and authors from registry, or infers from filename."""
        base_name = Path(filename).stem
        for pid, meta in self.paper_registry.items():
            if meta.get("filename") == filename or pid == base_name:
                return meta

        # Fallback if paper not found in registry
        clean_title = base_name.replace("_", " ").title()
        return {
            "id": base_name,
            "title": clean_title,
            "authors": "Unknown",
            "year": 2020,
            "filename": filename
        }

    def load_pdf(self, pdf_path: str | Path) -> List[DocumentPage]:
        """Loads a single PDF file and extracts pages with metadata."""
        path = Path(pdf_path)
        if not path.exists():
            raise FileNotFoundError(f"PDF file not found: {path}")

        if not path.is_file() or path.suffix.lower() != ".pdf":
            raise ValueError(f"Invalid PDF file path: {path}")

        if path.stat().st_size == 0:
            raise ValueError(f"PDF file is empty (0 bytes): {path}")

        filename = path.name
        meta = self._resolve_paper_metadata(filename)
        pages: List[DocumentPage] = []

        try:
            doc = pymupdf.open(str(path))
        except Exception as e:
            raise RuntimeError(f"Failed to open/parse PDF {filename}: {e}")

        total_pages = len(doc)
        if total_pages == 0:
            doc.close()
            raise ValueError(f"PDF has no pages: {filename}")

        for page_idx in range(total_pages):
            page = doc[page_idx]
            raw_text = page.get_text("text") or ""
            clean_text = normalize_whitespace(raw_text)

            # Detect section candidates on this page
            sections = extract_section_candidates(clean_text)

            page_obj = DocumentPage(
                paper_id=meta["id"],
                paper_title=meta["title"],
                authors=meta.get("short_authors", meta.get("authors", "")),
                filename=filename,
                page_number=page_idx + 1,  # 1-based page number
                total_pages=total_pages,
                text=clean_text,
                section_candidates=sections
            )
            pages.append(page_obj)

        doc.close()
        return pages

    def load_directory(self, dir_path: str | Path) -> List[DocumentPage]:
        """Loads all valid PDF files from a directory."""
        directory = Path(dir_path)
        if not directory.exists() or not directory.is_dir():
            raise FileNotFoundError(f"Papers directory not found: {directory}")

        pdf_files = sorted(list(directory.glob("*.pdf")))
        if not pdf_files:
            raise ValueError(f"No PDF files found in directory: {directory}")

        all_pages: List[DocumentPage] = []
        for pdf_file in pdf_files:
            try:
                pages = self.load_pdf(pdf_file)
                all_pages.extend(pages)
                logger.info(f"Loaded {len(pages)} pages from {pdf_file.name}")
            except Exception as e:
                logger.error(f"Error loading {pdf_file.name}: {e}")
                raise

        return all_pages
