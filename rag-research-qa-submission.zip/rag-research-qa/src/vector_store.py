"""Vector store module with FAISS indexing, metadata persistence, and consistency checks."""

import os
import json
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Any
import numpy as np

from src.chunking import Chunk

logger = logging.getLogger(__name__)


class VectorStore:
    """FAISS-based vector database with metadata synchronization and persistence."""

    def __init__(self, dimension: int = 384):
        self.dimension = dimension
        self.index = None
        self.chunks_metadata: List[Dict[str, Any]] = []
        self._faiss_available = False
        self._initialize_backend()

    def _initialize_backend(self):
        """Attempts to initialize FAISS backend; falls back to numpy exact search if missing."""
        try:
            import faiss
            self.index = faiss.IndexFlatIP(self.dimension)  # Inner product on normalized vectors = cosine sim
            self._faiss_available = True
            logger.info("FAISS vector backend initialized (IndexFlatIP).")
        except ImportError:
            logger.warning("FAISS not installed. Using high-performance NumPy exact cosine index.")
            self.index = None
            self._faiss_available = False
            self._vectors: List[np.ndarray] = []

    @property
    def is_faiss_active(self) -> bool:
        return self._faiss_available

    def size(self) -> int:
        """Returns the number of vectors currently indexed."""
        if self._faiss_available and self.index is not None:
            return self.index.ntotal
        elif not self._faiss_available and hasattr(self, "_vectors"):
            return len(self._vectors)
        return len(self.chunks_metadata)

    def add_chunks(self, chunks: List[Chunk], embeddings: np.ndarray):
        """Adds chunks and their corresponding embeddings to the index."""
        if len(chunks) != len(embeddings):
            raise ValueError(
                f"Mismatch between number of chunks ({len(chunks)}) and embeddings ({len(embeddings)})"
            )

        if len(chunks) == 0:
            return

        if embeddings.shape[1] != self.dimension:
            raise ValueError(
                f"Embedding dimension {embeddings.shape[1]} does not match index dimension {self.dimension}"
            )

        # Ensure float32 format
        vectors = np.ascontiguousarray(embeddings, dtype=np.float32)

        if self._faiss_available and self.index is not None:
            self.index.add(vectors)
        else:
            if not hasattr(self, "_vectors"):
                self._vectors = []
            for v in vectors:
                self._vectors.append(v)

        for chunk in chunks:
            self.chunks_metadata.append(chunk.to_dict())

        logger.info(f"Added {len(chunks)} chunks to vector store (total: {self.size()}).")

    def search(self, query_vector: np.ndarray, top_k: int = 5) -> List[Tuple[Dict[str, Any], float]]:
        """Searches for top_k most similar chunks by cosine similarity."""
        if self.size() == 0:
            return []

        if top_k <= 0:
            return []

        top_k = min(top_k, self.size())
        q_vec = np.ascontiguousarray(query_vector.reshape(1, -1), dtype=np.float32)

        if self._faiss_available and self.index is not None:
            scores, indices = self.index.search(q_vec, top_k)
            scores = scores[0]
            indices = indices[0]
        else:
            # NumPy exact inner product
            matrix = np.array(self._vectors, dtype=np.float32)
            sims = np.dot(matrix, q_vec.flatten())
            indices = np.argsort(sims)[::-1][:top_k]
            scores = sims[indices]

        results: List[Tuple[Dict[str, Any], float]] = []
        for idx, score in zip(indices, scores):
            if idx < 0 or idx >= len(self.chunks_metadata):
                continue
            meta = self.chunks_metadata[idx]
            results.append((meta, float(score)))

        return results

    def save(self, index_path: str | Path, metadata_path: str | Path):
        """Persists the vector index and synchronized chunk metadata."""
        idx_p = Path(index_path)
        meta_p = Path(metadata_path)

        idx_p.parent.mkdir(parents=True, exist_ok=True)
        meta_p.parent.mkdir(parents=True, exist_ok=True)

        # Save metadata JSON
        with open(meta_p, "w", encoding="utf-8") as f:
            json.dump(self.chunks_metadata, f, indent=2, ensure_ascii=False)

        # Save index
        if self._faiss_available and self.index is not None:
            import faiss
            faiss.write_index(self.index, str(idx_p))
        else:
            # Save numpy vectors directly using open file to avoid auto .npy extension
            with open(idx_p, "wb") as f:
                vecs = np.array(self._vectors, dtype=np.float32) if hasattr(self, "_vectors") and self._vectors else np.empty((0, self.dimension), dtype=np.float32)
                np.save(f, vecs)

        logger.info(f"Saved {self.size()} indexed items to {idx_p} and {meta_p}.")

    def load(self, index_path: str | Path, metadata_path: str | Path):
        """Loads index and metadata with strict consistency validation."""
        idx_p = Path(index_path)
        meta_p = Path(metadata_path)

        # Resolve index file if saved with .npy
        if not idx_p.exists():
            alt_p = Path(str(idx_p) + ".npy")
            if alt_p.exists():
                idx_p = alt_p
            else:
                raise FileNotFoundError(f"Vector index file not found: {idx_p}")

        if not meta_p.exists():
            raise FileNotFoundError(f"Metadata file not found: {meta_p}")

        # Load metadata
        with open(meta_p, "r", encoding="utf-8") as f:
            metadata = json.load(f)

        # Load index
        if self._faiss_available:
            try:
                import faiss
                loaded_index = faiss.read_index(str(idx_p))
                indexed_count = loaded_index.ntotal
                self.index = loaded_index
            except Exception as e:
                logger.warning(f"Failed to read FAISS index directly ({e}), checking numpy fallback.")
                with open(idx_p, "rb") as f:
                    vectors = np.load(f)
                import faiss
                self.index = faiss.IndexFlatIP(self.dimension)
                if len(vectors) > 0:
                    self.index.add(np.ascontiguousarray(vectors, dtype=np.float32))
                indexed_count = self.index.ntotal
        else:
            with open(idx_p, "rb") as f:
                vectors = np.load(f)
            self._vectors = [v for v in vectors]
            indexed_count = len(self._vectors)

        # Enforce consistency: count of vectors must strictly match metadata items
        if indexed_count != len(metadata):
            raise ValueError(
                f"Index-Metadata consistency violation: Index has {indexed_count} vectors "
                f"but metadata contains {len(metadata)} items. Rebuild index required."
            )

        self.chunks_metadata = metadata
        logger.info(f"Loaded vector store with {indexed_count} synchronized entries.")
