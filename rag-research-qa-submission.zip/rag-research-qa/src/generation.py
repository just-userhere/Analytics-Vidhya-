"""Answer generation module with strict factual grounding and Google Gemini LLM integration."""

import os
import logging
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional, Any

from src.retrieval import RetrievedPassage
from src.citations import Citation, CitationManager

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are a senior AI research assistant specialized in question answering over academic AI literature.

CRITICAL GROUNDING RULES:
1. Answer the user question strictly using ONLY the factual evidence provided in the EVIDENCE BLOCKS below.
2. Every major factual claim or technical description MUST include an inline citation identifier referencing the evidence block (e.g., [1], [2], or [1][3]).
3. NEVER fabricate or extrapolate information, formulas, page numbers, or findings not present in the evidence.
4. If the retrieved evidence does not contain enough information to answer the question, explicitly declare: "The provided research papers do not contain sufficient evidence to answer this question."
5. If different papers present contrasting approaches or findings, clearly explain the distinction and cite both sources.
6. Keep the answer structured, precise, technical, and objective."""


@dataclass
class GenerationResult:
    """Encapsulates generated answer, citations, and metadata."""
    question: str
    answer: str
    citations: List[Citation]
    is_live_llm: bool
    model_name: str
    cited_indices: List[int]
    is_fully_grounded: bool
    evidence_block: str

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["citations"] = [c.to_dict() if isinstance(c, Citation) else c for c in self.citations]
        return d


class AnswerGenerator:
    """Manages prompt construction and LLM answer generation."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model_name: str = "gemini-2.5-flash",
        temperature: float = 0.1,
        max_tokens: int = 1024,
        llm_client: Optional[Any] = None
    ):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY") or ""
        self.model_name = model_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._custom_client = llm_client

    def is_api_configured(self) -> bool:
        """Checks if an API key is present."""
        return bool(self.api_key and len(self.api_key.strip()) > 5)

    def _build_prompt(self, question: str, evidence_text: str) -> str:
        """Constructs the grounding prompt with question and evidence blocks."""
        prompt = (
            f"{SYSTEM_PROMPT}\n\n"
            f"=== RETRIEVED EVIDENCE FROM RESEARCH PAPERS ===\n"
            f"{evidence_text}\n"
            f"=== END OF EVIDENCE ===\n\n"
            f"QUESTION: {question}\n\n"
            f"Please provide an accurate, technically rigorous answer grounded solely in the above evidence blocks with inline citations (e.g., [1], [2])."
        )
        return prompt

    def generate(
        self,
        question: str,
        passages: List[RetrievedPassage]
    ) -> GenerationResult:
        """Generates a grounded answer for a question given retrieved passages."""
        citations = CitationManager.build_citations(passages)
        evidence_text = CitationManager.format_evidence_block(passages)

        if not passages:
            empty_msg = (
                "The provided research papers do not contain sufficient evidence to answer this question. "
                "No relevant passages were retrieved from the indexed document collection."
            )
            return GenerationResult(
                question=question,
                answer=empty_msg,
                citations=[],
                is_live_llm=False,
                model_name=self.model_name,
                cited_indices=[],
                is_fully_grounded=True,
                evidence_block=evidence_text
            )

        prompt = self._build_prompt(question, evidence_text)

        # 1. Custom / Mock client for automated tests
        if self._custom_client is not None:
            try:
                raw_answer = self._custom_client.generate(prompt)
                cited_indices = CitationManager.extract_cited_indices(raw_answer)
                return GenerationResult(
                    question=question,
                    answer=raw_answer,
                    citations=citations,
                    is_live_llm=True,
                    model_name=f"mock/{self.model_name}",
                    cited_indices=cited_indices,
                    is_fully_grounded=len(cited_indices) > 0,
                    evidence_block=evidence_text
                )
            except Exception as e:
                logger.error(f"Custom LLM client error: {e}")

        # 2. Live Google GenAI API Call if configured
        if self.is_api_configured():
            try:
                from google import genai
                from google.genai import types

                client = genai.Client(api_key=self.api_key)
                response = client.models.generate_content(
                    model=self.model_name,
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        temperature=self.temperature,
                        max_output_tokens=self.max_tokens,
                    )
                )

                answer_text = response.text.strip() if response.text else "No response generated by model."
                verification = CitationManager.verify_citations(answer_text, citations)

                return GenerationResult(
                    question=question,
                    answer=answer_text,
                    citations=citations,
                    is_live_llm=True,
                    model_name=self.model_name,
                    cited_indices=verification["all_cited_indices"],
                    is_fully_grounded=verification["is_fully_grounded"],
                    evidence_block=evidence_text
                )
            except Exception as e:
                logger.error(f"Gemini API call failed: {e}")
                error_msg = f"API Error: Failed to generate response with Gemini ({e})."
                return GenerationResult(
                    question=question,
                    answer=f"{error_msg}\n\nPlease check your GEMINI_API_KEY and model selection.",
                    citations=citations,
                    is_live_llm=False,
                    model_name=self.model_name,
                    cited_indices=[],
                    is_fully_grounded=False,
                    evidence_block=evidence_text
                )

        # 3. Graceful Local Demo / Evidence-Only Mode when API Key is not set
        notice = (
            "> **NOTE: GEMINI_API_KEY is not configured.**\n"
            "> Below are the verified evidence passages retrieved and ranked from the authentic research papers. "
            "Configure your Gemini API key in the sidebar or via the `.env` file to generate live synthesized LLM answers.\n\n"
            "### Retrieved Research Evidence Summary:\n"
        )
        summary_lines = []
        for c in citations:
            summary_lines.append(
                f"- **[{c.citation_id}] {c.paper_title}** (PDF Page {c.page_number}):\n"
                f"  > *\"{c.excerpt}\"*\n"
            )

        demo_answer = notice + "\n".join(summary_lines)
        return GenerationResult(
            question=question,
            answer=demo_answer,
            citations=citations,
            is_live_llm=False,
            model_name="unconfigured (evidence-only mode)",
            cited_indices=[c.citation_id for c in citations],
            is_fully_grounded=True,
            evidence_block=evidence_text
        )
