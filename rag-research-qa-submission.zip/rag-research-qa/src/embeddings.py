"""Embedding generation module with SentenceTransformers and TF-IDF/LSA semantic fallback."""

import logging
from typing import List, Union
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD

logger = logging.getLogger(__name__)


class EmbeddingGenerator:
    """Generates normalized vector embeddings for text passages and queries."""

    def __init__(self, model_name: str = "all-MiniLM-L6-v2", dimension: int = 384):
        self.model_name = model_name
        self.dimension = dimension
        self._model = None
        self._is_fallback = False
        self._tfidf = None
        self._svd = None
        self._initialize_model()

    def _initialize_model(self):
        """Attempts to load SentenceTransformer; falls back to TF-IDF/LSA projection if unavailable."""
        try:
            from sentence_transformers import SentenceTransformer
            logger.info(f"Loading SentenceTransformer: {self.model_name}")
            self._model = SentenceTransformer(self.model_name)
            self._is_fallback = False
            logger.info("SentenceTransformer loaded successfully.")
        except Exception as e:
            logger.warning(
                f"SentenceTransformer not available or failed to load ({e}). "
                f"Activating TF-IDF / LSA semantic projection (dim={self.dimension})."
            )
            self._model = None
            self._is_fallback = True

    @property
    def is_fallback(self) -> bool:
        return self._is_fallback

    def fit_fallback(self, corpus: List[str]):
        """Fits TF-IDF and SVD on corpus for dense semantic representation when in fallback mode."""
        if not corpus:
            return
        n_samples = len(corpus)
        n_comp = min(self.dimension, n_samples - 1) if n_samples > 1 else 1

        self._tfidf = TfidfVectorizer(
            ngram_range=(1, 2),
            max_features=10000,
            sublinear_tf=True
        )
        tfidf_mat = self._tfidf.fit_transform(corpus)

        self._svd = TruncatedSVD(n_components=n_comp, random_state=42)
        self._svd.fit(tfidf_mat)
        logger.info(f"Fitted TF-IDF / LSA semantic fallback with {n_comp} components.")

    def _lsa_project(self, texts: List[str]) -> np.ndarray:
        """Projects texts into dense L2-normalized semantic space."""
        if self._tfidf is not None and self._svd is not None:
            tfidf_mat = self._tfidf.transform(texts)
            reduced = self._svd.transform(tfidf_mat)

            # Pad or truncate to self.dimension
            batch_size = len(texts)
            out_mat = np.zeros((batch_size, self.dimension), dtype=np.float32)
            n_cols = min(reduced.shape[1], self.dimension)
            out_mat[:, :n_cols] = reduced[:, :n_cols]

            # L2 normalize
            norms = np.linalg.norm(out_mat, axis=1, keepdims=True)
            norms[norms == 0] = 1.0
            return (out_mat / norms).astype(np.float32)

        # Hashing projection if fit_fallback was not called
        vectors = []
        for text in texts:
            words = text.lower().split()
            vec = np.zeros(self.dimension, dtype=np.float32)
            if not words:
                vec[0] = 1.0
            else:
                for idx, w in enumerate(words):
                    h = abs(hash(w)) % self.dimension
                    weight = 1.0 / (1.0 + 0.05 * idx)
                    vec[h] += weight
                    if len(w) > 3:
                        h2 = abs(hash(w[:4])) % self.dimension
                        vec[h2] += 0.5 * weight
            norm = np.linalg.norm(vec)
            if norm > 0:
                vec = vec / norm
            else:
                vec[0] = 1.0
            vectors.append(vec)
        return np.array(vectors, dtype=np.float32)

    def embed_texts(self, texts: List[str], batch_size: int = 32) -> np.ndarray:
        """Encodes a list of texts into L2-normalized numpy float32 embeddings."""
        if not texts:
            return np.empty((0, self.dimension), dtype=np.float32)

        if self._model is not None:
            try:
                embeddings = self._model.encode(
                    texts,
                    batch_size=batch_size,
                    show_progress_bar=False,
                    normalize_embeddings=True,
                    convert_to_numpy=True
                )
                return np.asarray(embeddings, dtype=np.float32)
            except Exception as e:
                logger.warning(f"SentenceTransformer encoding failed: {e}. Using semantic projection.")

        return self._lsa_project(texts)

    def embed_query(self, query: str) -> np.ndarray:
        """Encodes a single query string into a 1D normalized float32 numpy vector."""
        vectors = self.embed_texts([query])
        return vectors[0]
