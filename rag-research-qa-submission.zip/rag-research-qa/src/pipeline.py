"""End-to-end RAG Pipeline orchestrating ingestion, retrieval, and grounded answer generation."""

import json
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

import config
from src.document_loader import DocumentLoader, DocumentPage
from src.chunking import TextChunker, Chunk
from src.embeddings import EmbeddingGenerator
from src.vector_store import VectorStore
from src.retrieval import BM25Retriever, HybridRetriever, RetrievedPassage
from src.citations import CitationManager
from src.generation import AnswerGenerator, GenerationResult

logger = logging.getLogger(__name__)


class RAGPipeline:
    """Unified pipeline for document ingestion, hybrid retrieval, and grounded QA."""

    def __init__(
        self,
        embedding_model_name: str = config.EMBEDDING_MODEL_NAME,
        chunk_size: int = config.CHUNK_SIZE,
        chunk_overlap: int = config.CHUNK_OVERLAP,
        top_k: int = config.DEFAULT_TOP_K,
        gemini_model: str = config.DEFAULT_GEMINI_MODEL,
        api_key: Optional[str] = None
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.top_k = top_k
        self.gemini_model = gemini_model
        self.api_key = api_key or config.GEMINI_API_KEY

        # Initialize subcomponents
        self.loader = DocumentLoader(paper_registry=config.RESEARCH_PAPERS)
        self.chunker = TextChunker(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        self.embedding_generator = EmbeddingGenerator(model_name=embedding_model_name, dimension=config.EMBEDDING_DIM)
        self.vector_store = VectorStore(dimension=config.EMBEDDING_DIM)
        self.bm25_retriever = BM25Retriever()

        self.retriever = HybridRetriever(
            vector_store=self.vector_store,
            embedding_generator=self.embedding_generator,
            bm25_retriever=self.bm25_retriever,
            rrf_k=config.RRF_K,
            semantic_weight=config.SEMANTIC_WEIGHT,
            keyword_weight=config.KEYWORD_WEIGHT
        )

        self.generator = AnswerGenerator(
            api_key=self.api_key,
            model_name=self.gemini_model,
            temperature=config.LLM_TEMPERATURE,
            max_tokens=config.LLM_MAX_TOKENS
        )

        self._is_ready = False
        self._load_existing_indexes_if_available()

    def is_indexed(self) -> bool:
        """Returns True if both vector store and BM25 index are populated."""
        return (
            self.vector_store.size() > 0 and
            len(self.bm25_retriever.chunks) > 0 and
            self._is_ready
        )

    def _load_existing_indexes_if_available(self):
        """Attempts to load pre-built indexes if present on disk."""
        idx_exists = config.INDEX_FILE.exists() or Path(str(config.INDEX_FILE) + ".npy").exists()
        if idx_exists and config.METADATA_FILE.exists() and config.BM25_FILE.exists():
            try:
                self.vector_store.load(config.INDEX_FILE, config.METADATA_FILE)
                self.bm25_retriever.load(config.BM25_FILE)
                self._is_ready = True
                logger.info(f"Loaded existing knowledge base with {self.vector_store.size()} chunks.")
            except Exception as e:
                logger.warning(f"Could not load pre-existing indexes ({e}). Ingestion required.")
                self._is_ready = False

    def ingest(
        self,
        papers_dir: Optional[Path | str] = None,
        force_rebuild: bool = False
    ) -> Dict[str, Any]:
        """Runs the full ingestion pipeline: load, chunk, embed, index, and save."""
        source_dir = Path(papers_dir) if papers_dir else config.PAPERS_DIR
        start_time = time.time()

        if self.is_indexed() and not force_rebuild:
            logger.info("Knowledge base is already indexed. Skipping re-ingestion.")
            return self.get_status()

        logger.info(f"Starting document ingestion from {source_dir}...")

        # 1. Load PDFs
        pages = self.loader.load_directory(source_dir)
        if not pages:
            raise ValueError(f"No pages extracted from {source_dir}")

        # 2. Chunk documents
        chunks = self.chunker.chunk_documents(pages, deduplicate=True)
        if not chunks:
            raise ValueError("No chunks created during document processing.")

        # 3. Generate embeddings
        chunk_texts = [c.text for c in chunks]
        if self.embedding_generator.is_fallback:
            self.embedding_generator.fit_fallback(chunk_texts)

        logger.info(f"Generating embeddings for {len(chunks)} chunks...")
        embeddings = self.embedding_generator.embed_texts(
            chunk_texts,
            batch_size=config.EMBEDDING_BATCH_SIZE
        )

        # 4. Populate vector store
        # Re-initialize to ensure clean index
        self.vector_store = VectorStore(dimension=config.EMBEDDING_DIM)
        self.vector_store.add_chunks(chunks, embeddings)

        # 5. Populate BM25 index
        self.bm25_retriever.fit([c.to_dict() for c in chunks])

        # 6. Persist to disk
        self.vector_store.save(config.INDEX_FILE, config.METADATA_FILE)
        self.bm25_retriever.save(config.BM25_FILE)

        # Update hybrid retriever references
        self.retriever.vector_store = self.vector_store
        self.retriever.bm25_retriever = self.bm25_retriever

        # 7. Write index manifest
        paper_counts = {}
        for p in pages:
            paper_counts[p.paper_title] = paper_counts.get(p.paper_title, 0) + 1

        manifest = {
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "total_pages": len(pages),
            "total_chunks": len(chunks),
            "papers_indexed": paper_counts,
            "chunk_size": self.chunk_size,
            "chunk_overlap": self.chunk_overlap,
            "embedding_model": self.embedding_generator.model_name,
            "embedding_dimension": config.EMBEDDING_DIM,
            "ingestion_duration_seconds": round(time.time() - start_time, 2)
        }
        with open(config.MANIFEST_FILE, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

        self._is_ready = True
        logger.info(f"Ingestion complete in {manifest['ingestion_duration_seconds']}s.")
        return manifest

    def query(
        self,
        question: str,
        top_k: Optional[int] = None,
        use_reranker: bool = config.USE_RERANKER_DEFAULT,
        api_key: Optional[str] = None,
        model_name: Optional[str] = None
    ) -> GenerationResult:
        """Executes full RAG query: hybrid retrieval, reranking, and grounded generation."""
        if not self.is_indexed():
            raise RuntimeError("Knowledge base is not indexed yet. Please run ingestion first.")

        k = top_k if top_k is not None else self.top_k

        # Retrieve relevant passages
        passages = self.retriever.retrieve(
            query=question,
            top_k=k,
            candidate_k=config.RETRIEVAL_CANDIDATE_K,
            use_reranker=use_reranker
        )

        # Update generator credentials/model if provided
        if api_key is not None:
            self.generator.api_key = api_key
        if model_name is not None:
            self.generator.model_name = model_name

        # Generate answer with citations
        result = self.generator.generate(question=question, passages=passages)
        return result

    def get_status(self) -> Dict[str, Any]:
        """Returns comprehensive diagnostic status of the pipeline."""
        return {
            "is_indexed": self.is_indexed(),
            "indexed_chunks": self.vector_store.size(),
            "embedding_model": self.embedding_generator.model_name,
            "is_embedding_fallback": self.embedding_generator.is_fallback,
            "is_faiss_active": self.vector_store.is_faiss_active,
            "gemini_api_configured": self.generator.is_api_configured(),
            "gemini_model": self.generator.model_name,
            "paper_registry_count": len(config.RESEARCH_PAPERS),
            "manifest_exists": config.MANIFEST_FILE.exists()
        }
