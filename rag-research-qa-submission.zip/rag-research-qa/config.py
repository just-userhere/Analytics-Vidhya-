"""Configuration module for the Research Paper RAG Assistant."""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file if present
load_dotenv()

# Base directories
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
PAPERS_DIR = DATA_DIR / "papers"
PROCESSED_DIR = DATA_DIR / "processed"
REPORTS_DIR = BASE_DIR / "reports"

# Ensure runtime directories exist
PAPERS_DIR.mkdir(parents=True, exist_ok=True)
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

# Storage paths
INDEX_FILE = PROCESSED_DIR / "faiss_index.bin"
METADATA_FILE = PROCESSED_DIR / "chunks_metadata.json"
BM25_FILE = PROCESSED_DIR / "bm25_index.pkl"
MANIFEST_FILE = PROCESSED_DIR / "index_manifest.json"

# Ingestion & Chunking parameters
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "800"))          # Characters per chunk
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "150"))     # Overlap characters
MIN_CHUNK_LENGTH = 80                                     # Minimum characters to keep

# Embedding configuration
EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME", "all-MiniLM-L6-v2")
EMBEDDING_DIM = 384
EMBEDDING_BATCH_SIZE = 32

# Retrieval settings
DEFAULT_TOP_K = int(os.getenv("TOP_K", "6"))
RETRIEVAL_CANDIDATE_K = int(os.getenv("RETRIEVAL_CANDIDATE_K", "25"))  # Pool for RRF & reranker
RRF_K = int(os.getenv("RRF_K", "60"))                                  # Reciprocal Rank Fusion constant
SEMANTIC_WEIGHT = float(os.getenv("SEMANTIC_WEIGHT", "0.6"))
KEYWORD_WEIGHT = float(os.getenv("KEYWORD_WEIGHT", "0.4"))
RERANKER_MODEL_NAME = os.getenv("RERANKER_MODEL_NAME", "cross-encoder/ms-marco-MiniLM-L-6-v2")
USE_RERANKER_DEFAULT = os.getenv("USE_RERANKER", "true").lower() in ("true", "1", "yes")

# Gemini LLM configuration
DEFAULT_GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.1"))
LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "1024"))

# Registry of the four canonical AI research papers
RESEARCH_PAPERS = {
    "attention_is_all_you_need": {
        "id": "attention_is_all_you_need",
        "title": "Attention Is All You Need",
        "authors": "Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, Illia Polosukhin",
        "short_authors": "Vaswani et al.",
        "year": 2017,
        "venue": "NeurIPS 2017",
        "arxiv_id": "1706.03762",
        "url": "https://arxiv.org/abs/1706.03762",
        "filename": "attention_is_all_you_need.pdf"
    },
    "language_models_few_shot_learners": {
        "id": "language_models_few_shot_learners",
        "title": "Language Models are Few-Shot Learners",
        "authors": "Tom B. Brown, Benjamin Mann, Nick Ryder, Melanie Subbiah, Jared Kaplan, Prafulla Dhariwal, et al.",
        "short_authors": "Brown et al.",
        "year": 2020,
        "venue": "NeurIPS 2020",
        "arxiv_id": "2005.14165",
        "url": "https://arxiv.org/abs/2005.14165",
        "filename": "language_models_few_shot_learners.pdf"
    },
    "retrieval_augmented_generation": {
        "id": "retrieval_augmented_generation",
        "title": "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks",
        "authors": "Patrick Lewis, Ethan Perez, Aleksandra Piktus, Fabio Petroni, Vladimir Karpukhin, Naman Goyal, et al.",
        "short_authors": "Lewis et al.",
        "year": 2020,
        "venue": "NeurIPS 2020",
        "arxiv_id": "2005.11401",
        "url": "https://arxiv.org/abs/2005.11401",
        "filename": "retrieval_augmented_generation.pdf"
    },
    "dense_passage_retrieval": {
        "id": "dense_passage_retrieval",
        "title": "Dense Passage Retrieval for Open-Domain Question Answering",
        "authors": "Vladimir Karpukhin, Barlas Oguz, Sewon Min, Patrick Lewis, Ledell Wu, Sergey Edunov, Danqi Chen, Wen-tau Yih",
        "short_authors": "Karpukhin et al.",
        "year": 2020,
        "venue": "EMNLP 2020",
        "arxiv_id": "2004.04906",
        "url": "https://arxiv.org/abs/2004.04906",
        "filename": "dense_passage_retrieval.pdf"
    }
}
