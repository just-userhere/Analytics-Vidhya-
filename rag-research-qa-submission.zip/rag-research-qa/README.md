# Research Paper RAG Assistant

A complete, production-grade Retrieval-Augmented Generation (RAG) system for question answering over peer-reviewed AI research literature, featuring hybrid semantic/keyword search, neural reranking, verifiable source attribution, and interactive Streamlit web interface.

---

## 📖 Table of Contents

- [Overview & Architecture](#overview--architecture)
- [Research Papers Included](#research-papers-included)
- [Project Structure](#project-structure)
- [Setup & Installation](#setup--installation)
- [API Key Configuration](#api-key-configuration)
- [Document Ingestion](#document-ingestion)
- [Running the Streamlit Application](#running-the-streamlit-application)
- [Running Automated Tests](#running-automated-tests)
- [Running Empirical Evaluation](#running-empirical-evaluation)
- [Retrieval & Citation Mechanics](#retrieval--citation-mechanics)
- [Troubleshooting](#troubleshooting)

---

## 🏗️ Overview & Architecture

The system enables researchers and students to ask natural-language questions over complex AI papers and receive precise, factual answers strictly grounded in the literature with verifiable source citations.

```
PDFs (data/papers/) ➔ PyMuPDF Page Extraction ➔ TextChunker (800 chars, 150 overlap)
                                                    │
                 ┌──────────────────────────────────┴──────────────────────────────────┐
                 ▼                                                                     ▼
    SentenceTransformers (all-MiniLM-L6-v2)                                    BM25 Keyword Index
                 │                                                                     │
                 ▼                                                                     │
         FAISS IndexFlatIP                                                             │
                 │                                                                     │
                 └──────────────────────────────────┬──────────────────────────────────┘
                                                    ▼
                                    Reciprocal Rank Fusion (RRF, k=60)
                                                    ▼
                               Cross-Encoder Reranker (ms-marco-MiniLM-L-6-v2)
                                                    ▼
                               Strict Grounded Prompt Construction
                                                    ▼
                                Google Gemini API (gemini-2.5-flash)
                                                    ▼
                             Streamlit Web Interface & Verifiable Citations
```

### Core Components
1. **Document Loader (`src/document_loader.py`)**: Page-by-page extraction using PyMuPDF (`pymupdf`), whitespace normalization, formula preservation, section heading candidate detection, and 1-based PDF page tracking.
2. **Chunking (`src/chunking.py`)**: Sentence-aware chunker with configurable size (800 chars) and overlap (150 chars). Preserves provenance metadata and performs SHA-256 deduplication.
3. **Embeddings (`src/embeddings.py`)**: Batched normalized float32 embeddings using `SentenceTransformers("all-MiniLM-L6-v2")` with automated TF-IDF / LSA fallback.
4. **Vector Store (`src/vector_store.py`)**: FAISS `IndexFlatIP` (exact cosine similarity) with strict metadata synchronization and consistency checks.
5. **Retrieval (`src/retrieval.py`)**: BM25Okapi + FAISS Dense Search + Reciprocal Rank Fusion (RRF) + Cross-Encoder Reranker (`cross-encoder/ms-marco-MiniLM-L-6-v2`).
6. **Citations (`src/citations.py`)**: Strict provenance manager extracting paper title, authors, filename, 1-based PDF page number, and literal excerpts.
7. **Generation (`src/generation.py`)**: Factual prompt engineering using Google GenAI SDK (`google-genai`). Includes unconfigured API key evidence mode and mock LLM test hooks.
8. **Web Interface (`app.py`)**: Streamlit app with collection status, quick sample question buttons, expandable citations, and evidence diagnostics.

---

## 📚 Research Papers Included

The knowledge base indexes four authentic, peer-reviewed AI research papers stored in `data/papers/`:

1. **Attention Is All You Need** (Vaswani et al., 2017) — *NeurIPS 2017* (`attention_is_all_you_need.pdf`, 15 pages)
2. **Language Models are Few-Shot Learners** (Brown et al., 2020) — *NeurIPS 2020* (`language_models_few_shot_learners.pdf`, 75 pages)
3. **Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks** (Lewis et al., 2020) — *NeurIPS 2020* (`retrieval_augmented_generation.pdf`, 19 pages)
4. **Dense Passage Retrieval for Open-Domain Question Answering** (Karpukhin et al., 2020) — *EMNLP 2020* (`dense_passage_retrieval.pdf`, 13 pages)

Total indexed collection: **122 pages, 640 chunks**.

---

## 📁 Project Structure

```
rag-research-qa/
├── app.py                     # Streamlit interactive web application
├── config.py                  # Central configuration and paper registry
├── requirements.txt           # Pinned production dependencies
├── README.md                  # Comprehensive documentation and run guide
├── .env.example               # Environment variables template
├── .gitignore                 # Secrets and temporary file ignore rules
├── data/
│   ├── papers/                # Authentic research paper PDFs
│   └── processed/             # Persisted FAISS, BM25, and metadata files
├── src/
│   ├── __init__.py
│   ├── document_loader.py     # PyMuPDF extraction and page metadata
│   ├── chunking.py            # Overlapping chunker and deduplication
│   ├── embeddings.py          # SentenceTransformers and fallback embeddings
│   ├── vector_store.py        # FAISS index with consistency checks
│   ├── retrieval.py           # Hybrid BM25 + FAISS + RRF + Reranker
│   ├── citations.py           # Citation attribution and verification
│   ├── generation.py          # Google Gemini LLM grounding integration
│   └── pipeline.py            # Unified orchestration pipeline
├── scripts/
│   ├── download_papers.py     # arXiv downloader for the 4 papers
│   ├── ingest_documents.py    # Document ingestion and index builder CLI
│   └── run_evaluation.py      # Automated 5-question evaluation runner
├── tests/
│   ├── test_document_loader.py
│   ├── test_chunking.py
│   ├── test_embeddings.py
│   ├── test_vector_store.py
│   ├── test_retrieval.py
│   ├── test_citations.py
│   ├── test_generation.py
│   └── test_pipeline_integration.py
└── reports/
    ├── evaluation_report.md   # Complete evaluation analysis report
    └── evaluation_results.json# Raw test outputs for the 5 questions
```

---

## 🚀 Setup & Installation

### 1. Prerequisites
- Python 3.10, 3.11, or 3.14 on Linux, macOS, or Windows.

### 2. Install Dependencies
```bash
cd rag-research-qa
pip install -r requirements.txt
```

---

## 🔑 API Key Configuration

The system connects to Google Gemini via the modern `google-genai` SDK.

### Option A: Via `.env` File (Recommended)
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Edit `.env` and set your key:
```ini
GEMINI_API_KEY=your_actual_gemini_api_key_here
GEMINI_MODEL=gemini-2.5-flash
```

### Option B: Via Streamlit UI
You can enter your API key directly into the secure sidebar text input inside the web application.

### Option C: Grounded Evidence Mode (No API Key Required)
If no API key is configured, the system executes the entire retrieval and citation pipeline, displaying the exact verified source passages and metadata.

---

## 📥 Document Ingestion

To re-download papers from arXiv (if needed):
```bash
python scripts/download_papers.py
```

To ingest papers and build the FAISS vector store and BM25 index:
```bash
python scripts/ingest_documents.py --rebuild
```

**Ingestion Output:**
- Loads all 4 PDFs from `data/papers/`
- Chunks text into 640 clean passages
- Computes dense embeddings with `all-MiniLM-L6-v2`
- Serializes FAISS index to `data/processed/faiss_index.bin`
- Serializes BM25 index to `data/processed/bm25_index.pkl`
- Saves chunk metadata to `data/processed/chunks_metadata.json`

---

## 🖥️ Running the Streamlit Application

Start the web interface with:
```bash
streamlit run app.py
```

Open your browser at `http://localhost:8501`.

### Key Features:
- **Instant Sample Questions:** Click any of the 5 mandatory question buttons to test retrieval instantly.
- **Grounded Answers:** Answers rendered with inline citation markers `[1]`, `[2]`.
- **Expandable Citation Cards:** Click citation badges to view paper title, authors, 1-based PDF page, relevance score, and verbatim excerpt.
- **Evidence Inspector:** Expand the retrieval diagnostics tab to inspect raw context sent to the LLM.

---

## 🧪 Running Automated Tests

Run the full automated pytest suite (40 unit, integration, and concept coverage tests):
```bash
pytest tests/ -v
```

All external API calls are mocked in unit tests, allowing tests to run completely offline without an API key.

---

## 📊 Running Empirical Evaluation

Run the evaluation script across all 5 mandatory benchmark questions:
```bash
python scripts/run_evaluation.py
```

### Mandatory Question Results (100% Target Paper Retrieval, 90.9% Average Concept Recall):
1. **Q1 (RAG Model Components):** Retrieved *Retrieval-Augmented Generation* (PDF Page 2) — **100.0%** concept recall (`retriever`, `generator`, `DPR`, `BART`, `parametric`, `non-parametric`, `marginalize`).
2. **Q2 (Transformer Encoder Sub-Layers):** Retrieved *Attention Is All You Need* (PDF Page 3) — **100.0%** concept recall (`multi-head self-attention`, `feed-forward`, `residual`, `layer normalization`, `sub-layers`).
3. **Q3 (Positional Encoding):** Retrieved *Attention Is All You Need* (PDF Page 6) — **85.7%** concept recall (`sinusoid`, `sine`, `cosine`, `frequencies`, `recurrence`, `convolution`).
4. **Q4 (Multi-Head Attention):** Retrieved *Attention Is All You Need* (PDF Page 5) — **85.7%** concept recall (`jointly attend`, `linear projections`, `queries`, `keys`, `values`, `scaled dot-product`).
5. **Q5 (Few-Shot Learning in GPT-3):** Retrieved *Language Models are Few-Shot Learners* (PDF Page 6) — **83.3%** concept recall (`demonstrations`, `context window`, `in-context learning`, `gradient updates`, `weight updates`).

Results are saved to `reports/evaluation_results.json` and analyzed in `reports/evaluation_report.md`.

---

## 🔍 Retrieval & Citation Mechanics

### Reciprocal Rank Fusion (RRF)
Given dense rank $r_{\text{dense}}(d)$ and sparse BM25 rank $r_{\text{bm25}}(d)$, passages are scored using:
$$RRF(d) = \frac{w_{\text{dense}}}{k + r_{\text{dense}}(d)} + \frac{w_{\text{bm25}}}{k + r_{\text{bm25}}(d)}$$
where $k = 60$, $w_{\text{dense}} = 0.6$, and $w_{\text{bm25}} = 0.4$.

### Source Attribution
Every retrieved chunk strictly tracks:
- `paper_title`: Canonical paper title.
- `authors`: Lead author string (e.g. *Vaswani et al.*).
- `filename`: Source PDF filename in `data/papers/`.
- `page_number`: 1-based page number in the source PDF file.
- `excerpt`: The exact passage text extracted from that specific page.

---

## 🛠️ Troubleshooting

- **PDF Loading Warnings:** `pymupdf` is used natively to eliminate deprecated fitz warnings.
- **Port In Use for Streamlit:** Run `streamlit run app.py --server.port 8502` if port 8501 is occupied.
- **Windows Terminal Unicode:** All CLI scripts automatically set `sys.stdout.reconfigure(encoding="utf-8")` to prevent Windows `cp1252` encoding errors on mathematical symbols.
