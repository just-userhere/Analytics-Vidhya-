"""
Unit and Integration Test Suite for Intelligent Travel Assistant AI
====================================================================
Tests verify:
- Custom Weather Tool (@tool) with WeatherAPI parsing and error handling
- Attractions Search Tool with DuckDuckGo / Tavily fallbacks
- Input validation (empty city, whitespace)
- Missing API key notices
- Network error handling
- LangChain Tool-Calling Agent and AgentExecutor construction
"""

import os
import sys
import unittest
from unittest.mock import patch, MagicMock
import pytest
import requests

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from travel_assistant import (
    get_current_weather,
    search_tourist_attractions,
    get_llm,
    create_travel_assistant_agent,
)


class TestWeatherTool(unittest.TestCase):
    """Test suite for get_current_weather tool."""

    def test_empty_city_validation(self):
        """Weather tool should reject empty or whitespace city."""
        result = get_current_weather.invoke({"city": ""})
        self.assertIn("Error: Destination city name cannot be empty", result)

        result_whitespace = get_current_weather.invoke({"city": "   "})
        self.assertIn("Error: Destination city name cannot be empty", result_whitespace)

    @patch.dict(os.environ, {"WEATHERAPI_API_KEY": ""}, clear=True)
    def test_missing_api_key(self):
        """Weather tool should return informative notice when API key is missing."""
        result = get_current_weather.invoke({"city": "Tokyo"})
        self.assertIn("WEATHERAPI_API_KEY is not configured", result)
        self.assertIn("https://www.weatherapi.com/", result)

    @patch.dict(os.environ, {"WEATHERAPI_API_KEY": "dummy_test_key_123"})
    @patch("requests.get")
    def test_successful_weather_fetch(self, mock_get):
        """Weather tool should correctly parse WeatherAPI response."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "location": {
                "name": "Tokyo",
                "region": "Tokyo",
                "country": "Japan",
                "localtime": "2026-10-11 23:45",
            },
            "current": {
                "temp_c": 18.5,
                "temp_f": 65.3,
                "feelslike_c": 17.8,
                "feelslike_f": 64.0,
                "humidity": 60,
                "condition": {"text": "Clear"},
                "wind_kph": 12.0,
                "wind_mph": 7.5,
                "wind_dir": "NE",
                "uv": 0.0,
            },
        }
        mock_get.return_value = mock_response

        result = get_current_weather.invoke({"city": "Tokyo"})
        self.assertIn("Current Weather Data for Tokyo", result)
        self.assertIn("Japan", result)
        self.assertIn("18.5°C", result)
        self.assertIn("Clear", result)
        self.assertIn("Humidity: 60%", result)

    @patch.dict(os.environ, {"WEATHERAPI_API_KEY": "dummy_test_key_123"})
    @patch("requests.get")
    def test_invalid_city_not_found(self, mock_get):
        """Weather tool should handle 400 location not found error (code 1006)."""
        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.json.return_value = {
            "error": {
                "code": 1006,
                "message": "No matching location found.",
            }
        }
        mock_get.return_value = mock_response

        result = get_current_weather.invoke({"city": "NonExistentCity12345"})
        self.assertIn("Destination city 'NonExistentCity12345' was not found", result)

    @patch.dict(os.environ, {"WEATHERAPI_API_KEY": "invalid_key"})
    @patch("requests.get")
    def test_authentication_error(self, mock_get):
        """Weather tool should handle authentication failure (code 2006)."""
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.json.return_value = {
            "error": {
                "code": 2006,
                "message": "API key is invalid.",
            }
        }
        mock_get.return_value = mock_response

        result = get_current_weather.invoke({"city": "Paris"})
        self.assertIn("WeatherAPI authentication failed", result)

    @patch.dict(os.environ, {"WEATHERAPI_API_KEY": "dummy_key"})
    @patch("requests.get")
    def test_network_timeout(self, mock_get):
        """Weather tool should gracefully handle network timeout exceptions."""
        mock_get.side_effect = requests.exceptions.Timeout("Connection timed out")

        result = get_current_weather.invoke({"city": "London"})
        self.assertIn("Network request timed out", result)


class TestSearchTool(unittest.TestCase):
    """Test suite for search_tourist_attractions tool."""

    def test_empty_city_validation(self):
        """Search tool should reject empty city input."""
        result = search_tourist_attractions.invoke({"city": ""})
        self.assertIn("Error: Destination city name cannot be empty", result)

    def test_live_attractions_search(self):
        """Search tool should return tourist attractions via DuckDuckGo without API keys."""
        result = search_tourist_attractions.invoke({"city": "Rome"})
        self.assertTrue(len(result) > 50)
        self.assertTrue("Rome" in result or "Attractions" in result or "sights" in result.lower())


class TestLLMAndAgent(unittest.TestCase):
    """Test suite for LLM configuration and AgentExecutor creation."""

    def test_missing_groq_key_raises_value_error(self):
        """get_llm should raise descriptive ValueError when GROQ_API_KEY is missing."""
        with patch.dict(os.environ, {"LLM_PROVIDER": "groq", "GROQ_API_KEY": ""}, clear=True):
            with self.assertRaises(ValueError) as ctx:
                get_llm()
            self.assertIn("Missing GROQ_API_KEY", str(ctx.exception))

    def test_unsupported_provider_raises_value_error(self):
        """get_llm should raise ValueError for unsupported providers."""
        with patch.dict(os.environ, {"LLM_PROVIDER": "unsupported_llm"}):
            with self.assertRaises(ValueError) as ctx:
                get_llm()
            self.assertIn("Unsupported LLM_PROVIDER", str(ctx.exception))

    def test_agent_executor_creation_with_mock_llm(self):
        """create_travel_assistant_agent should bind tools and return an AgentExecutor."""
        mock_llm = MagicMock()
        mock_llm.bind_tools = MagicMock(return_value=mock_llm)

        executor = create_travel_assistant_agent(llm=mock_llm, verbose=False)
        self.assertIsNotNone(executor)
        self.assertEqual(len(executor.tools), 2)
        tool_names = [t.name for t in executor.tools]
        self.assertIn("get_current_weather", tool_names)
        self.assertIn("search_tourist_attractions", tool_names)


if __name__ == "__main__":
    unittest.main()
