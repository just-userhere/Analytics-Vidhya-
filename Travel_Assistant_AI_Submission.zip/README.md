# Intelligent Travel Assistant AI 🌍✈️

An intelligent, autonomous travel assistant built with **LangChain**, powered by a **Tool-Calling Agent** architecture that dynamically coordinates real-time weather information and tourist attractions for any destination city worldwide.

Developed for the assignment: **"Building AI Agents with LangChain — Intelligent Travel Assistant AI"**.

---

## 📋 Table of Contents
- [Overview](#-overview)
- [System Architecture](#-system-architecture)
- [Core Features](#-core-features)
- [Project Structure](#-project-structure)
- [Prerequisites](#-prerequisites)
- [Installation Guide](#-installation-guide)
- [API Key Setup](#-api-key-setup)
- [Usage & Execution](#-usage--execution)
- [Testing & Diagnostics](#-testing--diagnostics)
- [Sample Output (Illustrative)](#-sample-output-illustrative)
- [Error Handling & Edge Cases](#-error-handling--edge-cases)
- [Limitations & Future Enhancements](#-limitations--future-enhancements)
- [License & Academic Integrity](#-license--academic-integrity)

---

## 🌟 Overview

Planning a trip requires synthesizing multiple real-time data sources: current meteorological conditions (to decide packing, indoor vs. outdoor scheduling) and local cultural landmarks or attractions. 

The **Intelligent Travel Assistant AI** addresses this challenge by combining:
1. **Custom Weather Tool (`@tool`)**: Queries [WeatherAPI.com](https://www.weatherapi.com/) for real-time temperature, precipitation, humidity, wind conditions, and local time.
2. **Tourist Attractions Search Tool**: Live web search powered by **DuckDuckGo** (default, no API key required) or **Tavily** for top sights, landmarks, and travel tips.
3. **LangChain Tool-Calling Agent**: Orchestrated using LangChain's official `create_tool_calling_agent` and executed via `AgentExecutor`. The LLM dynamically decides which tools to invoke, analyzes their output, and synthesizes a structured, personalized travel guide.

---

## 🏗️ System Architecture

```mermaid
flowchart TD
    User([User / CLI]) -->|1. Destination City| CLI[travel_assistant.py CLI]
    CLI -->|2. Formats Prompt| Executor[AgentExecutor]
    Executor -->|3. Coordinates Tools| Agent[Tool-Calling Agent]
    Agent <-->|4. Tool Schema & Selection| LLM[LLM: Groq / OpenAI / Gemini]
    
    Agent -->|5a. Tool Call| WeatherTool["@tool: get_current_weather"]
    Agent -->|5b. Tool Call| SearchTool["@tool: search_tourist_attractions"]
    
    WeatherTool -->|HTTP GET| WeatherAPI[(WeatherAPI.com REST API)]
    SearchTool -->|Web Query| SearchAPI[(DuckDuckGo / Tavily)]
    
    WeatherAPI -->|Weather JSON| WeatherTool
    SearchAPI -->|Attractions Text| SearchTool
    
    WeatherTool -->|Structured Weather Observation| Agent
    SearchTool -->|Attractions Observation| Agent
    
    Agent -->|6. Synthesize Observations| LLM
    LLM -->|7. Cohesive Travel Report| Executor
    Executor -->|8. Formatted Response| User
```

### How the Tool-Calling Loop Works:
1. **User Input**: The user inputs a destination city (e.g., *"Kyoto"*).
2. **Reasoning & Tool Selection**: The LLM receives the system prompt and tool definitions. It determines that answering requires both current weather conditions and top attractions.
3. **Parallel Tool Invocation**: The LLM generates structured tool-call requests for `get_current_weather` and `search_tourist_attractions`.
4. **Execution & Feedback**: `AgentExecutor` executes the Python functions, handles network/API logic, and injects observations back into the agent scratchpad.
5. **Synthesis**: The LLM synthesizes the observations into an organized, actionable itinerary and tailored recommendations.

---

## 🚀 Core Features

- **Standardized LangChain Tool-Calling**: Implemented strictly with LangChain's official `@tool` decorator, `create_tool_calling_agent`, and `AgentExecutor`.
- **Zero-Dependency Web Search**: DuckDuckGo search is integrated as the default search engine, enabling attractions retrieval out of the box without requiring paid or third-party search API keys. Tavily is supported as a high-precision alternative.
- **Resilient Weather Integration**: Direct integration with WeatherAPI.com with defensive error handling for invalid cities, rate limits, network timeouts, and authentication failures.
- **Strict Factual Grounding**: The agent prompt strictly instructs the LLM never to fabricate weather conditions or assert tool success if a tool call fails.
- **Multi-Provider LLM Support**: Native plug-and-play support for:
  - **Groq** (`llama-3.3-70b-versatile` — Recommended: free, high speed, excellent tool calling).
  - **OpenAI** (`gpt-4o-mini`).
  - **Google Gemini** (`gemini-1.5-flash` / `gemini-2.0-flash`).
- **Interactive Multi-Turn CLI**: Explore multiple destinations in a single continuous session with conversational history.
- **Diagnostic Mode**: Standalone tool verification flag (`--test-tools`) allowing instructors and evaluators to test tool mechanics independently without LLM credentials.

---

## 📁 Project Structure

```text
Intelligent-Travel-Assistant-AI/
├── .env.example                 # Configuration template with placeholder keys
├── .gitignore                   # Excludes API keys (.env), caches, virtualenvs
├── README.md                    # Detailed documentation and user guide
├── report.md                    # Academic assignment report
├── requirements.txt             # Mutual compatible package dependencies
├── travel_assistant.py          # Complete application code
├── package_submission.py        # Automated submission zip packaging script
└── tests/
    └── test_travel_assistant.py # Comprehensive unit and integration test suite
```

---

## 📦 Prerequisites

- **Operating System**: Windows 10/11, macOS, or Linux.
- **Python**: Python 3.10 to Python 3.14.
- **Internet Access**: Required for live API queries (WeatherAPI.com and search engine).

---

## 💻 Installation Guide

### 1. Clone or Open the Workspace
Open Windows PowerShell and navigate to the project directory:
```powershell
cd "d:\Projects\Analytics vidhya\Intelligent-Travel-Assistant-AI"
```

### 2. (Optional) Create and Activate a Virtual Environment
```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
```

### 3. Install Dependencies
Install all required libraries using pip:
```powershell
py -m pip install -r requirements.txt
```

---

## 🔑 API Key Setup

1. Copy `.env.example` to create your local `.env` configuration file:
   ```powershell
   Copy-Item .env.example .env
   ```
2. Open `.env` in any text editor and configure your credentials:

### 1. WeatherAPI.com (Required for Real Weather Data)
- Sign up for a free account at [https://www.weatherapi.com/](https://www.weatherapi.com/).
- Copy your API key from the dashboard and set:
  ```env
  WEATHERAPI_API_KEY=your_weatherapi_key_here
  ```

### 2. LLM Provider (Required for Agent Execution)
Choose your preferred LLM provider:
- **Groq (Recommended - Free & Fast)**:
  - Sign up at [https://console.groq.com/](https://console.groq.com/).
  - Generate an API key and update `.env`:
    ```env
    LLM_PROVIDER=groq
    GROQ_API_KEY=gsk_your_groq_api_key_here
    GROQ_MODEL=llama-3.3-70b-versatile
    ```
- **OpenAI (Alternative)**:
  - Obtain an API key from [https://platform.openai.com/](https://platform.openai.com/).
    ```env
    LLM_PROVIDER=openai
    OPENAI_API_KEY=sk-your_openai_api_key_here
    OPENAI_MODEL=gpt-4o-mini
    ```
- **Google Gemini (Alternative)**:
  - Obtain an API key from [https://aistudio.google.com/](https://aistudio.google.com/).
    ```env
    LLM_PROVIDER=gemini
    GEMINI_API_KEY=your_gemini_api_key_here
    GEMINI_MODEL=gemini-1.5-flash
    ```

### 3. Web Search Tool (Tourist Attractions)
- By default, `SEARCH_PROVIDER=duckduckgo` is enabled, which **requires no API key**.
- If you prefer Tavily, obtain a free key at [https://app.tavily.com/](https://app.tavily.com/) and set:
  ```env
  SEARCH_PROVIDER=tavily
  TAVILY_API_KEY=tvly-your_tavily_key_here
  ```

> ⚠️ **Security Warning**: Never commit or share your `.env` file. It is excluded via `.gitignore`.

---

## 🖥️ Usage & Execution

### 1. Interactive Command-Line Session
Run the assistant in interactive mode:
```powershell
py travel_assistant.py
```
Type any destination city (e.g. `Paris`, `Tokyo`, `Barcelona`) to receive live weather and attraction details. Type `exit` or `quit` to end the session.

### 2. Single-Query Non-Interactive Mode
To query a destination directly from the command line:
```powershell
py travel_assistant.py --city "Tokyo"
```

### 3. Verbose Tool Execution Logging
To inspect the LLM's tool calls, arguments, and intermediate observations in real time:
```powershell
py travel_assistant.py --city "Rome" --verbose
```

### 4. Standalone Tool Diagnostics (Zero LLM Keys Required)
To verify that the custom weather tool and web search tool function correctly without an LLM:
```powershell
py travel_assistant.py --test-tools
```

---

## 🧪 Testing & Diagnostics

A comprehensive automated test suite is provided in `tests/test_travel_assistant.py`.

Run the entire test suite using `pytest`:
```powershell
py -m pytest tests/test_travel_assistant.py -v
```

### Test Coverage Highlights:
- `test_empty_city_validation`: Confirms empty strings or spaces are rejected before tool execution.
- `test_missing_api_key`: Validates helpful error messages when `WEATHERAPI_API_KEY` is not set.
- `test_successful_weather_fetch`: Validates accurate parsing of temperature, conditions, wind, and humidity from WeatherAPI JSON.
- `test_invalid_city_not_found`: Validates HTTP 400 (code 1006) handling for non-existent cities.
- `test_authentication_error`: Validates HTTP 401/403 credential failure responses.
- `test_network_timeout`: Validates timeout resilience during network degradation.
- `test_live_attractions_search`: Performs live web search verification via DuckDuckGo.
- `test_agent_executor_creation_with_mock_llm`: Verifies binding of tools with `create_tool_calling_agent` and `AgentExecutor`.

---

## 📄 Sample Output (Illustrative)

Below is an illustrative transcript demonstrating the agent's synthesized response:

```text
+=====================================================================+
|                   INTELLIGENT TRAVEL ASSISTANT AI                   |
|             Powered by LangChain & Real-Time Tool Calling           |
+=====================================================================+

• Configuration Summary:
  - LLM Provider:       GROQ
  - Search Tool:        DUCKDUCKGO (attractions)
  - WeatherAPI Key:     CONFIGURED
-----------------------------------------------------------------------

Destination City > Tokyo

[AI Assistant] Researching travel details for: Tokyo...
[AI Assistant] Coordinating weather and tourist attraction tools...

=======================================================================
📍 Destination Overview: Tokyo, Japan
Tokyo is an electrifying metropolis that seamlessly merges ultramodern skyscrapers
and neon-lit districts with historic shrines and tranquil gardens.

🌤️ Current Weather & Forecast:
- Local Time: 2026-10-11 23:45
- Condition: Clear skies
- Temperature: 18.5°C (65.3°F)
- Feels Like: 17.8°C (64.0°F)
- Humidity: 60%
- Wind: 12.0 km/h from NE
- UV Index: 0.0 (Nighttime)

🏛️ Top Tourist Attractions & Must-Visit Sights:
• Senso-ji Temple: Tokyo's oldest and most sacred Buddhist temple, located in Asakusa.
• Shibuya Crossing & Hachiko Statue: The world-famous pedestrian scramble and iconic landmark.
• Tokyo Skytree: Panoramic observation deck offering breathtaking 360-degree city views.
• Meiji Jingu Shrine: A serene Shinto shrine nestled inside an expansive evergreen forest.
• Akihabara Electric Town: The global epicenter of electronics, anime, and gaming culture.

🎒 Practical Travel Advice & Weather Recommendations:
- Clothing: Mild evening conditions (18.5°C) make a light jacket or cardigan ideal for walking.
- Itinerary Planning: With clear weather, open-air night walks around Shibuya, Roppongi Hills,
  or the waterfront in Odaiba are highly recommended.
=======================================================================
```

---

## 🛡️ Error Handling & Edge Cases

| Scenario | System Behavior |
| :--- | :--- |
| **Missing WeatherAPI Key** | Reports clear notice with registration URL; avoids crashing; informs user that weather data cannot be fetched while still retrieving attractions. |
| **Invalid / Non-Existent City** | WeatherAPI error 1006 caught; agent informs user to verify spelling instead of hallucinating weather data. |
| **Network Timeout / Outage** | Catches `requests.exceptions.Timeout` and `ConnectionError`; returns fallback notification. |
| **Empty or Whitespace Input** | Input validation intercepts empty strings prior to tool execution. |
| **Missing LLM Key** | System outputs clear configuration error with provider-specific registration instructions. |

---

## ⚠️ Limitations & Future Enhancements

### Limitations:
- **Free WeatherAPI Tier**: WeatherAPI.com's free plan provides current weather and up to 3 days of forecast. Historical or long-range predictions require upgraded tiers.
- **DuckDuckGo Rate Limits**: DuckDuckGo search may occasionally rate-limit rapid successive queries from shared IP addresses. Tavily search provides a dedicated alternative.
- **Single-City Focus**: Designed for single city inquiries per turn. Multi-city complex routing could be implemented in future iterations.

### Future Enhancements:
- **Interactive Multi-Day Itinerary Generator**: Generating day-by-day itineraries based on hourly precipitation forecasts.
- **Flight and Hotel Integration**: Binding live booking tools via Google Flights or Amadeus API.
- **Speech Interface**: Adding speech-to-text (Whisper) and text-to-speech for audible travel guidance.

---

## 📜 License & Academic Integrity

This project is prepared for the **Analytics Vidhya / LangChain AI Agent Assignment**.
All source code and documentation are strictly authored for educational and assessment purposes.
