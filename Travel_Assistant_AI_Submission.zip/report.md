# Assignment Report: Building AI Agents with LangChain — Intelligent Travel Assistant AI

**Course / Topic**: Building AI Agents with LangChain  
**Project**: Intelligent Travel Assistant AI  
**Author**: Deepak Raj JS  
**Date**: October 2026  

---

## 1. Introduction and Objective

Modern travel planning is inherently multimodal and information-intensive. A traveler planning a visit to a city typically requires two fundamental categories of real-time intelligence:
1. **Dynamic Meteorological Information**: Current temperature, weather conditions, precipitation, humidity, and wind to plan packing and activity timing (e.g., whether to prioritize outdoor sightseeing or indoor museums).
2. **Curated Tourist Attractions**: Verified highlights, historic landmarks, architectural sites, and cultural venues that make the destination noteworthy.

Static language models (LLMs) trained on historical corpora suffer from two critical limitations when addressing this challenge: knowledge cutoffs and the inability to observe real-time environmental data. Relying on an LLM alone leads to hallucinations regarding present weather conditions or outdated recommendations regarding local venues.

### Primary Objective
The objective of this assignment is to design, implement, and evaluate an autonomous, tool-calling **Intelligent Travel Assistant AI** using the **LangChain** framework. The agent must:
- Accept any destination city from the user.
- Dynamically invoke a custom weather tool utilizing **WeatherAPI.com** to acquire live meteorological observations.
- Dynamically invoke a web search tool utilizing **DuckDuckGo** (or **Tavily**) to acquire verified tourist highlights and points of interest.
- Reason over user queries and coordinate tool execution through LangChain's official `create_tool_calling_agent` architecture and `AgentExecutor`.
- Synthesize the acquired observations into a coherent, structured, and factual travel report that strictly differentiates between real-time weather observations and travel recommendations.

---

## 2. Architecture and Tools Used

The system is architected as an autonomous agentic loop adhering to the Tool-Calling Agent paradigm.

```mermaid
graph TD
    subgraph User Interaction
        U[User] -->|Input: Destination City| CLI[Command Line Interface]
    end

    subgraph LangChain Agent Core
        CLI --> Prompt[ChatPromptTemplate]
        Prompt --> Agent[Tool-Calling Agent]
        Agent <-->|Structured Tool Schema & Selection| LLM[LLM: Groq / OpenAI / Gemini]
        Agent --> Executor[AgentExecutor]
    end

    subgraph External Tools & APIs
        Executor -->|Call| Tool1["Custom Weather Tool (@tool)<br/>get_current_weather"]
        Executor -->|Call| Tool2["Search Tool (@tool)<br/>search_tourist_attractions"]
        Tool1 -->|REST API Request| WAPI[WeatherAPI.com]
        Tool2 -->|Web Search Request| DDG[DuckDuckGo / Tavily]
        WAPI -->|JSON Response| Tool1
        DDG -->|Snippets| Tool2
    end

    subgraph Synthesis & Output
        Tool1 -->|Weather Observation| Executor
        Tool2 -->|Attractions Observation| Executor
        Executor --> Agent
        Agent -->|Final Synthesis| CLI
        CLI -->|Structured Travel Report| U
    end
```

### Components and Technologies:
1. **LangChain (`langchain`, `langchain-core`, `langchain-classic`)**:
   - `langchain_core.tools.tool`: Python decorator creating structured LangChain `BaseTool` instances with Pydantic type schemas and parameter descriptions.
   - `create_tool_calling_agent`: Constructs the decision pipeline binding the LLM's function-calling capabilities with tool definitions.
   - `AgentExecutor`: Manages the runtime execution loop, handles exceptions, manages intermediate scratchpads, and routes tool inputs/outputs.
2. **WeatherAPI.com REST API**:
   - High-precision meteorological provider supplying real-time weather, temperature, humidity, wind speed, UV index, and local timestamps.
3. **DuckDuckGo Search (`ddgs` / `DuckDuckGoSearchRun`)**:
   - Fast, privacy-respecting search engine integrated for real-time web discovery of tourist attractions with zero API-key overhead.
4. **LLM Provider Integration**:
   - Multi-provider support via `langchain-groq` (default: `llama-3.3-70b-versatile`), `langchain-openai` (`gpt-4o-mini`), and `langchain-google-genai` (`gemini-1.5-flash`), allowing flexible deployment.
5. **Configuration and Environment**:
   - `python-dotenv` for secure environment variable isolation (`.env.example`).

---

## 3. How the LLM Reasons About the Request and Selects Tools

In a traditional hardcoded script, execution flow is static: the developer writes code that calls the weather API first and the search API second, regardless of user intent. 

In contrast, the **Tool-Calling Agent** pattern delegates execution coordination to the LLM. 

### The Tool-Calling Mechanism:
1. **Tool Schema Exposure**:
   When tools are bound to the LLM via `create_tool_calling_agent`, each tool's name, docstring, and argument types are translated into a standardized function declaration schema (JSON Schema). For example:
   ```json
   {
     "name": "get_current_weather",
     "description": "Fetch current real-time weather information and forecast for a given destination city.",
     "parameters": {
       "type": "object",
       "properties": {
         "city": {"type": "string", "description": "Name of the city"}
       },
       "required": ["city"]
     }
   }
   ```
2. **Semantic Understanding of User Intent**:
   When a user submits a query such as:
   > *"I am planning a trip to Kyoto. What should I expect?"*
   the LLM evaluates the semantic requirements of the request against the declared descriptions of the tools available in its environment.
3. **Tool Selection and Parameter Generation**:
   The LLM determines that satisfying the request requires both real-time meteorological conditions and points of interest. Rather than immediately generating speculative prose, the LLM outputs a structured `tool_calls` payload:
   - Call `get_current_weather` with `{"city": "Kyoto"}`
   - Call `search_tourist_attractions` with `{"city": "Kyoto"}`
4. **Execution and Observation Cycle**:
   The `AgentExecutor` intercepts the model's tool calls, executes the underlying Python functions synchronously, and captures the resulting data as `ToolMessage` observations.
5. **Final Synthesis**:
   The observations are appended to the agent's scratchpad. The LLM receives the real data, performs synthesis, and outputs an organized response.

*Note on Internal Reasoning*: While we observe the LLM's inputs, selected tool calls, parameter arguments, and final outputs through execution logs, the model's internal parameter activations and latent representations are not directly observable. What is visible and verifiable is the resulting sequence of tool calls and the grounded factual output.

---

## 4. The Role of the Custom Weather and Attractions Search Tools

### 4.1 Custom Weather Tool (`get_current_weather`)
- **Implementation**: Created using LangChain's `@tool` decorator wrapping a Python function querying `https://api.weatherapi.com/v1/current.json`.
- **Defensive Error Handling**:
  - *Input Validation*: Immediately checks if the city parameter is empty or consists solely of whitespace.
  - *Missing Credentials*: Detects if `WEATHERAPI_API_KEY` is missing or contains template placeholders, returning a clear instructional notice.
  - *Invalid Location*: Parses HTTP 400 responses with error code `1006` ("No matching location found") and notifies the user to verify the city spelling.
  - *Authentication Failures*: Detects error codes `1002`, `2006`, and `2008` (invalid or disabled key).
  - *Quota Limits*: Detects error code `2009` (exceeded quota).
  - *Network Failures*: Catches `requests.exceptions.Timeout` and `ConnectionError` gracefully without terminating the application.
- **Data Formatting**: Normalizes JSON data into a clean, human-readable summary containing local time, condition, Celsius/Fahrenheit temperatures, feels-like temperatures, humidity, wind velocity, and UV index.

### 4.2 Tourist Attractions Search Tool (`search_tourist_attractions`)
- **Implementation**: Created using LangChain's `@tool` decorator.
- **Dual-Engine Search**:
  - *DuckDuckGo (Default)*: Directly uses the `ddgs` library and `DuckDuckGoSearchRun` fallback. Requires no API keys, eliminating onboarding friction.
  - *Tavily (Optional)*: Supports high-precision API-based search if `SEARCH_PROVIDER=tavily` and a valid `TAVILY_API_KEY` is present.
- **Role in Agent Architecture**: Provides live, up-to-date travel information including current operational statuses, iconic landmarks, top-rated museums, and district highlights.

---

## 5. Code and Execution Flow

The core application resides in `travel_assistant.py` and is organized into modular sections:

```
travel_assistant.py
├── Imports & Environment Setup (UTF-8 console config, load_dotenv)
├── Custom Weather Tool (@tool get_current_weather)
├── Attractions Search Tool (@tool search_tourist_attractions)
├── LLM Factory (get_llm: Groq, OpenAI, Gemini)
├── Agent Factory (create_travel_assistant_agent)
│   ├── ChatPromptTemplate (System, History, Human, Scratchpad)
│   ├── create_tool_calling_agent
│   └── AgentExecutor initialization
├── CLI Application Layer
│   ├── print_banner & check_configuration_status
│   ├── run_single_destination (execution & history tracking)
│   ├── run_interactive_session (multi-turn loop)
│   └── run_diagnostics (standalone tool testing)
└── Main Entry Point (CLI argument parsing)
```

### Detailed Execution Trace:
1. **Initialization**:
   - `travel_assistant.py` ensures UTF-8 stdout configuration for Windows compatibility.
   - `load_dotenv()` loads `.env` settings.
   - The user selects interactive mode or passes a city via `--city "<name>"`.
2. **Agent Construction**:
   - `get_llm()` verifies credentials and instantiates the selected chat model (e.g. `ChatGroq`).
   - `create_travel_assistant_agent()` binds `[get_current_weather, search_tourist_attractions]` to the LLM via `create_tool_calling_agent()`.
   - `AgentExecutor` wraps the agent with error handling and maximum iteration limits.
3. **Execution Loop**:
   - User enters `"Paris"`.
   - The query is dispatched to `executor.invoke({"input": ..., "chat_history": ...})`.
   - The LLM requests tool execution for `get_current_weather(city="Paris")` and `search_tourist_attractions(city="Paris")`.
   - The tools execute and return data.
   - The LLM evaluates the observations, constructs an organized response, and presents it through the CLI.

---

## 6. Testing Methodology and Actual Results

Testing was conducted across two distinct methodologies:
1. **Automated Unit & Integration Testing (`pytest`)**: Programmatic verification of edge cases, input validation, mocked network conditions, and tool bindings.
2. **Live Environmental Diagnostics (`--test-tools`)**: Direct testing against live external servers (DuckDuckGo and WeatherAPI).

### 6.1 Automated Pytest Execution Results
The test suite was executed via `py -m pytest tests/test_travel_assistant.py -v`. All 11 tests passed with 100% success rate:

```text
tests/test_travel_assistant.py::TestWeatherTool::test_authentication_error PASSED          [  9%]
tests/test_travel_assistant.py::TestWeatherTool::test_empty_city_validation PASSED         [ 18%]
tests/test_travel_assistant.py::TestWeatherTool::test_invalid_city_not_found PASSED        [ 27%]
tests/test_travel_assistant.py::TestWeatherTool::test_missing_api_key PASSED               [ 36%]
tests/test_travel_assistant.py::TestWeatherTool::test_network_timeout PASSED               [ 45%]
tests/test_travel_assistant.py::TestWeatherTool::test_successful_weather_fetch PASSED      [ 54%]
tests/test_travel_assistant.py::TestSearchTool::test_empty_city_validation PASSED         [ 63%]
tests/test_travel_assistant.py::TestSearchTool::test_live_attractions_search PASSED        [ 72%]
tests/test_travel_assistant.py::TestLLMAndAgent::test_agent_executor_creation_with_mock_llm PASSED [ 81%]
tests/test_travel_assistant.py::TestLLMAndAgent::test_missing_groq_key_raises_value_error PASSED    [ 90%]
tests/test_travel_assistant.py::TestLLMAndAgent::test_unsupported_provider_raises_value_error PASSED [100%]

======================== 11 passed, 1 warning in 5.99s ========================
```

### 6.2 Live Diagnostics Results (`travel_assistant.py --test-tools`)
Live tool diagnostics were executed on the local environment for destination `"Paris"`:
- **Search Tool Verification**: Successfully queried DuckDuckGo live servers without credentials. Accurately extracted attractions including the Eiffel Tower and Tripadvisor reviews.
- **Weather Tool Verification**: Evaluated with unconfigured/placeholder credentials. Correctly identified the missing API key, suppressed unhandled crashes, and printed clear user instructions pointing to `https://www.weatherapi.com/`.
- **Invalid City Handling**: Verified that invalid city input triggers informative error messages without throwing unhandled exceptions.

### 6.3 End-to-End Live Agent Testing Summary
- **Live Search**: Verified and working live.
- **Agent Architecture**: Verified and working live with mock LLM and tool binding.
- **Live Weather Data**: Verified via mocked HTTP tests and live error-handling tests. Live data retrieval requires the user to input their personal free API key into `.env`.

---

## 7. Limitations and Conclusion

### Limitations
1. **WeatherAPI Free Tier Bounds**:
   - The free plan from WeatherAPI.com provides current conditions and limited forecast windows. Multi-week seasonal trends are outside the scope of the free tier.
2. **Search Query Rate Limits**:
   - DuckDuckGo provides an unauthenticated interface. Rapid successive requests from high-traffic environments may occasionally encounter rate throttling.
3. **Single-City Scope**:
   - The assistant is optimized for exploring one destination at a time. Multi-city itinerary planning with cross-city travel logistics would require dedicated routing tools.

### Conclusion
The **Intelligent Travel Assistant AI** successfully meets all requirements of the assignment:
- Custom `@tool` implementation wrapping WeatherAPI.com with resilient error handling.
- Real-time tourist attraction discovery via DuckDuckGo and Tavily.
- Standardized LangChain tool-calling architecture using `create_tool_calling_agent` and `AgentExecutor`.
- Clean, multi-turn interactive command-line experience with strict factual grounding.
- Fully documented, modular, and reproducible codebase accompanied by automated tests and package submission.
