"""
Intelligent Travel Assistant AI
================================
A LangChain-powered travel assistant that coordinates multiple tools to fetch
real-time weather data and top tourist attractions for any destination city.

Built for the "Building AI Agents with LangChain" assignment.

Architecture:
- Weather Tool: Custom tool built with @tool decorator using WeatherAPI.com.
- Search Tool: Real-time web search for attractions using DuckDuckGo / Tavily.
- Agent: Tool-calling agent initialized via create_tool_calling_agent and AgentExecutor.
"""

import os
import sys
import argparse
from typing import List, Optional, Dict, Any
import requests
from dotenv import load_dotenv

# Ensure UTF-8 output encoding across Windows consoles
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Load environment variables from .env file
load_dotenv()

# LangChain Imports with dual-version compatibility (LangChain 0.2/0.3 and LangChain 1.x)
from langchain_core.tools import tool
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage

try:
    from langchain.agents import create_tool_calling_agent, AgentExecutor
except ImportError:
    from langchain_classic.agents import create_tool_calling_agent, AgentExecutor


# ==============================================================================
# 1. Custom Weather Tool (WeatherAPI.com)
# ==============================================================================

@tool
def get_current_weather(city: str) -> str:
    """Fetch current real-time weather information and forecast for a given destination city.

    Args:
        city: Name of the city (e.g. 'Paris', 'Tokyo', 'Rome').

    Returns:
        A structured string containing temperature, weather condition, humidity,
        wind speed, feels-like temperature, and local time, or an informative error message.
    """
    if not city or not city.strip():
        return "Error: Destination city name cannot be empty."

    cleaned_city = city.strip()
    api_key = os.getenv("WEATHERAPI_API_KEY") or os.getenv("WEATHER_API_KEY")

    if not api_key or api_key.strip() in ("", "your_weatherapi_key_here"):
        return (
            "Weather Tool Notice: WEATHERAPI_API_KEY is not configured or contains a placeholder. "
            "Please obtain a free API key from https://www.weatherapi.com/ and set it in your .env file."
        )

    endpoint = "https://api.weatherapi.com/v1/current.json"
    params = {
        "key": api_key.strip(),
        "q": cleaned_city,
        "aqi": "no",
    }

    try:
        response = requests.get(endpoint, params=params, timeout=10)
        data = response.json()

        if response.status_code == 200:
            loc = data.get("location", {})
            cur = data.get("current", {})
            condition = cur.get("condition", {}).get("text", "Unknown")

            return (
                f"Current Weather Data for {loc.get('name', cleaned_city)}, "
                f"{loc.get('region', '')} {loc.get('country', '')}:\n"
                f"- Local Time: {loc.get('localtime', 'N/A')}\n"
                f"- Condition: {condition}\n"
                f"- Temperature: {cur.get('temp_c')}°C ({cur.get('temp_f')}°F)\n"
                f"- Feels Like: {cur.get('feelslike_c')}°C ({cur.get('feelslike_f')}°F)\n"
                f"- Humidity: {cur.get('humidity')}%\n"
                f"- Wind: {cur.get('wind_kph')} km/h ({cur.get('wind_mph')} mph) from {cur.get('wind_dir', 'N/A')}\n"
                f"- UV Index: {cur.get('uv', 'N/A')}"
            )

        # Handle specific WeatherAPI error responses
        error_info = data.get("error", {})
        error_code = error_info.get("code")
        error_msg = error_info.get("message", response.text)

        if error_code == 1006:
            return f"Weather Error: Destination city '{cleaned_city}' was not found. Please verify the city spelling."
        elif error_code in (1002, 2006, 2008):
            return f"Weather Error: WeatherAPI authentication failed ({error_msg}). Please check your API key."
        elif error_code == 2009:
            return "Weather Error: WeatherAPI request quota has been exceeded."
        else:
            return f"Weather Error ({response.status_code}): {error_msg}"

    except requests.exceptions.Timeout:
        return f"Weather Error: Network request timed out while contacting WeatherAPI.com for '{cleaned_city}'."
    except requests.exceptions.ConnectionError:
        return "Weather Error: Network connection failure. Please check your internet connection."
    except requests.exceptions.RequestException as exc:
        return f"Weather Error: Request failed due to network exception: {str(exc)}"
    except Exception as exc:
        return f"Weather Error: Unexpected failure retrieving weather: {str(exc)}"


# ==============================================================================
# 2. Tourist Attractions Search Tool (DuckDuckGo / Tavily)
# ==============================================================================

@tool
def search_tourist_attractions(city: str) -> str:
    """Search for the top tourist attractions, famous landmarks, and interesting places to visit in a city.

    Args:
        city: The name of the destination city (e.g. 'Kyoto', 'Barcelona', 'New York').

    Returns:
        A compiled summary of top attractions, landmarks, and highlights for travelers.
    """
    if not city or not city.strip():
        return "Error: Destination city name cannot be empty."

    cleaned_city = city.strip()
    search_provider = os.getenv("SEARCH_PROVIDER", "duckduckgo").strip().lower()
    tavily_key = os.getenv("TAVILY_API_KEY", "").strip()

    # 1. Use Tavily if explicitly requested or if configured
    if search_provider == "tavily" and tavily_key and tavily_key != "your_tavily_api_key_here":
        try:
            from tavily import TavilyClient
            client = TavilyClient(api_key=tavily_key)
            query = f"top tourist attractions must visit landmarks in {cleaned_city}"
            result = client.search(query=query, search_depth="basic", max_results=5)
            snippets = [f"- {item.get('title')}: {item.get('content')}" for item in result.get("results", [])]
            if snippets:
                return f"Top Attractions in {cleaned_city} (via Tavily Search):\n" + "\n".join(snippets)
        except Exception as exc:
            # Fallback to DuckDuckGo if Tavily encounters an issue
            pass

    # 2. Use DuckDuckGo (Free, reliable, no API key required)
    query = f"top tourist attractions must see sights in {cleaned_city}"

    # Try ddgs directly first (latest standard package)
    try:
        from ddgs import DDGS
        ddgs = DDGS()
        results = list(ddgs.text(query, max_results=5))
        if results:
            formatted = []
            for item in results:
                title = item.get("title", "").strip()
                body = item.get("body", "").strip()
                if title and body:
                    formatted.append(f"• {title}: {body}")
            if formatted:
                return f"Top Tourist Attractions in {cleaned_city} (via DuckDuckGo):\n\n" + "\n\n".join(formatted)
    except Exception:
        pass

    # Fallback to DuckDuckGoSearchRun from langchain_community
    try:
        from langchain_community.tools import DuckDuckGoSearchRun
        search_tool = DuckDuckGoSearchRun()
        results_text = search_tool.invoke(query)
        if results_text and results_text.strip():
            return f"Top Tourist Attractions in {cleaned_city} (via DuckDuckGo Search):\n{results_text}"
    except Exception as exc:
        return (
            f"Search Tool Notice: Unable to retrieve live search results for '{cleaned_city}' ({str(exc)}). "
            "Please verify your internet connection or configure a valid TAVILY_API_KEY in .env."
        )

    return f"No search results found for attractions in '{cleaned_city}'."


# ==============================================================================
# 3. LLM Provider Setup
# ==============================================================================

def get_llm():
    """Initializes and returns the configured LLM provider instance with tool-calling capabilities."""
    provider = os.getenv("LLM_PROVIDER", "groq").strip().lower()

    if provider == "groq":
        api_key = os.getenv("GROQ_API_KEY", "").strip()
        if not api_key or api_key == "your_groq_api_key_here":
            raise ValueError(
                "Missing GROQ_API_KEY in environment or .env file.\n"
                "Please get a free Groq API key from https://console.groq.com/ and add it to your .env file."
            )
        model_name = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile").strip()
        from langchain_groq import ChatGroq
        return ChatGroq(api_key=api_key, model=model_name, temperature=0.2)

    elif provider == "openai":
        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        if not api_key or api_key == "your_openai_api_key_here":
            raise ValueError(
                "Missing OPENAI_API_KEY in environment or .env file.\n"
                "Please get an OpenAI API key from https://platform.openai.com/ and add it to your .env file."
            )
        model_name = os.getenv("OPENAI_MODEL", "gpt-4o-mini").strip()
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(api_key=api_key, model=model_name, temperature=0.2)

    elif provider in ("gemini", "google"):
        api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY", "").strip()
        if not api_key or api_key == "your_gemini_api_key_here":
            raise ValueError(
                "Missing GEMINI_API_KEY in environment or .env file.\n"
                "Please get a free Gemini API key from https://aistudio.google.com/ and add it to your .env file."
            )
        model_name = os.getenv("GEMINI_MODEL", "gemini-1.5-flash").strip()
        from langchain_google_genai import ChatGoogleGenerativeAI
        return ChatGoogleGenerativeAI(api_key=api_key, model=model_name, temperature=0.2)

    else:
        raise ValueError(
            f"Unsupported LLM_PROVIDER '{provider}'. "
            "Supported providers are 'groq', 'openai', or 'gemini'."
        )


# ==============================================================================
# 4. Travel Assistant Agent Construction
# ==============================================================================

def create_travel_assistant_agent(llm=None, verbose: bool = False) -> AgentExecutor:
    """Builds and returns the LangChain tool-calling Travel Assistant AgentExecutor.

    Args:
        llm: Optional LangChain chat model. If None, initialized from environment.
        verbose: Boolean flag controlling AgentExecutor debug logging.

    Returns:
        An initialized AgentExecutor ready to handle user destination requests.
    """
    if llm is None:
        llm = get_llm()

    # Tools available to the agent
    tools = [get_current_weather, search_tourist_attractions]

    # System prompt directing the LLM's tool calling and reasoning
    system_prompt = (
        "You are an expert, courteous Intelligent Travel Assistant AI.\n"
        "Your mission is to help travelers discover everything they need to know about their destination.\n\n"
        "Instructions:\n"
        "1. For any destination city requested by the user, coordinate BOTH tools:\n"
        "   - Call 'get_current_weather' to retrieve verified real-time weather information from WeatherAPI.com.\n"
        "   - Call 'search_tourist_attractions' to discover top landmarks, cultural sites, and tourist activities.\n"
        "2. Ground your final response strictly in the data returned by the tools:\n"
        "   - Keep real-time weather data distinct from travel recommendations.\n"
        "   - NEVER fabricate or guess temperature, precipitation, or weather conditions. If the weather tool "
        "returns an error or notes a missing API key, accurately disclose that to the user.\n"
        "3. Provide a clear, beautifully structured final response organized as:\n"
        "   - 📍 Destination Overview\n"
        "   - 🌤️ Current Weather & Forecast (temperature, condition, feels like, humidity, wind)\n"
        "   - 🏛️ Top Tourist Attractions & Must-Visit Sights (bulleted landmarks with brief descriptions)\n"
        "   - 🎒 Practical Travel Advice & Weather-Tailored Recommendations (clothing, indoor vs. outdoor tips)\n"
        "4. Maintain a warm, encouraging, professional tone."
    )

    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        MessagesPlaceholder(variable_name="chat_history", optional=True),
        ("human", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ])

    # Create the tool-calling agent using LangChain's official method
    agent = create_tool_calling_agent(llm=llm, tools=tools, prompt=prompt)

    # Bind into an AgentExecutor
    executor = AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=verbose,
        handle_parsing_errors=True,
        max_iterations=int(os.getenv("AGENT_MAX_ITERATIONS", "5")),
    )

    return executor


# ==============================================================================
# 5. Interactive CLI Application
# ==============================================================================

def print_banner():
    """Prints a clean, styled startup banner for the terminal application."""
    banner = """
+=====================================================================+
|                   INTELLIGENT TRAVEL ASSISTANT AI                   |
|             Powered by LangChain & Real-Time Tool Calling           |
+=====================================================================+
"""
    print(banner)


def check_configuration_status():
    """Displays the active configuration and available tool integrations."""
    weather_key = os.getenv("WEATHERAPI_API_KEY") or os.getenv("WEATHER_API_KEY")
    has_weather = bool(weather_key and weather_key.strip() != "your_weatherapi_key_here")

    provider = os.getenv("LLM_PROVIDER", "groq").lower()
    search_provider = os.getenv("SEARCH_PROVIDER", "duckduckgo").lower()

    print("• Configuration Summary:")
    print(f"  - LLM Provider:       {provider.upper()}")
    print(f"  - Search Tool:        {search_provider.upper()} (attractions)")
    print(f"  - WeatherAPI Key:     {'CONFIGURED' if has_weather else 'MISSING / PLACEHOLDER'}")
    if not has_weather:
        print("    [!] Tip: Sign up at https://www.weatherapi.com/ for a free key and add to .env")
    print("-" * 71)


def run_single_destination(executor: AgentExecutor, destination: str, chat_history: List[BaseMessage] = None):
    """Executes a single travel query through the agent and prints the result.

    Args:
        executor: The LangChain AgentExecutor instance.
        destination: City name entered by user.
        chat_history: Accumulated conversation history.
    """
    if chat_history is None:
        chat_history = []

    print(f"\n[AI Assistant] Researching travel details for: {destination}...")
    print("[AI Assistant] Coordinating weather and tourist attraction tools...\n")

    query = f"I am planning a trip to {destination}. Please provide the current weather and top tourist attractions to visit."

    try:
        result = executor.invoke({
            "input": query,
            "chat_history": chat_history,
        })

        output = result.get("output", "No response generated.")
        print("\n" + "=" * 71)
        print(output.strip())
        print("=" * 71 + "\n")

        # Update chat history
        chat_history.append(HumanMessage(content=query))
        chat_history.append(AIMessage(content=output))

    except Exception as exc:
        print(f"\n[Error executing travel agent]: {str(exc)}\n")


def run_interactive_session(executor: AgentExecutor):
    """Runs a multi-turn interactive command-line session."""
    chat_history: List[BaseMessage] = []

    print("\nEnter a destination city to explore (or type 'exit' / 'quit' to end session).")

    while True:
        try:
            user_input = input("\nDestination City > ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nExiting session. Safe travels!")
            break

        if not user_input:
            print("[!] Please enter a valid destination name (e.g. 'Paris', 'Tokyo', 'London').")
            continue

        if user_input.lower() in ("exit", "quit", "q", ":q"):
            print("\nThank you for using Intelligent Travel Assistant AI. Have a wonderful trip!")
            break

        if user_input.lower() in ("help", "?"):
            print("Commands:")
            print("  - Enter any city name (e.g., 'Rome', 'New York', 'Singapore') to get weather and attractions.")
            print("  - Type 'exit', 'quit', or 'q' to leave.")
            continue

        run_single_destination(executor, user_input, chat_history)


# ==============================================================================
# 6. Standalone Tool Diagnostic Mode
# ==============================================================================

def run_diagnostics(test_city: str = "Paris"):
    """Runs direct verification on individual tools without invoking the LLM."""
    print("\n" + "=" * 71)
    print(f"RUNNING INDEPENDENT TOOL DIAGNOSTICS FOR: '{test_city}'")
    print("=" * 71)

    print("\n--- Testing Custom Weather Tool ---")
    weather_result = get_current_weather.invoke({"city": test_city})
    print(weather_result)

    print("\n--- Testing Tourist Attractions Search Tool ---")
    search_result = search_tourist_attractions.invoke({"city": test_city})
    # Show first 500 characters of search result
    print(search_result[:500] + ("..." if len(search_result) > 500 else ""))

    print("\n--- Testing Invalid City Handling in Weather Tool ---")
    invalid_result = get_current_weather.invoke({"city": "NonExistentCityXYZ999"})
    print(invalid_result)

    print("\n" + "=" * 71)
    print("TOOL DIAGNOSTICS COMPLETE")
    print("=" * 71 + "\n")


# ==============================================================================
# 7. Main Entry Point
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Intelligent Travel Assistant AI - LangChain Tool-Calling Agent"
    )
    parser.add_argument(
        "--city",
        type=str,
        help="Specify a destination city directly to run a single query non-interactively.",
    )
    parser.add_argument(
        "--test-tools",
        action="store_true",
        help="Run independent diagnostics on Weather and Search tools without invoking LLM.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable detailed tool execution logging from AgentExecutor.",
    )

    args = parser.parse_args()

    print_banner()
    check_configuration_status()

    # Diagnostic mode
    if args.test_tools:
        city = args.city or "Paris"
        run_diagnostics(city)
        return

    # Check if agent can be initialized
    verbose_setting = args.verbose or os.getenv("AGENT_VERBOSE", "false").lower() in ("true", "1", "yes")

    try:
        executor = create_travel_assistant_agent(verbose=verbose_setting)
    except ValueError as val_err:
        print(f"\n[Configuration Error]:\n{val_err}\n")
        print("To run tool diagnostics without an LLM key, execute:")
        print("  python travel_assistant.py --test-tools\n")
        sys.exit(1)
    except Exception as exc:
        print(f"\n[Agent Initialization Error]: {exc}\n")
        sys.exit(1)

    # Single-shot command line mode
    if args.city:
        run_single_destination(executor, args.city)
        return

    # Interactive session loop
    run_interactive_session(executor)


if __name__ == "__main__":
    main()
