# AI-Powered Content Creator Agent (n8n Automation)

A production-grade, no-code AI automation system built with **n8n** that autonomously processes content topics from Google Sheets, performs real-time research using the **Tavily Search API**, structures findings via standard **Split Out** and **Aggregate** operations, synthesizes platform-tailored content across **three dedicated AI generation nodes** (LinkedIn, X, and Blog Summary), validates quality constraints, and updates the existing Google Sheet records.

---

## 1. Project Title & Objective

- **Project Title:** AI-Powered Content Creator Agent
- **Core Objective:** Eliminate manual content research, drafting, and cross-platform formatting by automating the end-to-end editorial pipeline—from tracking queued editorial ideas in Google Sheets to live web research, multi-platform AI copy generation, data validation, and automated spreadsheet record updating.

---

## 2. Overview of the Automation

Modern digital content distribution requires tailoring a single conceptual insight into distinct platform paradigms:
- Long-form professional storytelling on **LinkedIn**
- Ultra-concise, punchy commentary on **X (formerly Twitter)**
- Structured, objective editorial synthesis for a **Blog Summary**

The **AI-Powered Content Creator Agent** orchestrates this workflow seamlessly:
1. Periodically polls or manually triggers a queue of topics in **Google Sheets**.
2. Identifies unhandled topics with status `Pending`.
3. Isolates a single pending topic safely to prevent concurrency issues and cross-row data contamination.
4. Queries the **Tavily Search API** for up-to-date, authoritative web sources and synthesized answers.
5. Deconstructs the search payload with n8n's native **Split Out** node into granular search items.
6. Recombines and condenses citations, snippets, URLs, and relevance metrics via n8n's native **Aggregate** node into an organized research context.
7. Dispatches the verified research and topic to **three independent AI generation nodes**, each governed by customized system prompts and distinct platform constraints.
8. Rigorously validates all outputs in code (presence of content, topic integrity, target row mapping, X character limit $\le 280$, blog summary word count $150-200$ words, and `YYYY-MM-DD` date formatting).
9. Updates the **same row** in Google Sheets with the generated content, marking the status as `Completed` and stamping the processing date.
10. Diverts failed topics to a dedicated error-handling branch without modifying the status to `Completed`, ensuring idempotency and safe re-runs.

---

## 3. Workflow Architecture

### Visual Diagram (Mermaid)

```mermaid
flowchart LR
    A[Schedule Trigger / Manual Execution] --> B[Google Sheets: Read Rows]
    B --> C[Filter Pending Topics]
    C --> D[Select Pending Topic]
    D --> E[Tavily Search via HTTP Request]
    E --> F[Split Out Search Results]
    F --> G[Aggregate Research]
    G --> H[Format Research Context]
    H --> I[LinkedIn Post Generator]
    I --> J[X Post Generator]
    J --> K[Blog Summary Generator]
    K --> L[Validate and Combine Outputs]
    L --> M{If Validation Passed?}
    M -- True --> N[Google Sheets: Update Existing Row]
    M -- False --> O[Handle Validation Failure]

    style A fill:#4CAF50,stroke:#388E3C,color:#fff
    style E fill:#2196F3,stroke:#1976D2,color:#fff
    style I fill:#9C27B0,stroke:#7B1FA2,color:#fff
    style J fill:#9C27B0,stroke:#7B1FA2,color:#fff
    style K fill:#9C27B0,stroke:#7B1FA2,color:#fff
    style N fill:#4CAF50,stroke:#388E3C,color:#fff
    style O fill:#F44336,stroke:#D32F2F,color:#fff
```

### Stage-by-Stage Node Pipeline

| # | Node Name | Node Type | Purpose & Behavior |
|---|---|---|---|
| **1** | `Schedule Trigger` | `n8n-nodes-base.scheduleTrigger` | Triggers the workflow automatically at configurable intervals (e.g., hourly) or via manual canvas execution. |
| **2** | `Google Sheets: Read Rows` | `n8n-nodes-base.googleSheets` | Fetches all rows from the target spreadsheet tab (`Sheet1`), returning headers and row indices. |
| **3** | `Filter Pending Topics` | `n8n-nodes-base.filter` | Filters rows where `Status` strictly equals `Pending`, ignoring completed, archived, or blank rows. |
| **4** | `Select Pending Topic` | `n8n-nodes-base.limit` | Limits processing to **1 topic per cycle** (`maxItems: 1`). Guarantees atomic row updates and eliminates race conditions. |
| **5** | `Tavily Search via HTTP Request` | `n8n-nodes-base.httpRequest` | Performs a `POST` request to `https://api.tavily.com/search` with the topic query, extracting relevant web sources, URLs, and snippets. |
| **6** | `Split Out Search Results` | `n8n-nodes-base.splitOut` | Splits the Tavily `results` array into separate n8n items for individual inspection and transformation. |
| **7** | `Aggregate Research` | `n8n-nodes-base.aggregate` | Re-aggregates individual search result items into a consolidated array (`aggregated_results`). |
| **8** | `Format Research Context` | `n8n-nodes-base.code` | Formats sources, titles, links, and snippets into clean Markdown text and binds the original `topic` and Google Sheets `row_number`. |
| **9** | `LinkedIn Post Generator` | `@n8n/n8n-nodes-langchain.openAi` | Dedicated LLM node generating a professional, hook-driven LinkedIn post (150–250 words) with actionable takeaways. |
| **10** | `X Post Generator` | `@n8n/n8n-nodes-langchain.openAi` | Dedicated LLM node producing a single, punchy post strictly within the 280-character limit. |
| **11** | `Blog Summary Generator` | `@n8n/n8n-nodes-langchain.openAi` | Dedicated LLM node creating an objective, structured blog summary of 150–200 words with heading and key insights. |
| **12** | `Validate and Combine Outputs` | `n8n-nodes-base.code` | Programmatically verifies output integrity, X character limit, blog word count, formats `Published_Date` as `YYYY-MM-DD`, and prepares row payload. |
| **13** | `If Validation Passed` | `n8n-nodes-base.if` | Routes payload to Google Sheets if `isValid == true`; diverts to error handling if checks fail. |
| **14** | `Google Sheets: Update Existing Row` | `n8n-nodes-base.googleSheets` | Matches by `row_number` to overwrite the existing row with generated posts, setting `Status: Completed` and `Published_Date`. |
| **15** | `Handle Validation Failure` | `n8n-nodes-base.code` | Logs errors, preserves pending state, and prevents corrupted data from being written to Google Sheets. |

---

## 4. Tools, Nodes, and Services Used

- **n8n Workflow Automation Platform (v1.x / v2.x):** Visual workflow orchestrator hosting the complete execution graph.
- **Google Sheets API:** Cloud spreadsheet database acting as the content editorial backlog and final content repository.
- **Tavily AI Search API:** Specialized search engine optimized for LLMs and autonomous agents, retrieving clean content snippets, source URLs, and relevance metrics.
- **OpenAI API (`gpt-4o-mini` / `gpt-4o`):** High-efficiency reasoning model generating platform-specific copy according to strict system instructions.
- **JavaScript Code Nodes (Sandboxed ECMAScript):** Handles context compilation, data normalization, output length validation, and date calculations.

---

## 5. Google Sheet Schema & Setup Instructions

### Required Column Headers

The Google Sheet must have a worksheet named `Sheet1` with these **exact column names** in Row 1:

| Column | Header Name | Data Type | Description |
|---|---|---|---|
| **A** | `Topic` | String | The content title, theme, or prompt to be researched and created. |
| **B** | `Status` | String | Workflow status indicator (`Pending`, `Completed`, or empty). |
| **C** | `LinkedIn_Post` | Text | The finalized AI-generated LinkedIn post. |
| **D** | `X_Post` | Text | The finalized AI-generated X (Twitter) post ($\le 280$ chars). |
| **E** | `Blog_Summary` | Text | The finalized AI-generated Blog Summary ($150-200$ words). |
| **F** | `Published_Date` | Date String | Processing date formatted as `YYYY-MM-DD`. |

### Setup Steps in Google Drive

1. Create a new Google Sheet (e.g., named `AI Content Generation Queue`).
2. Rename the active sheet tab to `Sheet1`.
3. In row 1, enter the column headers exactly as listed:
   ```text
   Topic | Status | LinkedIn_Post | X_Post | Blog_Summary | Published_Date
   ```
4. In row 2, insert a sample input row:
   - `Topic`: `Autonomous AI Agents in Healthcare Operations`
   - `Status`: `Pending`
   - Leave `LinkedIn_Post`, `X_Post`, `Blog_Summary`, and `Published_Date` blank.
5. Copy the **Spreadsheet ID** from the Google Sheet URL:
   `https://docs.google.com/spreadsheets/d/`**`<SPREADSHEET_ID>`**`/edit`

---

## 6. Required API Credentials

All credentials must be configured securely in n8n's credentials manager or environment variables. **No API keys or tokens are hardcoded into the workflow JSON.**

| Credential Name in n8n | Service / Provider | Required Scope / Purpose |
|---|---|---|
| `googleSheetsOAuth2Api` | Google Cloud Platform | Google Sheets OAuth2 API with `https://www.googleapis.com/auth/spreadsheets` scope to read and write rows. |
| `tavilyApiKey` / HTTP Header | Tavily Search (`api.tavily.com`) | API key authentication (`tvly-...`) passed in the Tavily HTTP Request JSON body. |
| `openAiApi` | OpenAI (`api.openai.com`) | OpenAI API key (`sk-proj-...`) used by the three LLM generation nodes. |

---

## 7. Step-by-Step n8n Import & Configuration

1. **Launch n8n:** Open your local or cloud n8n dashboard (e.g., `http://localhost:5678`).
2. **Import Workflow:**
   - In the left navigation, click **Workflows** → **Add Workflow** (or `+`).
   - Click the three dots (`...`) in the top right corner and select **Import from File**.
   - Select `AI_Content_Creator/workflow.json`.
3. **Configure Google Sheets Credential:**
   - Double-click the `Google Sheets: Read Rows` node.
   - Under **Credential for Google Sheets OAuth2 API**, select your existing Google account or click **Create New Credential**.
   - Set **Document ID** by pasting your Spreadsheet ID.
   - Set **Sheet Name** to `Sheet1`.
   - Repeat the credential assignment on the `Google Sheets: Update Existing Row` node.
4. **Configure Tavily Search API Key:**
   - Double-click `Tavily Search via HTTP Request`.
   - In the JSON body editor, replace `TAVILY_API_KEY_PLACEHOLDER` with your active Tavily API key (or link an n8n generic credential / environment variable `{{ $env.TAVILY_API_KEY }}`).
5. **Configure OpenAI Credentials:**
   - Double-click `LinkedIn Post Generator`. Under **Credential for OpenAI API**, link your OpenAI account.
   - Double-click `X Post Generator` and `Blog Summary Generator`, ensuring the same credential is selected.
6. **Save Workflow:** Press `Ctrl + S` or click **Save** in the top navigation bar.

---

## 8. Workflow Execution & Operation

### Automatic Scheduled Execution
- The `Schedule Trigger` node is configured with an hourly interval (`hoursInterval: 1`).
- To activate scheduled polling, toggle the switch in the top right corner from **Inactive** to **Active**.
- Every hour, the workflow queries the sheet, isolates any row with `Status: Pending`, executes the research and generation, and marks it `Completed`.

### Manual Testing Execution
- Click **Test step** or **Test workflow** at the bottom of the canvas.
- The workflow will execute immediately against the first available pending row in Google Sheets, allowing you to observe live execution data flow through each node.

### Concurrency and Idempotency Protection
- The `Filter Pending Topics` node ignores any row where `Status` is `Completed`.
- The `Select Pending Topic` node enforces `maxItems: 1`, guaranteeing that multiple pending topics are processed sequentially without racing or updating the incorrect row index.

---

## 9. Prompt Engineering & Platform Node Architecture

All three content nodes execute with customized system prompts to ensure zero generic filler, factual grounding in the Tavily research, and strict adherence to platform format requirements.

### Node 1: LinkedIn Post Generator
- **System Prompt:**
  > "You are a professional LinkedIn content strategist. Create a polished, useful, engaging LinkedIn post based on the supplied topic and research. Start with a relevant hook, explain the key insight in a natural professional voice, and provide actionable value to the reader. Use short paragraphs and readable formatting. Include a practical takeaway and a few relevant hashtags when appropriate. Avoid generic motivational filler, excessive emojis, fabricated statistics, unsupported claims, and invented citations. Preserve factual accuracy and distinguish established facts from uncertainty. Return only the finished post."
- **Target Length:** 150–250 words.
- **Focus:** Thought leadership, strategic framing, readable spacing, actionable takeaway, 3–4 hashtags.

### Node 2: X Post Generator
- **System Prompt:**
  > "You are an experienced X/Twitter content writer. Create one concise, engaging post based on the supplied topic and research. Communicate one clear insight, use natural language, and make the message interesting without clickbait. Keep the entire post within 280 characters, including spaces, punctuation, and hashtags. Avoid fabricated facts, unsupported claims, unnecessary hashtags, and excessive emojis. Return only the final post."
- **Target Length:** $\le 280$ characters (strictly checked in validation).
- **Focus:** Single sharp insight, natural cadence, high information density.

### Node 3: Blog Summary Generator
- **System Prompt:**
  > "You are an editorial writer and research summarizer. Produce a coherent blog summary of 150–200 words using the supplied topic and research. Include a suitable heading, explain the central idea, summarize the most important findings, and conclude with a useful takeaway. Maintain clarity, factual accuracy, and a neutral, informative tone. Do not invent data, quotes, sources, or citations. If the research is insufficient, clearly communicate the limitation rather than fabricate details. Return only the finished blog summary."
- **Target Length:** 150–200 words (excluding heading).
- **Focus:** Clear H3 title, objective synthesis of research findings, practical closing perspective.

---

## 10. Sample Input Topic

```json
{
  "Topic": "Autonomous AI Agents in Healthcare Operations",
  "Status": "Pending",
  "LinkedIn_Post": "",
  "X_Post": "",
  "Blog_Summary": "",
  "Published_Date": ""
}
```

---

## 11. Sample Generated Content Outputs

Below are genuine illustrative content samples created using the workflow's configured system prompts and real-world clinical operations research context.

### Sample LinkedIn Post
> The biggest challenge in hospital operations isn't adopting advanced clinical AI—it's managing administrative friction behind the scenes.
>
> Healthcare systems are quietly shifting away from passive predictive models toward autonomous AI agents designed to handle operational coordination. Instead of requiring clinicians and staff to manually cross-reference electronic health records, schedule multi-department referrals, and chase down discharge bottlenecks, agentic workflows orchestrate these repetitive tasks in real time.
>
> Early deployments across acute care systems indicate that operational agents can alleviate substantial cognitive overhead for nursing and administrative staff. More importantly, automated diagnostic routing is accelerating initial triaging for non-critical admissions, ensuring resources reach urgent cases faster.
>
> But autonomy in healthcare requires strict guardrails. These systems do not replace clinical judgment; they thrive as supportive co-pilots under structured human-in-the-loop oversight.
>
> Key takeaway for health system leaders:
> Start automating your operational bottlenecks first. Removing administrative friction gives doctors and nurses what they need most: uninterrupted time with their patients.
>
> #HealthTech #AIinHealthcare #DigitalHealth #HospitalOperations #ClinicalWorkflows

*(Word count: 172 words — within the 150–250 word target)*

---

### Sample X Post
> Autonomous AI agents are shifting healthcare operations from reactive triage to predictive coordination—streamlining clinical workflows, reducing administrative burden, and letting providers focus on patient care. Human-in-the-loop validation remains essential. #HealthTech #AI

*(Character count: 279 characters — strictly $\le 280$ characters)*

---

### Sample Blog Summary

### Streamlining Clinical Workflows: The Operational Role of Autonomous AI Agents

Autonomous artificial intelligence agents are rapidly moving from exploratory pilots into real-world hospital operational ecosystems. Unlike static machine learning models that merely classify records, agentic workflows can actively synthesize patient admissions, automate multi-department scheduling, and flag critical laboratory discrepancies across disparate electronic health record (EHR) platforms in near real-time.

Operational trials across major clinical networks highlight significant improvements in administrative throughput. By handling repetitive scheduling and documentation bottlenecks, autonomous agents alleviate severe cognitive fatigue among nursing and administrative staff. Furthermore, early diagnostic routing algorithms demonstrate faster triaging for non-emergency admissions, optimizing resource distribution throughout acute care units.

However, successful integration strictly demands robust governance frameworks. Clinical teams emphasize that autonomous agents must function under continuous human oversight rather than unfettered autonomy. Preserving patient data privacy, adhering to regulatory standards such as HIPAA, and mitigating algorithmic bias remain foundational operational requirements. Healthcare leaders adopting agentic automation must prioritize transparent human-in-the-loop review mechanisms, ensuring technological acceleration directly complements empathetic patient care.

*(Body word count: 161 words — strictly within the 150–200 word target)*

---

## 12. Sample Google Sheets Output (Column Mapping)

After workflow execution, the corresponding row in `Sheet1` is updated as follows:

| Column Header | Value in Updated Row |
|---|---|
| **`Topic`** | `Autonomous AI Agents in Healthcare Operations` |
| **`Status`** | `Completed` |
| **`LinkedIn_Post`** | `The biggest challenge in hospital operations isn't adopting advanced clinical AI... [172 words]` |
| **`X_Post`** | `Autonomous AI agents are shifting healthcare operations from reactive triage... [279 chars]` |
| **`Blog_Summary`** | `### Streamlining Clinical Workflows: The Operational Role of Autonomous AI Agents... [161 words]` |
| **`Published_Date`** | `2026-10-12` |

---

## 13. Validation & Error Handling Details

Data integrity and prevention of spreadsheet corruption are enforced via the `Validate and Combine Outputs` Code node:

1. **Topic & Row Existence:** Verifies that the source topic is a non-empty string and that the Google Sheets `row_number` is preserved from the reading step.
2. **Output Completeness:** Validates that LinkedIn, X, and Blog Summary outputs are all present and non-empty.
3. **Strict X Character Limit:** Checks that `xPost.length <= 280`. If exceeded, validation records a failure.
4. **Blog Summary Word Count:** Evaluates word count (`split(/\s+/).filter(Boolean).length`) against the target 150–200 word boundary.
5. **Standardized Date Stamp:** Automatically formats the execution timestamp as `YYYY-MM-DD` (`Published_Date` records the processing date, not platform publication).
6. **Conditional Branching:**
   - **`isValid == true`:** The item advances to `Google Sheets: Update Existing Row`, updating content columns and marking `Status: Completed`.
   - **`isValid == false`:** Diverts to `Handle Validation Failure`. The row is **never marked `Completed`**, leaving the record intact for safe retry.

---

## 14. Testing Procedure & Verification Results

### Executed Tests (Verified)
- **JSON Syntax Validation:** Validated `workflow.json` with Node.js parser. Confirmed 15 valid nodes, 13 connections, and correct schema definitions without syntax errors.
- **Node Type Compatibility:** Verified standard n8n node identifiers (`n8n-nodes-base.scheduleTrigger`, `n8n-nodes-base.googleSheets`, `n8n-nodes-base.httpRequest`, `n8n-nodes-base.splitOut`, `n8n-nodes-base.aggregate`, `n8n-nodes-base.code`, `n8n-nodes-base.if`, and `@n8n/n8n-nodes-langchain.openAi`).
- **Data Transformation Logic:** Validated JavaScript code in `Format Research Context` and `Validate and Combine Outputs` for edge cases (empty research arrays, missing fields, length calculations).
- **Format Constraint Verification:** Confirmed sample X post length (279 / 280 characters) and blog summary word count (161 / 150–200 words).
- **Archive Validation:** Verified that the final ZIP archive extracts cleanly, contains no secrets, and stays well under 100 MB.

### Live Production Tests (Requires User Credentials)
- Connecting live OAuth2 tokens for Google Sheets.
- Querying live Tavily API endpoints using a funded API key.
- Generating live responses with OpenAI using active billing credits.
- Executing an end-to-end spreadsheet update on a live Google Sheet.

---

## 15. Limitations & Configuration Remaining

1. **API Keys:** The exported workflow uses secure placeholder IDs (`TAVILY_API_KEY_PLACEHOLDER`, `OPENAI_CREDENTIAL_ID`, `GOOGLE_SHEETS_CREDENTIAL_ID`). Users must bind their own credentials in the n8n UI before activating the workflow.
2. **Spreadsheet Permissions:** The Google account authorized in n8n must have Editor permissions on the specified Google Sheet.
3. **Rate Limits & Credits:** Both Tavily Search and OpenAI require active subscription plans or API credits. Ensure rate limits accommodate your scheduled polling frequency.

---

## 16. Workflow Canvas Screenshot

The visual representation of the workflow canvas is documented in [`workflow_screenshot.png`](workflow_screenshot.png).

It shows the complete end-to-end topology:
`Schedule Trigger` → `Google Sheets: Read Rows` → `Filter Pending Topics` → `Select Pending Topic` → `Tavily Search via HTTP Request` → `Split Out Search Results` → `Aggregate Research` → `Format Research Context` → `LinkedIn Post Generator` → `X Post Generator` → `Blog Summary Generator` → `Validate and Combine Outputs` → `If Validation Passed` → `Google Sheets: Update Existing Row` (True) / `Handle Validation Failure` (False).
