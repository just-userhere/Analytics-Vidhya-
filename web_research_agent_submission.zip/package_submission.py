"""
Submission packager utility for Web Research AI Agent assignment.
Creates a clean ZIP archive excluding secrets, caches, and virtual environments.
"""

import os
import zipfile

IGNORED_NAMES = {
    ".env",
    ".env.local",
    "__pycache__",
    ".pytest_cache",
    ".git",
    "venv",
    ".venv",
    "web_research_agent.zip",
}

IGNORED_EXTENSIONS = {".pyc", ".pyo", ".zip"}


def create_submission_zip(output_zip: str = "web_research_agent_submission.zip") -> str:
    root_dir = os.path.dirname(os.path.abspath(__file__))
    zip_path = os.path.join(root_dir, output_zip)

    files_added = []
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for dirpath, dirnames, filenames in os.walk(root_dir):
            # Prune ignored directories
            dirnames[:] = [d for d in dirnames if d not in IGNORED_NAMES and not d.startswith(".pytest")]

            for filename in filenames:
                if filename in IGNORED_NAMES or any(filename.endswith(ext) for ext in IGNORED_EXTENSIONS):
                    continue
                # Exclude secret .env files but retain .env.example
                if filename in {".env", ".env.local"} or filename.endswith(".env"):
                    continue

                full_path = os.path.join(dirpath, filename)
                rel_path = os.path.relpath(full_path, root_dir)
                zf.write(full_path, arcname=rel_path)
                files_added.append(rel_path)

    print(f"Created submission archive: {zip_path}")
    print(f"Packaged {len(files_added)} files:")
    for f in sorted(files_added):
        print(f"  + {f}")

    return zip_path


if __name__ == "__main__":
    create_submission_zip()
