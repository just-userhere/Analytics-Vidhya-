"""
Comprehensive Test Suite for Web Research AI Agent.

Covers:
- Topic validation and empty input handling
- LLM response parsing (JSON arrays, markdown blocks, numbered lists)
- Planning question count constraints (5-6 questions)
- Tavily search execution, structured parsing, and exception handling
- URL deduplication across questions in Act & Observe phase
- Partial search failures and empty result resilience
- Report synthesis and evidence grounding
- End-to-end ReAct pipeline execution with mocked components
- Missing API credential configuration errors
- Verification that sensitive secrets are not exposed in state or outputs
- CLI argument parsing validation
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import pytest

# Ensure workspace root is in python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from agent import (
    BaseLLMClient,
    ConfigurationError,
    GroqLLMClient,
    GeminiLLMClient,
    PlanningError,
    QuestionResearch,
    ResearchState,
    SearchResult,
    SynthesisError,
    TavilySearchTool,
    ToolExecutionError,
    WebResearchAgent,
    build_parser,
    get_llm_client,
)


# ==============================================================================
# Test Fixtures & Mocks
# ==============================================================================

class MockLLMClient(BaseLLMClient):
    """Mock LLM client returning predetermined strings."""

    def __init__(self, plan_response: Optional[str] = None, report_response: Optional[str] = None):
        self.plan_response = plan_response or json.dumps([
            "What is the foundational architecture of the topic?",
            "What recent technological milestones have emerged?",
            "What are the leading enterprise applications in production?",
            "What scalability and security challenges remain unresolved?",
            "How do regulatory frameworks impact future deployment?",
        ])
        self.report_response = report_response or (
            "# Research Report: Autonomous Systems\n\n"
            "## Introduction\nAutonomous systems represent a critical advancement.\n\n"
            "## Findings\nGroundbreaking progress reported in [TechCrunch](https://techcrunch.com/article1).\n\n"
            "## Conclusion\nContinued research is required."
        )
        self.call_count = 0
        self.prompts: List[str] = []

    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> str:
        self.call_count += 1
        self.prompts.append(prompt)
        if "collected evidence dossier" in prompt.lower() or "report requirements" in prompt.lower():
            return self.report_response
        if "generate exactly 5 to 6" in prompt.lower() or "research plan" in str(system_prompt).lower():
            return self.plan_response
        return self.report_response


class MockTavilySearchTool(TavilySearchTool):
    """Mock search tool returning predictable SearchResult items."""

    def __init__(self, canned_results: Optional[Dict[str, List[SearchResult]]] = None):
        # Do not call super().__init__ to avoid requiring TAVILY_API_KEY
        self.api_key = "mock_tavily_key"
        self.client = MagicMock()
        self.canned_results = canned_results or {}
        self.queries_received: List[str] = []

    def search(
        self,
        query: str,
        max_results: int = 4,
        search_depth: str = "basic",
    ) -> List[SearchResult]:
        self.queries_received.append(query)
        if query in self.canned_results:
            return self.canned_results[query]

        # Default standard results
        return [
            SearchResult(
                title=f"Resource on {query[:25]}",
                url=f"https://example.org/study-{abs(hash(query)) % 1000}",
                content=f"Detailed evidence snippet for query: {query}",
                score=0.92,
            )
        ]


# ==============================================================================
# 1. Planning Phase & Topic Validation Tests
# ==============================================================================

def test_empty_or_whitespace_topic_raises_planning_error():
    """Agent must reject empty or whitespace-only research topics."""
    agent = WebResearchAgent(llm_client=MockLLMClient())
    with pytest.raises(PlanningError, match="cannot be empty"):
        agent.reason_and_plan("")
    with pytest.raises(PlanningError, match="cannot be empty"):
        agent.reason_and_plan("   \t\n  ")


def test_missing_llm_client_raises_configuration_error():
    """Agent must raise ConfigurationError if LLM client is None."""
    agent = WebResearchAgent(llm_client=None)
    with pytest.raises(ConfigurationError, match="LLM client is not initialized"):
        agent.reason_and_plan("Quantum Computing")


def test_question_parsing_from_clean_json_array():
    """Parser must extract questions directly from a JSON list."""
    llm = MockLLMClient(
        plan_response=json.dumps([
            "What is quantum key distribution?",
            "How do post-quantum algorithms function?",
            "What are recent NIST standards for PQC?",
            "How does Shor's algorithm impact RSA encryption?",
            "What is the timeline for cryptographically relevant quantum computers?",
        ])
    )
    agent = WebResearchAgent(llm_client=llm)
    questions = agent.reason_and_plan("Quantum Cryptography")
    assert len(questions) == 5
    assert "What is quantum key distribution?" in questions[0]


def test_question_parsing_from_markdown_code_block():
    """Parser must extract JSON questions when wrapped in ```json ... ``` code fence."""
    raw = """```json
[
  "What are autonomous AI agents?",
  "How does the ReAct pattern orchestrate reasoning and action?",
  "What are the most popular multi-agent frameworks?",
  "How is tool use and function calling handled in LLMs?",
  "What are the latency bottlenecks in agentic workflows?",
  "What safety guardrails are needed for autonomous agents?"
]
```"""
    agent = WebResearchAgent(llm_client=MockLLMClient(plan_response=raw))
    questions = agent.reason_and_plan("Agentic Workflows")
    assert len(questions) == 6
    assert questions[1] == "How does the ReAct pattern orchestrate reasoning and action?"


def test_question_parsing_from_numbered_list():
    """Parser should handle fallback line-by-line numbered formats."""
    raw = """
1. What is the fundamental architecture of modern vision models?
2. How do vision-language models handle multi-modal fusion?
3. What benchmarks evaluate spatial reasoning in VLMs?
4. What are the key compute constraints in training large vision models?
5. How are vision agents being deployed in robotic manipulation?
"""
    agent = WebResearchAgent(llm_client=MockLLMClient(plan_response=raw))
    questions = agent.reason_and_plan("Vision Language Models")
    assert len(questions) == 5
    assert "fundamental architecture" in questions[0]


def test_planning_insufficient_questions_raises_error():
    """If the LLM returns fewer than 5 valid questions, PlanningError must be raised."""
    raw = json.dumps(["Only question 1?", "Only question 2?"])
    agent = WebResearchAgent(llm_client=MockLLMClient(plan_response=raw))
    with pytest.raises(PlanningError, match="5-6 are required"):
        agent.reason_and_plan("Topic with too few questions")


def test_planning_caps_excess_questions_to_six():
    """If the LLM returns more than 6 questions, it must be capped at 6."""
    raw = json.dumps([f"Research question number {i}?" for i in range(1, 10)])
    agent = WebResearchAgent(llm_client=MockLLMClient(plan_response=raw))
    questions = agent.reason_and_plan("Broad Topic")
    assert len(questions) == 6


# ==============================================================================
# 2. Acting & Observing (Tavily Search) Tests
# ==============================================================================

def test_tavily_search_success_with_mocked_client():
    """TavilySearchTool should format results into SearchResult dataclasses."""
    with patch("tavily.TavilyClient") as mock_tavily_cls:
        mock_instance = MagicMock()
        mock_instance.search.return_value = {
            "results": [
                {
                    "title": "NIST Selects Post-Quantum Cryptography Algorithms",
                    "url": "https://www.nist.gov/news-events/news/2024/08/pqc",
                    "content": "NIST announces the primary post-quantum cryptographic standards.",
                    "score": 0.98,
                },
                {
                    "title": "Quantum Resistance Overview",
                    "url": "https://example.com/pqc-overview",
                    "content": "An overview of lattice-based cryptography.",
                    "score": 0.85,
                },
            ]
        }
        mock_tavily_cls.return_value = mock_instance

        tool = TavilySearchTool(api_key="tvly-mock-key")
        results = tool.search("Post-Quantum Cryptography", max_results=2)

        assert len(results) == 2
        assert isinstance(results[0], SearchResult)
        assert results[0].title == "NIST Selects Post-Quantum Cryptography Algorithms"
        assert results[0].url == "https://www.nist.gov/news-events/news/2024/08/pqc"
        assert results[0].score == 0.98


def test_tavily_search_empty_query():
    """Empty query should return empty list without calling API."""
    with patch("tavily.TavilyClient"):
        tool = TavilySearchTool(api_key="tvly-mock-key")
        results = tool.search("   ")
        assert results == []


def test_tavily_search_handles_api_failure():
    """TavilySearchTool should catch API exceptions and raise ToolExecutionError."""
    with patch("tavily.TavilyClient") as mock_tavily_cls:
        mock_instance = MagicMock()
        mock_instance.search.side_effect = RuntimeError("Rate limit exceeded 429")
        mock_tavily_cls.return_value = mock_instance

        tool = TavilySearchTool(api_key="tvly-mock-key")
        with pytest.raises(ToolExecutionError, match="Tavily search API failed"):
            tool.search("Failing Query")


def test_act_and_observe_deduplication():
    """Agent must deduplicate identical URLs across queries."""
    shared_result = SearchResult(
        title="Comprehensive AI Survey",
        url="https://arxiv.org/abs/2401.00001",
        content="Deep analysis of AI agent frameworks.",
        score=0.95,
    )
    unique_result = SearchResult(
        title="Benchmarks for Agents",
        url="https://github.com/agents-benchmark",
        content="Evaluation benchmark repository.",
        score=0.91,
    )

    search_tool = MockTavilySearchTool(
        canned_results={
            "Question 1": [shared_result],
            "Question 2": [shared_result, unique_result],  # Contains duplicate
        }
    )
    agent = WebResearchAgent(search_tool=search_tool)
    observations = agent.act_and_observe(["Question 1", "Question 2"])

    assert len(observations) == 2
    # Question 1 got the shared URL
    assert len(observations[0].results) == 1
    assert observations[0].results[0].url == "https://arxiv.org/abs/2401.00001"

    # Question 2 deduplicated the shared URL and kept only the unique one
    assert len(observations[1].results) == 1
    assert observations[1].results[0].url == "https://github.com/agents-benchmark"


def test_act_and_observe_handles_partial_failures_gracefully():
    """Agent must continue executing remaining searches if one question query fails."""
    class FlakySearchTool(TavilySearchTool):
        def __init__(self):
            self.api_key = "flaky_key"
            self.client = MagicMock()

        def search(self, query: str, max_results: int = 4, search_depth: str = "basic") -> List[SearchResult]:
            if "flaky" in query.lower():
                raise RuntimeError("503 Service Temporarily Unavailable")
            if "empty" in query.lower():
                return []
            return [
                SearchResult(
                    title=f"Result for {query}",
                    url=f"https://source.com/{abs(hash(query))}",
                    content=f"Findings on {query}",
                )
            ]

    agent = WebResearchAgent(search_tool=FlakySearchTool())
    questions = ["Working question A", "Flaky question B", "Empty question C"]
    results = agent.act_and_observe(questions)

    assert len(results) == 3
    assert results[0].status == "success"
    assert len(results[0].results) == 1

    assert results[1].status == "failed"
    assert "503 Service" in results[1].error_message
    assert len(results[1].results) == 0

    assert results[2].status == "no_results"
    assert len(results[2].results) == 0


# ==============================================================================
# 3. Report Synthesis & Evidence Grounding Tests
# ==============================================================================

def test_synthesize_report_includes_evidence_and_returns_markdown():
    """Synthesizer must pass collected sources to LLM prompt and return markdown."""
    mock_llm = MockLLMClient()
    agent = WebResearchAgent(llm_client=mock_llm)

    research_data = [
        QuestionResearch(
            question="What is the ReAct pattern?",
            status="success",
            results=[
                SearchResult(
                    title="ReAct: Synergizing Reasoning and Acting in Language Models",
                    url="https://arxiv.org/abs/2210.03629",
                    content="ReAct prompts LLMs to generate reasoning traces and task-specific actions.",
                )
            ],
        )
    ]

    report = agent.synthesize_report("ReAct AI Agents", research_data)
    assert isinstance(report, str)
    assert "# Research Report" in report

    # Verify that the LLM prompt contained the exact URL and title
    assert len(mock_llm.prompts) == 1
    sent_prompt = mock_llm.prompts[0]
    assert "https://arxiv.org/abs/2210.03629" in sent_prompt
    assert "ReAct: Synergizing Reasoning and Acting" in sent_prompt


# ==============================================================================
# 4. End-to-End ReAct Pipeline Tests
# ==============================================================================

def test_full_react_pipeline_execution(tmp_path):
    """End-to-end execution of Reason -> Act -> Observe -> Continue -> Synthesize."""
    output_file = str(tmp_path / "test_report.md")
    llm = MockLLMClient()
    search = MockTavilySearchTool()

    agent = WebResearchAgent(
        llm_client=llm,
        search_tool=search,
        max_results_per_query=3,
    )

    state = agent.run("State of AI Agents in 2026", output_path=output_file)

    assert isinstance(state, ResearchState)
    assert state.topic == "State of AI Agents in 2026"
    assert len(state.questions) == 5
    assert len(state.research_data) == 5
    assert all(q.status == "success" for q in state.research_data)
    assert len(state.unique_sources) >= 5

    # Check output file on disk
    assert os.path.exists(output_file)
    with open(output_file, "r", encoding="utf-8") as f:
        content = f.read()
    assert "# Research Report" in content
    assert "Autonomous Systems" in content


# ==============================================================================
# 5. Configuration & Security Tests
# ==============================================================================

def test_missing_credentials_raise_configuration_error(monkeypatch):
    """Clients must raise clear ConfigurationError when required API keys are missing."""
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("TAVILY_API_KEY", raising=False)

    with pytest.raises(ConfigurationError, match="GROQ_API_KEY is not set"):
        GroqLLMClient()

    with pytest.raises(ConfigurationError, match="GEMINI_API_KEY is not set"):
        GeminiLLMClient()

    with pytest.raises(ConfigurationError, match="TAVILY_API_KEY is not set"):
        TavilySearchTool()


def test_secrets_are_not_exposed_in_data_representations():
    """Verify that API keys are not leaked in string or dictionary representations."""
    secret_key = "tvly-secret-production-key-998877"
    with patch("tavily.TavilyClient"):
        tool = TavilySearchTool(api_key=secret_key)
        # Verify str/repr of tool doesn't expose key
        assert secret_key not in str(tool.__dict__.get("client"))

    result = SearchResult(
        title="Public Title",
        url="https://public-url.com",
        content="Public content",
    )
    result_dict = result.to_dict()
    assert "key" not in str(result_dict).lower()


# ==============================================================================
# 6. CLI Argument Parsing Tests
# ==============================================================================

def test_cli_parser_defaults_and_overrides():
    """CLI parser must set proper defaults and handle custom flags."""
    parser = build_parser()

    # Default values
    default_args = parser.parse_args([])
    assert default_args.topic is None
    assert default_args.output == "research_report.md"
    assert default_args.provider is None
    assert default_args.depth == "basic"
    assert default_args.max_results == 4

    # Custom arguments
    custom_args = parser.parse_args([
        "--topic", "Autonomous Driving Systems",
        "--output", "custom_report.md",
        "--provider", "gemini",
        "--model", "gemini-2.5-flash",
        "--depth", "advanced",
        "--max-results", "6",
    ])
    assert custom_args.topic == "Autonomous Driving Systems"
    assert custom_args.output == "custom_report.md"
    assert custom_args.provider == "gemini"
    assert custom_args.model == "gemini-2.5-flash"
    assert custom_args.depth == "advanced"
    assert custom_args.max_results == 6
