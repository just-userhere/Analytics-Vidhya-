# Web Research AI Agent (ReAct Pattern)

An autonomous Web Research AI Agent built from scratch in Python implementing the **ReAct (Reasoning + Acting)** pattern. The agent accepts an arbitrary user-defined research topic, breaks it down into structured research questions using an LLM, executes targeted live web searches using the Tavily Search API, observes and deduplicates findings, and synthesizes a citation-grounded Markdown research report.

---

## 1. Assignment Objective

The objective of this project is to build an autonomous research agent using the ReAct architectural framework:
- **Reason / Plan**: Formulate targeted investigative research questions from a broad topic.
- **Act**: Query the Tavily Web Search API to retrieve relevant web sources.
- **Observe**: Inspect, deduplicate, and organize the retrieved titles, URLs, and snippet evidence.
- **Continue**: Iteratively process research questions and tolerate partial search failures.
- **Synthesize**: Ground the final technical report strictly in verified web observations, linking claims to source URLs.

---

## 2. ReAct Pattern in This Implementation

The **ReAct** (Reasoning + Acting) paradigm coordinates large language model reasoning with external tool execution in an explicit, observable loop:

```
+-----------------------------------------------------------------------------+
|                               USER TOPIC                                    |
+-----------------------------------------------------------------------------+
                                      |
                                      v
+-----------------------------------------------------------------------------+
| 1. REASON / PLAN (LLM Planning Phase)                                       |
|    - Decomposes the topic into 5-6 multi-faceted research questions.        |
|    - Ensures coverage of concepts, technology, applications, risks, future. |
+-----------------------------------------------------------------------------+
                                      |
                                      v
                  +---------------------------------------+
                  |  FOR EACH QUESTION (Iterative Loop)   |
                  +---------------------------------------+
                                      |
                                      v
+-----------------------------------------------------------------------------+
| 2. ACT (Tool Execution)                                                     |
|    - Invokes TavilySearchTool with query, depth, and max_results.           |
+-----------------------------------------------------------------------------+
                                      |
                                      v
+-----------------------------------------------------------------------------+
| 3. OBSERVE (Observation & Deduplication)                                    |
|    - Normalizes URLs and eliminates duplicate sources.                      |
|    - Extracts title, snippet, and relevance score.                          |
|    - Records query status ("success", "no_results", "failed").              |
+-----------------------------------------------------------------------------+
                                      |
                                      v
+-----------------------------------------------------------------------------+
| 4. CONTINUE                                                                 |
|    - Gracefully isolates errors, continuing to process remaining questions. |
+-----------------------------------------------------------------------------+
                                      |
                                      v
+-----------------------------------------------------------------------------+
| 5. SYNTHESIZE (LLM Grounded Synthesis)                                      |
|    - Compiles collected observations into an Evidence Dossier.              |
|    - Instructs LLM to write a comprehensive report with genuine hyperlinks. |
|    - Explicitly identifies evidence gaps and search limitations.            |
+-----------------------------------------------------------------------------+
                                      |
                                      v
+-----------------------------------------------------------------------------+
|                     OUTPUT: research_report.md                              |
+-----------------------------------------------------------------------------+
```

### No Hidden Chain-of-Thought
Rather than claiming access to private internal model thoughts, our implementation surfaces observable execution logs at each step:
- `[ACT]` logs the exact query dispatched to the Tavily search tool.
- `[OBSERVE]` logs the retrieved titles, URLs, and status counts.
- `[SYNTHESIZE]` logs the compilation of evidence into the final document.

---

## 3. Project Architecture and Data Flow

### Directory Structure
```
Building AI Agents from Scratch/
├── agent.py                     # Core Agent, LLM clients, Tavily tool, and CLI
├── requirements.txt             # Minimal required Python dependencies
├── .env.example                 # Environment configuration template
├── .gitignore                   # Excludes .env, caches, venvs, and secrets
├── README.md                    # Complete technical and execution documentation
├── research_report.md           # Generated research report
├── web_research_agent/          # Package wrapper
│   ├── __init__.py
│   └── agent.py
└── tests/                       # Unit test suite
    ├── __init__.py
    └── test_agent.py
```

### Key Python Classes and Data Structures

1. **`BaseLLMClient` & `GroqLLMClient` / `GeminiLLMClient`**:
   - Clean provider abstraction with error handling for API connection, authentication, and rate-limiting errors.
   - Groq is configured as the default provider (`llama-3.3-70b-versatile`), offering high throughput and low latency.
   - Google Gemini is supported via the official `google-genai` SDK (`gemini-2.5-flash`).

2. **`TavilySearchTool`**:
   - Encapsulates Tavily Python SDK calls.
   - Converts raw JSON payloads into structured `SearchResult` instances (`title`, `url`, `content`, `score`).
   - Handles connection errors and empty query inputs safely.

3. **`WebResearchAgent`**:
   - Orchestrates the full lifecycle: `reason_and_plan()`, `act_and_observe()`, and `synthesize_report()`.
   - Maintains an in-memory `ResearchState` containing timestamps, questions, structured search observations, and deduplicated sources.

---

## 4. Detailed Stage Explanations

### A. Planning Phase (Why LLM is Used)
A raw topic (e.g., *"Quantum Computing in Cryptography"*) is too broad for a single web query. If searched as a single phrase, search engines return generic landing pages.

The LLM is prompted as an academic strategist to decompose the topic into **5–6 distinct, targeted research questions** exploring:
1. Core architecture and technical definitions.
2. Current state-of-the-art and recent breakthroughs.
3. Real-world applications and production deployments.
4. Security challenges, scalability bottlenecks, or ethical concerns.
5. Future directions and industry implications.

The response parser accepts standard JSON arrays as well as fallback markdown code blocks and numbered lists, validating that 5–6 questions are obtained.

### B. Acting Phase (Tavily Web Search)
For each research question, the agent executes an independent tool call using `TavilySearchTool.search()`.
- Search depth is configurable (`basic` or `advanced`).
- Maximum results per query defaults to 4, preventing context bloating while ensuring multi-source coverage.
- If a query fails (network disruption or rate limit), the error is isolated into `QuestionResearch.error_message` while subsequent queries proceed.

### C. Observing Phase (Deduplication & Organization)
As results arrive:
- URLs are normalized (removing fragment anchors and trailing slashes) and checked against a session set of `seen_urls`.
- Duplicate links across queries are stripped so the synthesis context remains high-density and diverse.
- If no results return, the state is flagged as `"no_results"`.

### D. Synthesis Phase (Report Generation)
The collected evidence is assembled into an evidence dossier containing only real titles, URLs, and snippet texts. The LLM is then invoked with strict grounding instructions:
- Every factual claim must be backed by the retrieved evidence.
- Every citation must use valid Markdown hyperlink syntax: `[Source Title](URL)`.
- Hallucinated URLs, invented statistics, or fabricated quotes are strictly prohibited.
- Gaps in the retrieved evidence must be stated transparently in the **Limitations** section.

---

## 5. Installation and Setup (Windows)

### Prerequisites
- Python 3.10+ (Verified on Python 3.14.6)
- Git (optional)

### 1. Clone or Open Workspace
Navigate to the project root directory:
```powershell
cd "d:\Projects\Analytics vidhya\Building AI Agents from Scratch"
```

### 2. Install Dependencies
Install all required packages using pip:
```powershell
pip install -r requirements.txt
```

### 3. Configure API Credentials
Copy `.env.example` to `.env`:
```powershell
Copy-Item .env.example .env
```
Open `.env` in any text editor and fill in your API credentials:
```ini
# Required: Tavily Search API key (from https://app.tavily.com/)
TAVILY_API_KEY=tvly-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Default LLM: Groq (from https://console.groq.com/)
LLM_PROVIDER=groq
GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
GROQ_MODEL=llama-3.3-70b-versatile

# Alternative LLM: Google Gemini (from https://aistudio.google.com/)
# GEMINI_API_KEY=AIzaxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
# GEMINI_MODEL=gemini-2.5-flash
```

> **Security Note**: Never commit your `.env` file to version control. The `.gitignore` file is configured to exclude all `.env` files.

---

## 6. Execution Instructions

### Run Interactively
If run without arguments, the agent will prompt for a topic:
```powershell
python agent.py
```

### Run with Command-Line Arguments
```powershell
# Specify a topic directly
python agent.py --topic "The Impact of Quantum Computing on Modern Cryptography"

# Specify a custom output file and advanced search depth
python agent.py --topic "Autonomous AI Agents in Healthcare" --output "healthcare_agents_report.md" --depth advanced

# Use Google Gemini as the LLM provider
python agent.py --topic "Post-Quantum Cryptography" --provider gemini
```

### Available CLI Options
| Flag | Short | Default | Description |
|------|-------|---------|-------------|
| `--topic` | `-t` | Interactive prompt | Research topic to investigate |
| `--output` | `-o` | `research_report.md` | Path for saving the generated Markdown report |
| `--provider` | `-p` | `groq` | LLM provider (`groq` or `gemini`) |
| `--model` | `-m` | Provider default | Override model identifier |
| `--depth` | `-d` | `basic` | Tavily search depth (`basic` or `advanced`) |
| `--max-results` | `-k` | `4` | Max search results per question |

---

## 7. Running the Test Suite

The test suite thoroughly validates core logic offline using mocked LLM and Tavily responses, verifying that no network access or live credentials are required to verify the implementation.

Execute pytest with verbose output:
```powershell
python -m pytest tests/ -v
```

### Tested Scenarios
- Topic validation (empty and whitespace input rejection).
- LLM response parsing (JSON arrays, markdown fences, numbered lists).
- Constraint enforcement (5–6 questions).
- Tavily search result extraction and error handling.
- URL deduplication across search queries.
- Resilient recovery from partial search query failures.
- Evidence dossier construction and synthesis grounding.
- Full end-to-end ReAct execution.
- Configuration error handling when API keys are missing.
- Security verification ensuring API keys are never leaked in state dictionaries or logs.
- CLI argument parsing defaults and overrides.

---

## 8. Limitations & Best Practices

1. **API Rate Limits and Quotas**:
   - Tavily's free tier provides 1,000 requests per month. Each topic run performs 5–6 queries.
   - Groq provides generous free tier rate limits (e.g. 30 requests/minute for Llama 3.3).
2. **Search Depth vs. Latency**:
   - `basic` search depth is fast and adequate for most academic and technical topics.
   - `advanced` search depth retrieves more detailed full-content extractions but requires slightly longer response times.
3. **Web Freshness**:
   - Search quality depends on public internet indexing. Internal corporate wikis or firewalled academic papers may yield limited public snippets. Any missing information is documented in the report's Limitations section.
