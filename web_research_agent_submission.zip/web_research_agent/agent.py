"""
Entry point for web_research_agent package.
Enables execution via: python web_research_agent/agent.py
"""

import os
import sys

# Add project root to sys.path so agent can be imported
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from agent import main

if __name__ == "__main__":
    sys.exit(main())
