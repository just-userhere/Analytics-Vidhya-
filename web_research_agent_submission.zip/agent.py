"""
Web Research AI Agent using the ReAct (Reasoning + Acting) Pattern.

Architecture:
1. Reason / Plan: LLM decomposes research topic into 5-6 structured research questions.
2. Act: Agent queries the Tavily Web Search API for each generated question.
3. Observe: Agent inspects, structures, deduplicates, and validates search results.
4. Continue: Agent processes all questions, handling partial failures and empty results gracefully.
5. Synthesize: LLM synthesizes evidence-grounded research report with genuine source citations.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv

# Load environment variables from .env file if present
load_dotenv()


# ==============================================================================
# Custom Exceptions
# ==============================================================================

class AgentError(Exception):
    """Base exception for Web Research Agent errors."""
    pass


class ConfigurationError(AgentError):
    """Raised when environment variables or API keys are missing/invalid."""
    pass


class PlanningError(AgentError):
    """Raised when the LLM planning phase fails to produce valid questions."""
    pass


class ToolExecutionError(AgentError):
    """Raised when an external tool (e.g., Tavily) fails to execute."""
    pass


class SynthesisError(AgentError):
    """Raised when the report synthesis phase fails."""
    pass


# ==============================================================================
# Data Structures
# ==============================================================================

@dataclass
class SearchResult:
    """Represents a single retrieved search result."""
    title: str
    url: str
    content: str
    score: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "url": self.url,
            "content": self.content,
            "score": self.score,
        }


@dataclass
class QuestionResearch:
    """Holds the research query, execution status, and collected results."""
    question: str
    results: List[SearchResult] = field(default_factory=list)
    status: str = "pending"  # "success", "no_results", "failed"
    error_message: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "question": self.question,
            "status": self.status,
            "results_count": len(self.results),
            "results": [r.to_dict() for r in self.results],
            "error_message": self.error_message,
        }


@dataclass
class ResearchState:
    """Encapsulates the complete state of a research session."""
    topic: str
    questions: List[str] = field(default_factory=list)
    research_data: List[QuestionResearch] = field(default_factory=list)
    unique_sources: Dict[str, str] = field(default_factory=dict)  # URL -> Title
    start_time: str = ""
    end_time: str = ""
    report_markdown: str = ""


# ==============================================================================
# LLM Provider Abstraction
# ==============================================================================

class BaseLLMClient:
    """Abstract base class for LLM providers."""

    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> str:
        raise NotImplementedError("Subclasses must implement generate()")


class GroqLLMClient(BaseLLMClient):
    """Groq API client implementation."""

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or os.getenv("GROQ_API_KEY")
        if not self.api_key or not self.api_key.strip():
            raise ConfigurationError(
                "GROQ_API_KEY is not set. Please set it in your .env file or environment variables."
            )
        self.model = model or os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
        try:
            from groq import Groq
            self.client = Groq(api_key=self.api_key)
        except ImportError as exc:
            raise ConfigurationError(
                "The 'groq' package is not installed. Run 'pip install groq'."
            ) from exc

    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> str:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.3,
            )
            content = response.choices[0].message.content
            if not content:
                raise SynthesisError("Groq returned an empty response.")
            return content.strip()
        except Exception as exc:
            error_name = type(exc).__name__
            raise SynthesisError(f"Groq API call failed [{error_name}]: {exc}") from exc


class GeminiLLMClient(BaseLLMClient):
    """Google Gemini API client implementation using google-genai."""

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key or not self.api_key.strip():
            raise ConfigurationError(
                "GEMINI_API_KEY is not set. Please set it in your .env file or environment variables."
            )
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        try:
            from google import genai
            self.client = genai.Client(api_key=self.api_key)
        except ImportError as exc:
            raise ConfigurationError(
                "The 'google-genai' package is not installed. Run 'pip install google-genai'."
            ) from exc

    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> str:
        try:
            contents = prompt
            if system_prompt:
                contents = f"{system_prompt}\n\nUser Request:\n{prompt}"
            response = self.client.models.generate_content(
                model=self.model,
                contents=contents,
            )
            text = getattr(response, "text", "")
            if not text:
                raise SynthesisError("Gemini returned an empty response.")
            return text.strip()
        except Exception as exc:
            error_name = type(exc).__name__
            raise SynthesisError(f"Gemini API call failed [{error_name}]: {exc}") from exc


def get_llm_client(
    provider: Optional[str] = None,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
) -> BaseLLMClient:
    """
    Factory function to instantiate the configured LLM client.
    Defaults to Groq, with support for Gemini.
    """
    resolved_provider = (provider or os.getenv("LLM_PROVIDER") or "").strip().lower()

    # Auto-detect if provider not explicitly specified
    if not resolved_provider:
        if os.getenv("GROQ_API_KEY") or (api_key and "gsk_" in api_key):
            resolved_provider = "groq"
        elif os.getenv("GEMINI_API_KEY"):
            resolved_provider = "gemini"
        else:
            resolved_provider = "groq"  # Default fallback

    if resolved_provider == "groq":
        return GroqLLMClient(api_key=api_key, model=model)
    elif resolved_provider in ("gemini", "google"):
        return GeminiLLMClient(api_key=api_key, model=model)
    else:
        raise ConfigurationError(
            f"Unsupported LLM provider '{resolved_provider}'. Supported options: 'groq', 'gemini'."
        )


# ==============================================================================
# Tavily Web Search Tool
# ==============================================================================

class TavilySearchTool:
    """Tool for executing web searches using the Tavily Python SDK."""

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("TAVILY_API_KEY")
        if not self.api_key or not self.api_key.strip():
            raise ConfigurationError(
                "TAVILY_API_KEY is not set. Please set it in your .env file or environment variables."
            )
        try:
            from tavily import TavilyClient
            self.client = TavilyClient(api_key=self.api_key)
        except ImportError as exc:
            raise ConfigurationError(
                "The 'tavily-python' package is not installed. Run 'pip install tavily-python'."
            ) from exc

    def search(
        self,
        query: str,
        max_results: int = 4,
        search_depth: str = "basic",
    ) -> List[SearchResult]:
        """
        Executes a web search query via Tavily and extracts structured results.
        Returns a list of SearchResult objects.
        """
        if not query or not query.strip():
            return []

        try:
            response = self.client.search(
                query=query.strip(),
                max_results=max_results,
                search_depth=search_depth,
            )
        except Exception as exc:
            error_name = type(exc).__name__
            raise ToolExecutionError(f"Tavily search API failed [{error_name}]: {exc}") from exc

        raw_results = response.get("results", []) if isinstance(response, dict) else []
        results: List[SearchResult] = []

        for item in raw_results:
            if not isinstance(item, dict):
                continue
            title = (item.get("title") or "Untitled Document").strip()
            url = (item.get("url") or "").strip()
            content = (item.get("content") or item.get("snippet") or "").strip()
            score = float(item.get("score") or 0.0)

            if url and content:
                results.append(SearchResult(
                    title=title,
                    url=url,
                    content=content,
                    score=score,
                ))

        return results


# ==============================================================================
# ReAct Web Research Agent
# ==============================================================================

class WebResearchAgent:
    """
    Autonomous Web Research Agent implementing the ReAct pattern:
    - Reason: Decomposes a research topic into 5-6 targeted questions.
    - Act: Queries Tavily web search tool for each question.
    - Observe: Analyzes, deduplicates, and organizes search results.
    - Continue: Iterates through plan, tolerating partial failures.
    - Synthesize: Produces a fully grounded Markdown report with source links.
    """

    def __init__(
        self,
        llm_client: Optional[BaseLLMClient] = None,
        search_tool: Optional[TavilySearchTool] = None,
        max_results_per_query: int = 4,
        search_depth: str = "basic",
    ):
        self.llm_client = llm_client
        self.search_tool = search_tool
        self.max_results_per_query = max_results_per_query
        self.search_depth = search_depth
        self.state: Optional[ResearchState] = None

    # --------------------------------------------------------------------------
    # 1. Reason / Plan Phase
    # --------------------------------------------------------------------------
    def reason_and_plan(self, topic: str) -> List[str]:
        """
        Uses the LLM to generate 5-6 structured, diverse research questions
        covering core definitions, technological architecture, real-world
        applications, key challenges/risks, and future outlook.
        """
        if not topic or not topic.strip():
            raise PlanningError("Research topic cannot be empty.")

        if self.llm_client is None:
            raise ConfigurationError("LLM client is not initialized.")

        system_prompt = (
            "You are an expert academic research strategist. Your task is to formulate "
            "a comprehensive research plan by breaking down a topic into exactly 5 to 6 "
            "well-scoped, distinct research questions."
        )

        prompt = (
            f"Topic: {topic.strip()}\n\n"
            "Generate exactly 5 to 6 distinct, structured research questions that explore:\n"
            "1. Fundamentals, definitions, and core architectural components.\n"
            "2. Current state of technology and recent breakthroughs.\n"
            "3. Practical real-world applications, case studies, or implementations.\n"
            "4. Critical challenges, bottlenecks, security, or ethical considerations.\n"
            "5. Future outlook, emerging trends, or industry implications.\n\n"
            "Formatting Requirements:\n"
            "- Return ONLY a JSON list of strings (e.g. [\"Question 1?\", \"Question 2?\", ...]).\n"
            "- Do not include markdown code block quotes, commentary, or extra text."
        )

        try:
            raw_response = self.llm_client.generate(prompt=prompt, system_prompt=system_prompt)
        except Exception as exc:
            raise PlanningError(f"Failed to generate research questions from LLM: {exc}") from exc

        questions = self._parse_questions(raw_response)
        if len(questions) < 5:
            # Fallback parsing or validation
            raise PlanningError(
                f"LLM produced {len(questions)} valid questions, but 5-6 are required. "
                f"Raw response was: {raw_response[:200]}"
            )

        # Cap at 6 questions if LLM generated more
        validated_questions = questions[:6]
        return validated_questions

    def _parse_questions(self, text: str) -> List[str]:
        """
        Extracts questions from raw LLM output, supporting JSON arrays,
        numbered lists, and markdown bullet points.
        """
        cleaned = text.strip()

        # Attempt 1: Direct JSON parse
        try:
            data = json.loads(cleaned)
            if isinstance(data, list):
                result = [str(q).strip() for q in data if str(q).strip()]
                if result:
                    return result
        except json.JSONDecodeError:
            pass

        # Attempt 2: Extract JSON array from markdown code fence
        json_match = re.search(r"\[\s*\"(?:\\.|[^\"])*\"(?:\s*,\s*\"(?:\\.|[^\"])*\")*\s*\]", cleaned, re.DOTALL)
        if json_match:
            try:
                data = json.loads(json_match.group(0))
                if isinstance(data, list):
                    result = [str(q).strip() for q in data if str(q).strip()]
                    if result:
                        return result
            except json.JSONDecodeError:
                pass

        # Attempt 3: Line-by-line parsing for numbered lists or bullets
        lines = cleaned.splitlines()
        extracted: List[str] = []
        for line in lines:
            line = line.strip()
            # Match "1. ...", "1) ...", "- ...", "* ...", "> ..."
            cleaned_line = re.sub(r"^(\d+[\.\)]|\*|\-|\>)\s*", "", line).strip()
            # Strip enclosing quotes if present
            cleaned_line = re.sub(r"^[\"']|[\"']$", "", cleaned_line).strip()
            if len(cleaned_line) > 10 and (cleaned_line.endswith("?") or not cleaned_line.endswith(".")):
                extracted.append(cleaned_line)

        return extracted

    # --------------------------------------------------------------------------
    # 2. Act & Observe Phase
    # --------------------------------------------------------------------------
    def act_and_observe(self, questions: List[str]) -> List[QuestionResearch]:
        """
        Executes Tavily web search for each research question, observing and
        filtering results while deduplicating URLs.
        """
        if self.search_tool is None:
            raise ConfigurationError("Tavily search tool is not initialized.")

        research_data: List[QuestionResearch] = []
        seen_urls: set[str] = set()

        for idx, question in enumerate(questions, 1):
            print(f"\n[ACT {idx}/{len(questions)}] Querying Tavily: \"{question}\"")
            item = QuestionResearch(question=question)

            try:
                raw_results = self.search_tool.search(
                    query=question,
                    max_results=self.max_results_per_query,
                    search_depth=self.search_depth,
                )

                # Deduplicate and validate
                unique_for_question: List[SearchResult] = []
                for res in raw_results:
                    normalized_url = res.url.split("#")[0].rstrip("/")
                    if normalized_url not in seen_urls:
                        seen_urls.add(normalized_url)
                        unique_for_question.append(res)
                    else:
                        # URL already gathered in another question, avoid duplicate context
                        continue

                item.results = unique_for_question
                if unique_for_question:
                    item.status = "success"
                    print(f"  [OBSERVE] Retrieved {len(unique_for_question)} unique source(s).")
                    for r in unique_for_question:
                        print(f"    - {r.title} ({r.url})")
                else:
                    item.status = "no_results"
                    print("  [OBSERVE] Tavily returned no new/unique results for this query.")

            except Exception as exc:
                item.status = "failed"
                item.error_message = str(exc)
                print(f"  [OBSERVE/ERROR] Search query failed: {exc}")

            research_data.append(item)

        return research_data

    # --------------------------------------------------------------------------
    # 3. Synthesize Phase
    # --------------------------------------------------------------------------
    def synthesize_report(
        self,
        topic: str,
        research_data: List[QuestionResearch],
    ) -> str:
        """
        Uses the LLM to synthesize a comprehensive, evidence-grounded
        Markdown research report strictly based on collected web sources.
        """
        if self.llm_client is None:
            raise ConfigurationError("LLM client is not initialized.")

        # Build evidence context
        evidence_sections: List[str] = []
        all_sources: Dict[str, str] = {}  # url -> title

        for i, item in enumerate(research_data, 1):
            section_text = f"### Research Question {i}: {item.question}\nStatus: {item.status.upper()}\n"
            if item.status == "failed":
                section_text += f"Search Error: {item.error_message}\n"
            elif item.status == "no_results":
                section_text += "Search Result: No specific web results were located for this question.\n"
            else:
                section_text += "Retrieved Web Evidence:\n"
                for res in item.results:
                    all_sources[res.url] = res.title
                    section_text += (
                        f"- Source: [{res.title}]({res.url})\n"
                        f"  Content Snippet: {res.content}\n"
                    )
            evidence_sections.append(section_text)

        evidence_text = "\n\n".join(evidence_sections)

        system_prompt = (
            "You are a rigorous, objective academic research scientist and technical report author. "
            "Your task is to synthesize collected web research into an authoritative Markdown research report. "
            "STRICT GROUNDING RULE: You must ONLY state facts, findings, and metrics supported by the provided evidence. "
            "Never invent sources, citations, quotations, or URLs. Every citation must use the exact URL from the evidence. "
            "If evidence for a question is sparse or unavailable, state that clearly under that section."
        )

        prompt = (
            f"# Research Topic: {topic}\n\n"
            "## Collected Evidence Dossier\n"
            f"{evidence_text}\n\n"
            "---\n\n"
            "## Report Requirements\n"
            "Write a structured, exhaustive Markdown research report with the following exact sections:\n"
            "1. # [Comprehensive Research Report Title]\n"
            "2. **Topic**: Original research topic statement.\n"
            "3. ## Introduction: Background, significance, and scope of this investigation.\n"
            "4. ## Key Research Questions & Findings: Detailed analysis addressing each research question in order, "
            "incorporating Markdown hyperlinks `[Source Title](URL)` directly into the findings.\n"
            "5. ## Synthesis & Cross-Domain Implications: Synthesizing insights across all findings.\n"
            "6. ## Limitations & Evidence Gaps: Explicitly discuss any search limitations, failed queries, or remaining gaps.\n"
            "7. ## Conclusion: Summary of takeaways and future outlook.\n"
            "8. ## References: A formatted reference list linking every cited source title to its URL.\n\n"
            "Generate the full Markdown report now."
        )

        try:
            report = self.llm_client.generate(prompt=prompt, system_prompt=system_prompt)
            return report.strip()
        except Exception as exc:
            raise SynthesisError(f"Failed to synthesize research report: {exc}") from exc

    # --------------------------------------------------------------------------
    # 4. Master ReAct Execution
    # --------------------------------------------------------------------------
    def run(
        self,
        topic: str,
        output_path: str = "research_report.md",
    ) -> ResearchState:
        """
        Executes the full ReAct pipeline:
        Reason -> Act -> Observe -> Continue -> Synthesize.
        """
        start_dt = datetime.now(timezone.utc).isoformat()
        print("=" * 70)
        print("WEB RESEARCH AI AGENT: ReAct EXECUTION PIPELINE")
        print("=" * 70)
        print(f"Target Topic: \"{topic}\"")
        print(f"Started At:   {start_dt}")
        print("=" * 70)

        # Step 1: Reason / Plan
        print("\n[STAGE 1: REASON / PLAN]")
        print("Generating 5-6 structured research questions using LLM...")
        questions = self.reason_and_plan(topic)
        print(f"Generated {len(questions)} research questions:")
        for idx, q in enumerate(questions, 1):
            print(f"  {idx}. {q}")

        # Step 2: Act & Observe
        print("\n[STAGE 2: ACT & OBSERVE (TAVILY WEB SEARCH)]")
        research_data = self.act_and_observe(questions)

        # Calculate search metrics
        successful_searches = sum(1 for q in research_data if q.status == "success")
        failed_searches = sum(1 for q in research_data if q.status == "failed")
        no_result_searches = sum(1 for q in research_data if q.status == "no_results")
        total_unique_sources = sum(len(q.results) for q in research_data)

        print("\n[STAGE 3: SEARCH EXECUTION SUMMARY]")
        print(f"  - Questions investigated: {len(questions)}")
        print(f"  - Successful searches:    {successful_searches}")
        print(f"  - No results returned:    {no_result_searches}")
        print(f"  - Failed queries:         {failed_searches}")
        print(f"  - Total unique sources:   {total_unique_sources}")

        # Step 4: Synthesize Report
        print("\n[STAGE 4: SYNTHESIZE EVIDENCE INTO REPORT]")
        print("Synthesizing evidence-grounded research report with citations...")
        report_markdown = self.synthesize_report(topic, research_data)

        end_dt = datetime.now(timezone.utc).isoformat()

        # Compile unique sources map
        unique_sources: Dict[str, str] = {}
        for q in research_data:
            for r in q.results:
                unique_sources[r.url] = r.title

        state = ResearchState(
            topic=topic,
            questions=questions,
            research_data=research_data,
            unique_sources=unique_sources,
            start_time=start_dt,
            end_time=end_dt,
            report_markdown=report_markdown,
        )
        self.state = state

        # Save Report
        if output_path:
            # Ensure parent directory exists
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(report_markdown)
            print(f"\n[STAGE 5: COMPLETE] Research report saved to: {os.path.abspath(output_path)}")

        return state


# ==============================================================================
# CLI Entrypoint
# ==============================================================================

def build_parser() -> argparse.ArgumentParser:
    """Configures the command-line interface arguments."""
    parser = argparse.ArgumentParser(
        description="Web Research AI Agent using the ReAct (Reasoning + Acting) pattern."
    )
    parser.add_argument(
        "--topic", "-t",
        type=str,
        default=None,
        help="The research topic to investigate. If omitted, you will be prompted interactively.",
    )
    parser.add_argument(
        "--output", "-o",
        type=str,
        default="research_report.md",
        help="Path where the final Markdown research report will be saved. (Default: research_report.md)",
    )
    parser.add_argument(
        "--provider", "-p",
        type=str,
        choices=["groq", "gemini"],
        default=None,
        help="LLM provider to use (default: env LLM_PROVIDER or 'groq').",
    )
    parser.add_argument(
        "--model", "-m",
        type=str,
        default=None,
        help="Model name override for the selected LLM provider.",
    )
    parser.add_argument(
        "--depth", "-d",
        type=str,
        choices=["basic", "advanced"],
        default="basic",
        help="Tavily search depth: 'basic' (fast) or 'advanced' (thorough). (Default: basic)",
    )
    parser.add_argument(
        "--max-results", "-k",
        type=int,
        default=4,
        help="Maximum search results per research question. (Default: 4)",
    )
    return parser


def main() -> int:
    """CLI execution function."""
    parser = build_parser()
    args = parser.parse_args()

    topic = args.topic
    if not topic or not topic.strip():
        try:
            topic = input("Enter research topic: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nOperation cancelled by user.")
            return 1

    if not topic:
        print("[ERROR] Research topic cannot be empty.", file=sys.stderr)
        return 1

    try:
        # Initialize LLM and Tavily clients
        llm_client = get_llm_client(provider=args.provider, model=args.model)
        search_tool = TavilySearchTool()

        agent = WebResearchAgent(
            llm_client=llm_client,
            search_tool=search_tool,
            max_results_per_query=args.max_results,
            search_depth=args.depth,
        )

        agent.run(topic=topic, output_path=args.output)
        return 0

    except ConfigurationError as exc:
        print(f"\n[CONFIGURATION ERROR] {exc}", file=sys.stderr)
        print("\nPlease check your .env file or environment variables.", file=sys.stderr)
        return 2
    except AgentError as exc:
        print(f"\n[AGENT ERROR] {exc}", file=sys.stderr)
        return 3
    except Exception as exc:
        print(f"\n[UNEXPECTED ERROR] {exc}", file=sys.stderr)
        return 4


if __name__ == "__main__":
    sys.exit(main())
