"""
Logistics Optimization System - Crew Configuration
Defines exactly two agents and two sequential tasks using the CrewAI framework.
"""

import os
from typing import List, Optional, Tuple
from dotenv import load_dotenv
from crewai import Agent, Crew, Process, Task, LLM

# Load environment variables
load_dotenv()


class LogisticsConfigurationError(Exception):
    """Raised when required credentials or configuration are missing."""
    pass


class LogisticsValidationError(Exception):
    """Raised when runtime inputs are invalid."""
    pass


def get_llm(model: Optional[str] = None, api_key: Optional[str] = None) -> LLM:
    """
    Configures and returns a compatible CrewAI LLM instance based on available credentials.
    Supports OpenAI, Google Gemini, Anthropic, or custom LiteLLM models.
    """
    openai_key = api_key or os.getenv("OPENAI_API_KEY")
    gemini_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    anthropic_key = os.getenv("ANTHROPIC_API_KEY")
    env_model = os.getenv("MODEL_NAME") or os.getenv("OPENAI_MODEL_NAME")

    target_model = model or env_model

    # 1. User specified an explicit model
    if target_model:
        if "gemini" in target_model.lower():
            if not gemini_key:
                raise LogisticsConfigurationError(
                    f"Model '{target_model}' requested, but GEMINI_API_KEY / GOOGLE_API_KEY is not set."
                )
            return LLM(model=target_model, api_key=gemini_key)
        elif "claude" in target_model.lower() or "anthropic" in target_model.lower():
            if not anthropic_key:
                raise LogisticsConfigurationError(
                    f"Model '{target_model}' requested, but ANTHROPIC_API_KEY is not set."
                )
            return LLM(model=target_model, api_key=anthropic_key)
        else:
            # Assume OpenAI-compatible model
            if not openai_key:
                raise LogisticsConfigurationError(
                    f"Model '{target_model}' requested, but OPENAI_API_KEY is not set."
                )
            return LLM(model=target_model, api_key=openai_key)

    # 2. Check OpenAI default
    if openai_key and openai_key.strip():
        return LLM(model="gpt-4o-mini", api_key=openai_key)

    # 3. Check Gemini default
    if gemini_key and gemini_key.strip():
        return LLM(model="gemini/gemini-1.5-flash", api_key=gemini_key)

    # 4. Check Anthropic default
    if anthropic_key and anthropic_key.strip():
        return LLM(model="anthropic/claude-3-5-sonnet-20241022", api_key=anthropic_key)

    # If no keys were found
    raise LogisticsConfigurationError(
        "No LLM API credentials found in environment or .env file.\n"
        "Please provide one of the following:\n"
        "  - OPENAI_API_KEY (for OpenAI models like gpt-4o-mini)\n"
        "  - GEMINI_API_KEY or GOOGLE_API_KEY (for Google Gemini models)\n"
        "  - ANTHROPIC_API_KEY (for Claude models)\n\n"
        "Tip: Check '.env.example' to create your '.env' file, or run with '--dry-run' for structural offline testing."
    )


def create_logistics_analyst(llm: Optional[LLM] = None, verbose: bool = True) -> Agent:
    """
    Creates Agent 1: Logistics Analyst.
    Responsible for analyzing operations, identifying inefficiencies, risks,
    and structured baseline findings for the supplied products without inventing live data.
    """
    return Agent(
        role="Logistics Analyst",
        goal="Analyze logistics operations and identify inefficiencies, risks, and optimization opportunities for the supplied products.",
        backstory=(
            "You are an experienced logistics analyst skilled in supply-chain analysis, "
            "route efficiency, inventory turnover, demand patterns, transportation costs, "
            "and identifying operational bottlenecks. You focus on objective data analysis, "
            "identifying systemic issues, comparing performance indicators when data is available, "
            "and producing structured findings for the Optimization Strategist. "
            "You strictly adhere to professional integrity: you do not invent fictional real-world statistics "
            "or claim to have accessed live tracking systems without verified data sources. When data is illustrative "
            "or based on industry benchmarks, you clearly state it as an assumption."
        ),
        llm=llm,
        verbose=verbose,
        memory=False,
        allow_delegation=False,
    )


def create_optimization_strategist(llm: Optional[LLM] = None, verbose: bool = True) -> Agent:
    """
    Creates Agent 2: Optimization Strategist.
    Responsible for developing a practical, measurable logistics optimization strategy
    based on the findings of the Logistics Analyst.
    """
    return Agent(
        role="Optimization Strategist",
        goal="Develop a practical, measurable logistics optimization strategy using the Logistics Analyst's findings.",
        backstory=(
            "You are an experienced supply-chain optimization specialist who develops "
            "cost-effective delivery strategies, improves inventory management, reduces delays, "
            "and balances operational efficiency with customer satisfaction. You use empirical findings "
            "from logistics analysis to recommend actionable operational improvements, prioritize high-impact measures, "
            "estimate potential benefits only when supported by evidence, and define clear Key Performance Indicators (KPIs)."
        ),
        llm=llm,
        verbose=verbose,
        memory=False,
        allow_delegation=False,
    )


def create_logistics_analysis_task(
    agent: Agent,
    output_file: Optional[str] = "output/logistics_analysis_report.md"
) -> Task:
    """
    Creates Task 1: Logistics Analysis.
    Assigned to Agent 1 (Logistics Analyst).
    """
    description = (
        "Conduct a thorough logistics analysis for the supplied product list: {products}.\n"
        "Primary logistics focus: {logistics_focus}.\n\n"
        "Your analysis must investigate:\n"
        "1. Delivery-route efficiency and potential distribution delays.\n"
        "2. Transportation and fulfillment costs across each product category.\n"
        "3. Inventory turnover rates and holding cost pressures.\n"
        "4. Stock availability, lead times, and demand variability risks.\n"
        "5. Critical operational bottlenecks in warehousing, dispatch, and transit.\n\n"
        "Grounding and Data Rules:\n"
        "- If reliable external research tools or actual logistics datasets are available, analyze them methodically.\n"
        "- Otherwise, clearly distinguish explicit assumptions, illustrative sample benchmarks, and verified findings.\n"
        "- Do not fabricate real-world proprietary metrics or claim live system access.\n\n"
        "Produce a structured report containing the following mandatory sections:\n"
        "# Logistics Analysis Report\n"
        "## 1. Executive Summary\n"
        "## 2. Product-by-Product Analysis\n"
        "## 3. Identified Inefficiencies and Operational Risks\n"
        "## 4. Available Performance Indicators and Benchmarks\n"
        "## 5. Data Gaps and Core Assumptions\n"
        "## 6. Structured Findings for the Optimization Strategist\n"
    )

    expected_output = (
        "A structured markdown report covering: Executive Summary, Product-by-Product Analysis "
        "(route efficiency, delivery costs, inventory turnover, stock availability, and bottlenecks), "
        "Identified Inefficiencies and Risks, Available Performance Indicators (distinguishing assumptions from verified data), "
        "Data Gaps and Core Assumptions, and Structured Findings for the Optimization Strategist."
    )

    return Task(
        description=description,
        expected_output=expected_output,
        agent=agent,
        output_file=output_file,
    )


def create_optimization_strategy_task(
    agent: Agent,
    analysis_task: Task,
    output_file: Optional[str] = "output/logistics_optimization_report.md"
) -> Task:
    """
    Creates Task 2: Logistics Optimization Strategy.
    Assigned to Agent 2 (Optimization Strategist).
    Explicitly depends on Task 1 through CrewAI's context parameter.
    """
    description = (
        "Develop an actionable, practical, and measurable logistics optimization strategy for the products: {products}, "
        "strictly utilizing the findings produced in the Logistics Analysis report.\n"
        "Primary logistics focus: {logistics_focus}.\n\n"
        "Do not repeat the background analysis without developing concrete solutions. Synthesize the findings into an actionable operational roadmap.\n\n"
        "Your strategy must provide:\n"
        "1. Recommended optimization strategies for each relevant product category.\n"
        "2. Route optimization and inventory improvement measures tailored to product shelf-life, shipping velocity, and handling requirements.\n"
        "3. A prioritized implementation plan categorized into immediate quick-wins, medium-term enhancements, and long-term strategic projects.\n"
        "4. Expected benefits and their underlying assumptions, supported by logical evidence (clearly labeled as modeled/projected targets rather than historical empirical measurements).\n"
        "5. Clear Key Performance Indicators (KPIs) with measurement methods and target thresholds for tracking ongoing progress.\n"
        "6. Potential operational risks of implementation and practical mitigation measures.\n"
        "7. Final recommendations and overarching conclusion.\n\n"
        "Produce a structured report containing the following mandatory sections:\n"
        "# Logistics Optimization Strategy Report\n"
        "## 1. Executive Strategy Summary\n"
        "## 2. Product-Specific Optimization Strategies\n"
        "## 3. Route and Inventory Improvement Measures\n"
        "## 4. Prioritized Implementation Plan\n"
        "## 5. Expected Benefits and Underlying Assumptions\n"
        "## 6. Key Performance Indicators (KPIs)\n"
        "## 7. Potential Risks and Mitigation Measures\n"
        "## 8. Final Recommendations and Conclusion\n"
    )

    expected_output = (
        "A comprehensive logistics optimization strategy markdown report containing: "
        "Executive Strategy Summary, Product-Specific Optimization Strategies, Route and Inventory Improvement Measures, "
        "Prioritized Implementation Plan, Expected Benefits and Assumptions, Key Performance Indicators (KPIs), "
        "Potential Risks and Mitigations, and Final Recommendations."
    )

    return Task(
        description=description,
        expected_output=expected_output,
        agent=agent,
        context=[analysis_task],
        output_file=output_file,
    )


def build_logistics_crew(
    llm: Optional[LLM] = None,
    analysis_output_file: Optional[str] = "output/logistics_analysis_report.md",
    strategy_output_file: Optional[str] = "output/logistics_optimization_report.md",
    verbose: bool = True,
) -> Tuple[Crew, Agent, Agent, Task, Task]:
    """
    Builds and returns the CrewAI Crew instance with exactly two agents and two sequential tasks.
    Returns: (crew, analyst_agent, strategist_agent, analysis_task, strategy_task)
    """
    # 1. Create Exactly Two Agents
    analyst_agent = create_logistics_analyst(llm=llm, verbose=verbose)
    strategist_agent = create_optimization_strategist(llm=llm, verbose=verbose)

    # 2. Create Exactly Two Tasks
    analysis_task = create_logistics_analysis_task(
        agent=analyst_agent,
        output_file=analysis_output_file
    )
    strategy_task = create_optimization_strategy_task(
        agent=strategist_agent,
        analysis_task=analysis_task,
        output_file=strategy_output_file
    )

    # 3. Assemble Sequential Crew
    crew = Crew(
        agents=[analyst_agent, strategist_agent],
        tasks=[analysis_task, strategy_task],
        process=Process.sequential,
        verbose=verbose,
    )

    return crew, analyst_agent, strategist_agent, analysis_task, strategy_task
