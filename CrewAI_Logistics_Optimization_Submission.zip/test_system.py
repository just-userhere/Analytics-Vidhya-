"""
Comprehensive Test Suite for Logistics Optimization System
Tests structural compliance with assignment requirements, agent/task definitions,
context chaining, dynamic parameterization, error handling, and end-to-end execution.
"""

import os
import shutil
import pytest
from unittest.mock import patch

from crewai import Agent, Task, Crew, Process, LLM
from crewai.llms.providers.openai.completion import OpenAICompletion

from crew import (
    build_logistics_crew,
    create_logistics_analyst,
    create_optimization_strategist,
    create_logistics_analysis_task,
    create_optimization_strategy_task,
    get_llm,
    LogisticsConfigurationError,
    LogisticsValidationError,
)
from main import sanitize_product_list, generate_simulated_responses, run_logistics_system


@pytest.fixture
def mock_llm():
    """Provides a deterministic mock LLM for structural testing without network calls."""
    return LLM(model="gpt-4o-mini", api_key="test-structural-key")


class TestSystemStructure:
    """Verifies that the multi-agent system meets all exact assignment requirements."""

    def test_exactly_two_agents_created(self, mock_llm):
        """Requirement: Create exactly two agents."""
        crew, a1, a2, t1, t2 = build_logistics_crew(llm=mock_llm, verbose=False)
        assert len(crew.agents) == 2, f"Expected exactly 2 agents, found {len(crew.agents)}"

    def test_agent_1_logistics_analyst_specification(self, mock_llm):
        """Requirement: Agent 1 must be Logistics Analyst with specified role, goal, and backstory traits."""
        analyst = create_logistics_analyst(llm=mock_llm, verbose=False)
        assert analyst.role == "Logistics Analyst"
        assert "Analyze logistics operations" in analyst.goal
        assert "route efficiency" in analyst.backstory.lower()
        assert "inventory turnover" in analyst.backstory.lower()
        assert "operational bottlenecks" in analyst.backstory.lower()
        # Data integrity rule: must not claim live data without verification
        assert "integrity" in analyst.backstory.lower() or "not invent" in analyst.backstory.lower()

    def test_agent_2_optimization_strategist_specification(self, mock_llm):
        """Requirement: Agent 2 must be Optimization Strategist with specified role, goal, and backstory traits."""
        strategist = create_optimization_strategist(llm=mock_llm, verbose=False)
        assert strategist.role == "Optimization Strategist"
        assert "optimization strategy" in strategist.goal.lower()
        assert "cost-effective delivery strategies" in strategist.backstory.lower()
        assert "kpi" in strategist.backstory.lower() or "indicators" in strategist.backstory.lower()

    def test_exactly_two_tasks_created(self, mock_llm):
        """Requirement: Create exactly two tasks."""
        crew, a1, a2, t1, t2 = build_logistics_crew(llm=mock_llm, verbose=False)
        assert len(crew.tasks) == 2, f"Expected exactly 2 tasks, found {len(crew.tasks)}"

    def test_task_assignments(self, mock_llm):
        """Requirement: Assign Task 1 to Logistics Analyst, Task 2 to Optimization Strategist."""
        crew, a1, a2, t1, t2 = build_logistics_crew(llm=mock_llm, verbose=False)
        assert t1.agent == a1
        assert t1.agent.role == "Logistics Analyst"
        assert t2.agent == a2
        assert t2.agent.role == "Optimization Strategist"

    def test_task_context_dependency(self, mock_llm):
        """Requirement: Task 2 must depend on Task 1 and receive its output via context."""
        crew, a1, a2, t1, t2 = build_logistics_crew(llm=mock_llm, verbose=False)
        assert t2.context is not None, "Task 2 context must not be None"
        assert len(t2.context) == 1, "Task 2 should have exactly 1 task in context"
        assert t2.context[0] == t1, "Task 2 context must reference Task 1"

    def test_sequential_workflow_process(self, mock_llm):
        """Requirement: Set the process to sequential."""
        crew, a1, a2, t1, t2 = build_logistics_crew(llm=mock_llm, verbose=False)
        assert crew.process == Process.sequential, f"Expected Process.sequential, got {crew.process}"

    def test_task_template_parameterization(self, mock_llm):
        """Requirement: Task descriptions must reference runtime inputs via template syntax {products} and focus."""
        a1 = create_logistics_analyst(llm=mock_llm, verbose=False)
        a2 = create_optimization_strategist(llm=mock_llm, verbose=False)
        t1 = create_logistics_analysis_task(a1)
        t2 = create_optimization_strategy_task(a2, analysis_task=t1)

        assert "{products}" in t1.description, "Task 1 description must contain {products} template tag"
        assert "{products}" in t2.description, "Task 2 description must contain {products} template tag"
        assert "{logistics_focus}" in t1.description, "Task 1 description must contain {logistics_focus} template tag"
        assert "{logistics_focus}" in t2.description, "Task 2 description must contain {logistics_focus} template tag"

    def test_task_1_required_report_sections(self, mock_llm):
        """Requirement: Task 1 report must require specified core sections."""
        a1 = create_logistics_analyst(llm=mock_llm, verbose=False)
        t1 = create_logistics_analysis_task(a1)
        desc = t1.description
        assert "Executive Summary" in desc
        assert "Product-by-Product Analysis" in desc
        assert "Identified Inefficiencies" in desc
        assert "Performance Indicators" in desc
        assert "Data Gaps" in desc
        assert "Findings for the Optimization Strategist" in desc

    def test_task_2_required_report_sections(self, mock_llm):
        """Requirement: Task 2 report must require specified core sections."""
        a1 = create_logistics_analyst(llm=mock_llm, verbose=False)
        a2 = create_optimization_strategist(llm=mock_llm, verbose=False)
        t1 = create_logistics_analysis_task(a1)
        t2 = create_optimization_strategy_task(a2, t1)
        desc = t2.description
        assert "Executive Strategy Summary" in desc
        assert "Product-Specific Optimization Strategies" in desc
        assert "Route and Inventory Improvement Measures" in desc
        assert "Prioritized Implementation Plan" in desc
        assert "Expected Benefits" in desc
        assert "Key Performance Indicators" in desc
        assert "Potential Risks and Mitigation" in desc
        assert "Final Recommendations" in desc


class TestInputValidation:
    """Verifies runtime input validation and sanitization."""

    def test_valid_product_list_sanitization(self):
        cleaned = sanitize_product_list("Electronics, Clothing, Perishable Goods")
        assert cleaned == ["Electronics", "Clothing", "Perishable Goods"]

    def test_product_list_with_messy_whitespace(self):
        cleaned = sanitize_product_list("  Automotive Parts  ,   Medical Devices  ,  ")
        assert cleaned == ["Automotive Parts", "Medical Devices"]

    def test_empty_product_string_raises_validation_error(self):
        with pytest.raises(LogisticsValidationError):
            sanitize_product_list("")

    def test_whitespace_only_raises_validation_error(self):
        with pytest.raises(LogisticsValidationError):
            sanitize_product_list("   ,   ,   ")


class TestConfigurationAndCredentials:
    """Verifies reliable credential checks and informative error messaging."""

    def test_missing_credentials_raises_configuration_error(self):
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(LogisticsConfigurationError) as exc_info:
                get_llm()
            assert "No LLM API credentials found" in str(exc_info.value)
            assert "OPENAI_API_KEY" in str(exc_info.value)

    def test_openai_key_detection(self):
        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-mock-openai-key"}, clear=True):
            llm = get_llm()
            assert llm.model == "gpt-4o-mini"
            assert llm.api_key == "sk-mock-openai-key"

    def test_gemini_key_detection(self):
        with patch.dict(os.environ, {"GEMINI_API_KEY": "mock-gemini-key"}, clear=True):
            llm = get_llm()
            assert "gemini" in llm.model.lower()
            assert llm.api_key == "mock-gemini-key"


class TestEndToEndExecution:
    """Verifies complete multi-agent execution and report generation in simulation mode."""

    def test_end_to_end_dry_run_simulation(self, tmp_path):
        test_output_dir = str(tmp_path / "test_output")
        products = ["Electronics", "Clothing", "Perishable Goods"]
        focus = "route efficiency and inventory management"

        run_logistics_system(
            products=products,
            focus=focus,
            output_dir=test_output_dir,
            dry_run=True,
            verbose=False,
        )

        analysis_file = os.path.join(test_output_dir, "logistics_analysis_report.md")
        strategy_file = os.path.join(test_output_dir, "logistics_optimization_report.md")

        assert os.path.exists(analysis_file), "Logistics analysis report must be created"
        assert os.path.exists(strategy_file), "Logistics optimization report must be created"

        with open(analysis_file, "r", encoding="utf-8") as f:
            analysis_text = f.read()
            assert "# Logistics Analysis Report" in analysis_text
            assert "Electronics" in analysis_text
            assert "Clothing" in analysis_text
            assert "Perishable Goods" in analysis_text
            assert "Executive Summary" in analysis_text
            assert "Identified Inefficiencies and Operational Risks" in analysis_text

        with open(strategy_file, "r", encoding="utf-8") as f:
            strategy_text = f.read()
            assert "# Logistics Optimization Strategy Report" in strategy_text
            assert "Electronics" in strategy_text
            assert "Clothing" in strategy_text
            assert "Perishable Goods" in strategy_text
            assert "Prioritized Implementation Plan" in strategy_text
            assert "Key Performance Indicators (KPIs)" in strategy_text
