# AI-Powered Logistics Optimization System (CrewAI)

An enterprise-grade, academic-compliant multi-agent logistics analysis and optimization platform built with the **CrewAI** framework. The system dynamically accepts any arbitrary list of product categories at runtime and coordinates two specialized AI agents in a sequential workflow to generate actionable, evidence-based operational recommendations.

---

## 1. Objective

Logistics operations frequently suffer from sub-optimal delivery routing, inventory turnover imbalances, volatile transportation costs, recurring stockouts, and warehousing bottlenecks. 

This system automates end-to-end logistics evaluation by:
1. Conducting a grounded, product-by-product operational assessment across key supply chain dimensions.
2. Formulating a phased, measurable optimization strategy with concrete Key Performance Indicators (KPIs) and risk mitigation measures.
3. Dynamically accepting runtime inputs without hardcoding products or altering agent/task definitions.

---

## 2. Multi-Agent System Architecture

The system implements **exactly two agents** and **exactly two sequential tasks**, fully adhering to assignment requirements.

```
+-----------------------------------------------------------------------------------------+
|                                RUNTIME INPUT PARAMETERS                                 |
|               products = ["Electronics", "Clothing", "Perishable Goods"]                |
|                    logistics_focus = "delivery-route efficiency, ..."                   |
+-----------------------------------------------------------------------------------------+
                                           |
                                           v
+-----------------------------------------------------------------------------------------+
| AGENT 1: Logistics Analyst                                                               |
| Role: Logistics Analyst                                                                 |
| Goal: Analyze logistics operations and identify inefficiencies, risks, and             |
|       optimization opportunities for the supplied products.                             |
+-----------------------------------------------------------------------------------------+
                                           |
                                           v (Executes Task 1)
+-----------------------------------------------------------------------------------------+
| TASK 1: Logistics Analysis                                                              |
| - Product-by-product analysis on transit, costs, turnover, stock, and bottlenecks       |
| - Strictly distinguishes assumptions from verified data                                 |
| - Output: output/logistics_analysis_report.md                                           |
+-----------------------------------------------------------------------------------------+
                                           |
                                           | [Context Output Passed Directly]
                                           v
+-----------------------------------------------------------------------------------------+
| AGENT 2: Optimization Strategist                                                        |
| Role: Optimization Strategist                                                           |
| Goal: Develop a practical, measurable logistics optimization strategy using the        |
|       Logistics Analyst's findings.                                                     |
+-----------------------------------------------------------------------------------------+
                                           |
                                           v (Executes Task 2 with Task 1 Context)
+-----------------------------------------------------------------------------------------+
| TASK 2: Logistics Optimization Strategy                                                 |
| - Builds upon Task 1 findings without redundant repetition                              |
| - Delivers product strategies, route/inventory fixes, phased roadmap, KPIs, & risks     |
| - Output: output/logistics_optimization_report.md                                       |
+-----------------------------------------------------------------------------------------+
```

### Agent 1: Logistics Analyst
- **Role**: `Logistics Analyst`
- **Goal**: Analyze logistics operations and identify inefficiencies, risks, and optimization opportunities for the supplied products.
- **Backstory**: An experienced logistics analyst skilled in supply-chain analysis, route efficiency, inventory turnover, demand patterns, transportation costs, and identifying operational bottlenecks.
- **Responsibilities**: Researches and assesses product-level logistics data, identifies systemic issues, compares performance benchmarks, and produces structured findings for the Optimization Strategist.
- **Data Integrity & Grounding**: Adheres to strict professional standards: does not invent fictional metrics or claim live system access when external feeds are unavailable. Explicitly flags assumptions and illustrative baselines.

### Agent 2: Optimization Strategist
- **Role**: `Optimization Strategist`
- **Goal**: Develop a practical, measurable logistics optimization strategy using the Logistics Analyst's findings.
- **Backstory**: An experienced supply-chain optimization specialist who develops cost-effective delivery strategies, improves inventory management, reduces delays, and balances operational efficiency with customer satisfaction.
- **Responsibilities**: Consumes the Logistics Analyst's structured report, recommends actionable operational improvements, establishes a prioritized phased roadmap, estimates evidence-based benefits, and defines measurable KPIs.

---

## 3. Tasks & Sequential Context Workflow

### Task 1: Logistics Analysis
- **Assigned to**: `Logistics Analyst`
- **Scope**: Evaluates route efficiency, transit delays, transportation costs, inventory turnover, stock availability, demand variability, and fulfillment bottlenecks for `{products}` under `{logistics_focus}`.
- **Mandatory Sections Produced**:
  1. Executive Summary
  2. Product-by-Product Analysis
  3. Identified Inefficiencies and Operational Risks
  4. Available Performance Indicators and Benchmarks (Clarifying Assumptions vs. Verified Data)
  5. Data Gaps and Core Assumptions
  6. Structured Findings for the Optimization Strategist

### Task 2: Logistics Optimization Strategy
- **Assigned to**: `Optimization Strategist`
- **Context Dependency**: Configured with `context=[analysis_task]`, guaranteeing that Task 2 automatically receives Task 1's structured output.
- **Scope**: Develops actionable solutions tailored to `{products}` and `{logistics_focus}` without duplicating raw descriptive analysis.
- **Mandatory Sections Produced**:
  1. Executive Strategy Summary
  2. Product-Specific Optimization Strategies
  3. Route and Inventory Improvement Measures
  4. Prioritized Implementation Plan (Phase 1 Quick Wins, Phase 2 Enhancements, Phase 3 Overhaul)
  5. Expected Benefits and Underlying Assumptions
  6. Key Performance Indicators (KPIs) & Governance Framework
  7. Potential Risks and Mitigation Measures
  8. Final Recommendations and Conclusion

---

## 4. Dynamic Parameterization

The system strictly avoids hardcoded products. Products are injected dynamically at runtime via CrewAI's template interpolation:

- **CrewAI Kickoff Inputs**:
  ```python
  crew_inputs = {
      "products": "Electronics, Clothing, Perishable Goods",
      "logistics_focus": "delivery-route efficiency, inventory turnover, delivery costs, stock availability, and operational bottlenecks"
  }
  result = crew.kickoff(inputs=crew_inputs)
  ```
- **Template Placeholders**: Both task descriptions reference `{products}` and `{logistics_focus}`. Users can change the product list via CLI arguments without modifying a single line of agent or task definitions.

---

## 5. Project Structure

```
d:/Projects/Analytics vidhya/Crew AI/
├── main.py                  # CLI entry point, argument parsing, runtime kickoff & validation
├── crew.py                  # Agent, Task, and Crew configurations using CrewAI APIs
├── test_system.py           # Automated test suite (18 unit & structural validation tests)
├── requirements.txt         # Project dependencies (crewai, google-genai, python-dotenv, pytest)
├── .env.example             # Configuration template for LLM credentials (no real secrets)
├── .gitignore               # Excludes virtual envs, secrets (.env), caches, and raw reports
├── README.md                # Comprehensive documentation, setup, and execution guide
└── output/                  # Directory storing generated markdown reports
    ├── .gitkeep
    ├── logistics_analysis_report.md
    └── logistics_optimization_report.md
```

---

## 6. Installation and Setup

### Prerequisites
- Python **3.10**, **3.11**, or **3.12** recommended.

### Step 1: Clone or Navigate to the Workspace
```powershell
cd "d:\Projects\Analytics vidhya\Crew AI"
```

### Step 2: Create and Activate a Virtual Environment

Using **uv** (recommended for high-speed dependency resolution):
```powershell
uv venv .venv --python 3.11
.venv\Scripts\activate
```

Or using standard Python:
```powershell
python -m venv .venv
.venv\Scripts\activate
```

### Step 3: Install Required Dependencies
```powershell
uv pip install -r requirements.txt
# or: pip install -r requirements.txt
```

---

## 7. Environment & LLM Configuration

The system reads credentials securely from a `.env` file using `python-dotenv`. **API keys are never hardcoded.**

### Step 1: Create your `.env` file
Copy `.env.example` to `.env`:
```powershell
Copy-Item .env.example .env
```

### Step 2: Set your preferred LLM Provider

Open `.env` in any text editor and supply your key:

#### Option A: OpenAI (Default)
```env
OPENAI_API_KEY=sk-proj-your-openai-api-key-here
OPENAI_MODEL_NAME=gpt-4o-mini
```

#### Option B: Google Gemini
```env
GEMINI_API_KEY=AIzaSyYourGeminiApiKeyHere
# Supported model automatically defaults to: gemini/gemini-1.5-flash
```

#### Option C: Anthropic Claude
```env
ANTHROPIC_API_KEY=sk-ant-your-anthropic-key-here
MODEL_NAME=anthropic/claude-3-5-sonnet-20241022
```

---

## 8. Execution Commands

### 1. Default Run (Sample Product List)
Analyzes the default product list (`Electronics, Clothing, Perishable Goods`):
```powershell
python main.py
```

### 2. Custom Product List via CLI
Supply any comma-separated product categories dynamically:
```powershell
python main.py --products "Automotive Parts, Medical Devices, Industrial Machinery"
```

### 3. Custom Logistics Focus Area
Specify a specialized supply chain focus:
```powershell
python main.py --products "Fresh Seafood, Organic Dairy, Frozen Meat" --focus "cold-chain temperature integrity and route dwell time"
```

### 4. Explicit Model Selection
Override the default model at invocation:
```powershell
python main.py --model gemini/gemini-1.5-flash
```

### 5. Offline Dry-Run Validation Mode (Zero API Costs)
Verify the entire multi-agent sequential pipeline, dynamic template interpolation, and report writing without requiring an active API key:
```powershell
python main.py --dry-run
```

To run with minimal console streaming:
```powershell
python main.py --dry-run --quiet
```

---

## 9. Sample Runtime Inputs and Expected Outputs

### Sample Runtime Inputs
```bash
--products "Electronics, Clothing, Perishable Goods"
--focus "delivery-route efficiency, inventory turnover, delivery costs, stock availability, and operational bottlenecks"
```

### Sample Report 1: Logistics Analysis Report (`output/logistics_analysis_report.md`)
```markdown
# Logistics Analysis Report
*Generated by Agent 1: Logistics Analyst*

## 1. Executive Summary
This analysis evaluates current logistics operations across the target product portfolio: Electronics, Clothing, Perishable Goods...

## 2. Product-by-Product Analysis
### 2.1 Product Category: Electronics
- Route Efficiency & Delays: High-value freight requiring secured tracking...
- Transportation & Fulfillment Costs: Express freight and 8-12% returns...
...
### 2.2 Product Category: Clothing
...
### 2.3 Product Category: Perishable Goods
...

## 3. Identified Inefficiencies and Operational Risks
1. Route Sub-optimization: Inflexible dispatch schedules cause LTL inefficiencies...
...
## 4. Available Performance Indicators and Benchmarks
- Order Fulfillment Cycle Time: 4.2 days
- On-Time In-Full (OTIF) Rate: 87.4%
...
## 5. Data Gaps and Core Assumptions
- Telematics GPS live feed is modeled on regional routing averages...
...
## 6. Structured Findings for the Optimization Strategist
- Prioritize multi-stop route clustering...
```

### Sample Report 2: Logistics Optimization Strategy Report (`output/logistics_optimization_report.md`)
```markdown
# Logistics Optimization Strategy Report
*Generated by Agent 2: Optimization Strategist*

## 1. Executive Strategy Summary
Based on the empirical findings provided by the Logistics Analyst...

## 2. Product-Specific Optimization Strategies
### 2.1 Targeted Action Plan: Electronics
...
### 2.2 Targeted Action Plan: Clothing
...
### 2.3 Targeted Action Plan: Perishable Goods
...

## 3. Route and Inventory Improvement Measures
- Dynamic Vehicle Routing: Deploy cluster-first, route-second dispatching...
...
## 4. Prioritized Implementation Plan
| Horizon | Milestone / Action Item | Target Completion | Responsible Unit |
| :--- | :--- | :--- | :--- |
| Phase 1: Quick Wins | Consolidate carrier contracts | Days 1 - 30 | Logistics Dispatch |
| Phase 2: Enhancements | Deploy dynamic route optimization | Days 31 - 90 | Operations |
| Phase 3: Strategic Overhaul | Automated cross-docking hubs | Days 91 - 180 | IT & Supply Chain |

## 5. Expected Benefits and Underlying Assumptions
- Projected Fuel & Transit Savings: 12% to 16% reduction in transport expenses...
...
## 6. Key Performance Indicators (KPIs)
1. OTIF: Target >= 95.5% weekly.
2. Cost per Delivered Unit (CPDU): 10% reduction monthly.
...
## 7. Potential Risks and Mitigation Measures
...
## 8. Final Recommendations and Conclusion
...
```

---

## 10. Testing and Validation

A comprehensive test suite of **18 automated tests** is provided in `test_system.py`.

To run the full test suite:
```powershell
pytest -v test_system.py
```

### Test Suite Coverage:
1. **Agent Count & Role Compliance**: Verifies exactly 2 agents with exact roles, goals, and backstories.
2. **Task Count & Assignment**: Verifies exactly 2 tasks assigned to the appropriate agents.
3. **Sequential Workflow & Context**: Verifies `Process.sequential` and explicit `context=[analysis_task]` dependency.
4. **Dynamic Template Parameterization**: Validates `{products}` and `{logistics_focus}` template variables.
5. **Report Section Integrity**: Verifies all required report sections in both task definitions.
6. **Input Sanitization**: Tests whitespace trimming, comma-delimited parsing, and empty input rejection.
7. **Credential Diagnostics**: Verifies readable error handling when credentials are missing.
8. **End-to-End Simulation**: Verifies complete crew kickoff, context piping, and report file creation.

---

## 11. Reliability and Error Handling

- **Missing Credentials**: If no API key is detected in the environment or `.env`, `main.py` catches `LogisticsConfigurationError`, prints clear setup instructions, and suggests running with `--dry-run`.
- **Invalid Inputs**: Blank or whitespace-only product lists raise a `LogisticsValidationError` with immediate guidance.
- **API/Runtime Failures**: Errors during LLM inference are caught gracefully with actionable troubleshooting advice.
- **Academic Assessment Integrity**: The system makes explicit distinctions between verified empirical findings and illustrative sample assumptions, upholding academic and industrial standards.
