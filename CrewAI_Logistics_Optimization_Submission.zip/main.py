"""
Logistics Optimization System - Main Entry Point
Accepts dynamic runtime inputs (products, optional focus) and coordinates execution
via CrewAI's sequential multi-agent workflow.
"""

import argparse
import os
import sys
from typing import List, Optional
from unittest.mock import patch

# Ensure UTF-8 output encoding on Windows consoles
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

from crewai.llms.providers.openai.completion import OpenAICompletion
from crew import (
    build_logistics_crew,
    get_llm,
    LogisticsConfigurationError,
    LogisticsValidationError,
)


def parse_arguments() -> argparse.Namespace:
    """Parses command-line arguments for dynamic runtime configuration."""
    parser = argparse.ArgumentParser(
        description="AI-Powered Logistics Analysis & Optimization System using CrewAI",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument(
        "--products",
        type=str,
        default="Electronics, Clothing, Perishable Goods",
        help="Comma-separated list of products to analyze and optimize dynamically at runtime.",
    )

    parser.add_argument(
        "--focus",
        type=str,
        default="delivery-route efficiency, inventory turnover, delivery costs, stock availability, and operational bottlenecks",
        help="Optional logistics focus area for both agents.",
    )

    parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="LLM model identifier (e.g., 'gpt-4o-mini', 'gemini/gemini-1.5-flash', 'claude-3-5-sonnet').",
    )

    parser.add_argument(
        "--output-dir",
        type=str,
        default="output",
        help="Directory to save generated analysis and optimization reports.",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run an offline structural simulation to validate agent & task chaining without calling external paid APIs.",
    )

    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Reduce CrewAI verbose console streaming.",
    )

    return parser.parse_args()


def sanitize_product_list(products_input: str) -> List[str]:
    """
    Validates and cleans the comma-separated product string into a list of non-empty product names.
    Raises LogisticsValidationError if the resulting list is empty.
    """
    if not products_input or not isinstance(products_input, str):
        raise LogisticsValidationError("Product list input must be a non-empty string.")

    cleaned = [p.strip() for p in products_input.split(",") if p.strip()]

    if not cleaned:
        raise LogisticsValidationError(
            "No valid products specified. Please provide at least one product name (e.g. --products 'Electronics, Clothing')."
        )

    return cleaned


def generate_simulated_responses(products: List[str], focus: str) -> List[str]:
    """Generates realistic structured responses for dry-run offline validation."""
    products_str = ", ".join(products)

    # Product-specific traits generator for rich simulated reporting
    def get_analysis_profile(product_name: str) -> dict:
        p_lower = product_name.lower()
        if "perish" in p_lower or "food" in p_lower or "cold" in p_lower or "dairy" in p_lower:
            return {
                "route": "High sensitivity to transit time; cold-chain temperature telemetry required.",
                "cost": "Refrigerated reefer transit adds 28-35% premium over ambient dry freight.",
                "turnover": "Ultra-short shelf-life requires high inventory turnover (18-24x per year) to avoid spoilage.",
                "stock": "High stockout risk due to rigid expiry windows and unpredictable demand surges.",
                "bottleneck": "Refrigerated cross-dock bottlenecks and dwell time during pre-cooling inspections."
            }
        elif "electr" in p_lower or "tech" in p_lower or "device" in p_lower or "phone" in p_lower:
            return {
                "route": "High-value freight requiring secured route tracking, geofencing, and signature verification.",
                "cost": "High transit insurance, express air/ground delivery, and reverse logistics costs (8-12% returns).",
                "turnover": "Moderate turnover (6-8x per year); rapid product lifecycle risks obsolete depreciation.",
                "stock": "Component supply chain bottlenecks and long semiconductor lead times (6-12 weeks).",
                "bottleneck": "Secure cage handling, serial number scanning latency, and customs clearance holds."
            }
        elif "cloth" in p_lower or "apparel" in p_lower or "fashion" in p_lower or "shoe" in p_lower:
            return {
                "route": "Omnichannel distribution channels; high volume parcel delivery to urban residential nodes.",
                "cost": "Excessive reverse logistics costs; return rates reach 22-30% in e-commerce fashion.",
                "turnover": "Seasonal SKU churn; high inventory turnover during peak seasons followed by markdown lags.",
                "stock": "Extreme SKU proliferation (sizes, colors); inventory fragmentation creates localized stockouts.",
                "bottleneck": "Garment sorting and pick-and-pack bottlenecks during seasonal promotional events."
            }
        else:
            return {
                "route": "Standard road/freight corridors with scheduled regional LTL consolidation.",
                "cost": "Fulfillment and transportation account for approximately 15-20% of net landed cost.",
                "turnover": "Standard inventory turnover (4-6x annually) with baseline safety buffer policies.",
                "stock": "Moderate lead-time variability with seasonal restocking dependencies.",
                "bottleneck": "Pallet storage capacity and dock scheduling delays at regional distribution hubs."
            }

    def get_strategy_profile(product_name: str) -> dict:
        p_lower = product_name.lower()
        if "perish" in p_lower or "food" in p_lower or "cold" in p_lower or "dairy" in p_lower:
            return {
                "fulfillment": "Deploy automated First-Expired-First-Out (FEFO) warehouse inventory picking.",
                "route": "Implement temperature-monitored direct route dispatching with geofenced delivery alerts.",
                "inventory": "Contract local supplier cross-docks to reduce transit radius under 150 miles."
            }
        elif "electr" in p_lower or "tech" in p_lower or "device" in p_lower or "phone" in p_lower:
            return {
                "fulfillment": "Consolidate regional security vaults with automated serial-tracking fulfillment.",
                "route": "Utilize verified scheduled express corridors with dedicated tamper-evident seals.",
                "inventory": "Implement postponement assembly and centralized buffer stocking for high-value variants."
            }
        elif "cloth" in p_lower or "apparel" in p_lower or "fashion" in p_lower or "shoe" in p_lower:
            return {
                "fulfillment": "Establish localized return processing hubs with rapid restocking turnaround (< 48 hrs).",
                "route": "Zone skipping and hybrid parcel carrier diversification for urban deliveries.",
                "inventory": "Dynamic size-curve allocation algorithms to prevent fragmented SKU deadstock."
            }
        else:
            return {
                "fulfillment": "Deploy regional micro-fulfillment centers to cut last-mile travel distance by 25%.",
                "route": "Deploy dynamic vehicle route optimization with multi-stop milk runs.",
                "inventory": "Automate reorder-point triggers integrated with supplier lead-time tracking."
            }

    analysis_response = f"""# Logistics Analysis Report
*Generated by Agent 1: Logistics Analyst*

## 1. Executive Summary
This analysis evaluates current logistics operations across the target product portfolio: {products_str}.
The investigation specifically addresses the primary operational focus: {focus}.
The findings indicate varied operational vulnerabilities, ranging from temperature-control transit constraints
to rapid inventory obsolescence, return rate pressures, and lead-time variability.

## 2. Product-by-Product Analysis
"""
    for idx, prod in enumerate(products, 1):
        prof = get_analysis_profile(prod)
        analysis_response += f"""
### 2.{idx} Product Category: {prod}
- **Route Efficiency & Delays**: {prof['route']}
- **Transportation & Fulfillment Costs**: {prof['cost']}
- **Inventory Turnover & Holding Costs**: {prof['turnover']}
- **Stock Availability & Demand Volatility**: {prof['stock']}
- **Operational Bottlenecks**: {prof['bottleneck']}
"""

    analysis_response += """
## 3. Identified Inefficiencies and Operational Risks
1. **Route Sub-optimization**: Inflexible dispatch schedules result in less-than-truckload (LTL) inefficiency and redundant mileage.
2. **Buffer Inventory Imbalances**: Excessive safety stock for slow-moving SKUs alongside recurrent stockouts for high-velocity items.
3. **Cross-Docking Delays**: Transit handoffs between regional hubs and local distribution centers create avoidable idle dwell time.

## 4. Available Performance Indicators and Benchmarks
*(Note: Metrics represent industry benchmarks and structured baseline models rather than live telemetry)*
- Average Order Fulfillment Cycle Time: 4.2 days
- On-Time In-Full (OTIF) Delivery Rate: 87.4%
- Fleet Capacity Utilization: 68.5%
- Inventory Carrying Cost Ratio: 22.0% annually

## 5. Data Gaps and Core Assumptions
- Telematics GPS live feed is not directly connected; transit duration estimates are modeled on regional highway routing averages.
- Supplier manufacturing lead times are assumed to follow deterministic historical standard deviations.
- Fuel surcharge impacts are evaluated against current regional diesel price indices.

## 6. Structured Findings for the Optimization Strategist
- Prioritize multi-stop route clustering and dynamic dispatching to elevate fleet utilization above 82%.
- Implement tiered safety-stock replenishment (EOQ + dynamic buffer) based on product shelf-life and demand volatility.
- Eliminate transit touchpoints through direct-to-hub cross-docking for high-priority shipments.
"""

    strategy_response = f"""# Logistics Optimization Strategy Report
*Generated by Agent 2: Optimization Strategist*

## 1. Executive Strategy Summary
Based on the empirical findings provided by the Logistics Analyst for {products_str}, this strategy
outlines an actionable, multi-phase roadmap to optimize delivery-route efficiency, reduce operating costs,
and elevate stock availability while keeping capital expenditure constrained.

## 2. Product-Specific Optimization Strategies
"""
    for idx, prod in enumerate(products, 1):
        strat = get_strategy_profile(prod)
        strategy_response += f"""
### 2.{idx} Targeted Action Plan: {prod}
- **Fulfillment Model**: {strat['fulfillment']}
- **Route Dispatch**: {strat['route']}
- **Inventory Policy**: {strat['inventory']}
"""

    strategy_response += """
## 3. Route and Inventory Improvement Measures
- **Dynamic Vehicle Routing**: Deploy cluster-first, route-second dispatching algorithms to minimize deadhead miles.
- **Safety Stock Right-Sizing**: Reallocate working capital from stagnant SKUs to high-demand safety buffers.
- **Vendor-Managed Inventory (VMI)**: Establish automated supplier notifications for critical replenishment thresholds.

## 4. Prioritized Implementation Plan
| Horizon | Milestone / Action Item | Target Completion | Responsible Unit |
| :--- | :--- | :--- | :--- |
| **Phase 1: Quick Wins** | Consolidate regional carrier contracts & establish dispatch cutoffs | Days 1 - 30 | Logistics Dispatch |
| **Phase 2: Operational Enhancements** | Deploy dynamic route optimization & reset SKU inventory reorder points | Days 31 - 90 | Supply Chain Operations |
| **Phase 3: Strategic Overhaul** | Integrate automated cross-docking hubs and predictive demand forecasting | Days 91 - 180 | IT & Operations Leadership |

## 5. Expected Benefits and Underlying Assumptions
*(Methodology Note: The values below represent modeled operational targets and illustrative projections derived from baseline assumptions, not pre-existing measured outcomes)*
- **Projected Fuel & Transit Savings (Target)**: 12% to 16% reduction in transportation expenditures (assuming route consolidation compliance >= 85%).
- **On-Time Delivery (OTIF) Target**: Projected improvement from an 87.4% baseline to >= 95.0% post-implementation.
- **Holding Cost Reduction (Target)**: 18% reduction in excess holding costs through inventory rationalization.

## 6. Key Performance Indicators (KPIs)
*(Targeted benchmarks established for operational governance and progress tracking)*
1. **OTIF (On-Time In-Full)**: Target >= 95.5% measured weekly.
2. **Cost per Delivered Unit (CPDU)**: Target 10% net reduction measured monthly.
3. **Inventory Turnover Ratio (ITR)**: Target increase from 4.8x baseline to >= 6.5x annually.
4. **Fleet Load Factor**: Target >= 82% cubic capacity utilization.

## 7. Potential Risks and Mitigation Measures
- *Risk*: Driver resistance to dynamic algorithmic routing.
  - *Mitigation*: Conduct hands-on driver onboarding and provide performance-linked efficiency incentives.
- *Risk*: Initial supplier delivery variance during VMI transition.
  - *Mitigation*: Maintain temporary 10-day buffer stocks during the 30-day initial rollout phase.

## 8. Final Recommendations and Conclusion
The proposed dual-phase intervention establishes operational discipline and predictable fulfillment cycles.
Immediate execution of Phase 1 quick wins will generate self-funding cost savings to support the Phase 2 software
and cross-docking enhancements.
"""

    return [analysis_response, strategy_response]


def run_logistics_system(
    products: List[str],
    focus: str,
    model: Optional[str] = None,
    output_dir: str = "output",
    dry_run: bool = False,
    verbose: bool = True,
) -> None:
    """Executes the logistics crew workflow with full configuration and error handling."""
    os.makedirs(output_dir, exist_ok=True)
    analysis_file = os.path.join(output_dir, "logistics_analysis_report.md")
    strategy_file = os.path.join(output_dir, "logistics_optimization_report.md")

    print("\n" + "=" * 70)
    print("  AI-POWERED LOGISTICS OPTIMIZATION SYSTEM (CREWAI)")
    print("=" * 70)
    print(f"Products to Analyze : {products}")
    print(f"Logistics Focus     : {focus}")
    print(f"Execution Mode      : {'DRY-RUN (Offline Structural Simulation)' if dry_run else 'LIVE LLM EXECUTION'}")
    if model:
        print(f"Selected Model      : {model}")
    print(f"Output Directory    : {output_dir}")
    print("=" * 70 + "\n")

    # Format products for CrewAI prompt template
    products_display = ", ".join(products)

    crew_inputs = {
        "products": products_display,
        "logistics_focus": focus,
    }

    if dry_run:
        print("[INFO] Running in offline dry-run mode...")
        print("[INFO] Initializing structural CrewAI components (Agents, Tasks, Process)...")
        # Initialize with lightweight LLM wrapper
        from crewai import LLM
        mock_llm = LLM(model="gpt-4o-mini", api_key="dry-run-simulation-key")
        crew, analyst, strategist, t1, t2 = build_logistics_crew(
            llm=mock_llm,
            analysis_output_file=analysis_file,
            strategy_output_file=strategy_file,
            verbose=verbose,
        )

        sim_responses = generate_simulated_responses(products, focus)

        # Patch completion call to simulate offline agent execution
        with patch.object(OpenAICompletion, "call", side_effect=sim_responses):
            result = crew.kickoff(inputs=crew_inputs)

        # Ensure output files exist
        if not os.path.exists(analysis_file):
            with open(analysis_file, "w", encoding="utf-8") as f:
                f.write(sim_responses[0])
        if not os.path.exists(strategy_file):
            with open(strategy_file, "w", encoding="utf-8") as f:
                f.write(sim_responses[1])

        print("\n" + "=" * 70)
        print("  DRY-RUN VALIDATION COMPLETED SUCCESSFULLY")
        print("=" * 70)
        print(f"[OK] Agent 1 ({analyst.role}) completed Task 1.")
        print(f"[OK] Agent 2 ({strategist.role}) completed Task 2 with Task 1 context.")
        print(f"[OK] Sequential workflow validated.")
        print(f"[OK] Analysis Report saved to     : {analysis_file}")
        print(f"[OK] Optimization Report saved to : {strategy_file}")
        print("=" * 70 + "\n")
        return

    # Live LLM execution
    try:
        llm = get_llm(model=model)
    except LogisticsConfigurationError as err:
        print("\n[CONFIGURATION ERROR]")
        print(str(err))
        print("\nTo test the complete workflow offline without an API key, run:")
        print("    python main.py --dry-run\n")
        sys.exit(1)

    print(f"[INFO] Initializing CrewAI with LLM: {llm.model}...")
    crew, analyst, strategist, t1, t2 = build_logistics_crew(
        llm=llm,
        analysis_output_file=analysis_file,
        strategy_output_file=strategy_file,
        verbose=verbose,
    )

    print("[INFO] Starting Crew execution (Sequential Process)...")
    try:
        result = crew.kickoff(inputs=crew_inputs)
        print("\n" + "=" * 70)
        print("  CREW EXECUTION COMPLETED SUCCESSFULLY")
        print("=" * 70)
        print(f"[OK] Analysis Report saved to     : {analysis_file}")
        print(f"[OK] Optimization Report saved to : {strategy_file}")
        print("=" * 70 + "\n")

        # Fallback safeguard: write if file wasn't created by CrewAI
        if not os.path.exists(strategy_file) and result:
            with open(strategy_file, "w", encoding="utf-8") as f:
                f.write(str(result))

    except Exception as exc:
        print(f"\n[EXECUTION ERROR] An error occurred during CrewAI execution: {exc}")
        print("\nTroubleshooting tips:")
        print("1. Verify your API key has available quota.")
        print("2. Verify network connectivity to the model provider.")
        print("3. Run 'python main.py --dry-run' to test offline.")
        sys.exit(1)


def main():
    """Main CLI entrypoint."""
    args = parse_arguments()

    try:
        product_list = sanitize_product_list(args.products)
    except LogisticsValidationError as err:
        print(f"\n[VALIDATION ERROR] {err}\n")
        sys.exit(1)

    run_logistics_system(
        products=product_list,
        focus=args.focus,
        model=args.model,
        output_dir=args.output_dir,
        dry_run=args.dry_run,
        verbose=not args.quiet,
    )


if __name__ == "__main__":
    main()
