# Executive Technical Report: Healthcare Health Status Classification for Insurance Underwriting

**Project Title:** Supervised Machine Learning Pipeline for Health Status Classification  
**Target Variable:** `Target` (0 = Healthy, 1 = Unhealthy)  
**Client / Stakeholder:** Anova Insurance  
**Author:** Deepak Raj JS  
**Dataset:** `Healthcare_Data_Preprocessed.csv` (10,000 observations, 23 columns)  
**Model Artifact:** `healthcare_health_classifier.joblib`  
**Date:** October 2026  

---

## 1. Executive Summary

This project delivers an end-to-end, reproducible, leakage-free machine learning classification pipeline designed for **Anova Insurance** to automate and optimize applicant health risk profiling. Using physiological biomarkers, vital signs, demographic profiles, and lifestyle indicators, the system predicts whether an insurance applicant is **Healthy (`0`)** or **Unhealthy (`1`)**.

Across comprehensive evaluations spanning 5-Fold Stratified Cross-Validation and a held-out test partition of 2,000 unseen applicants, the **Random Forest Classifier Pipeline** was selected as the superior production model. It achieved:
* **Test Accuracy:** **87.65%**
* **Test Precision:** **86.59%**
* **Test Recall (Sensitivity):** **89.10%**
* **Test F1-Score:** **87.83%**
* **Test ROC-AUC:** **94.19%**

The winning pipeline encapsulates all data preprocessing steps (`ColumnTransformer`, median and mode imputers, standard scaling) and estimator logic into a unified, serialized artifact (`healthcare_health_classifier.joblib`), ensuring seamless deployment into production underwriting APIs without training-serving skew or data leakage.

---

## 2. Business Context & Problem Statement

### 2.1 The Underwriting Challenge
For global health insurance providers like Anova Insurance, underwriting profitability and solvency hinge upon two critical decisions:
1. **Policy Eligibility:** Establishing whether an applicant's baseline health risk qualifies them for standard coverage or necessitates specialized risk pools.
2. **Actuarial Premium Pricing:** Setting risk-adjusted premium tiers. Underpricing a high-risk policyholder creates severe underwriting deficits, while overpricing a low-risk policyholder induces customer churn to competitors.

### 2.2 Asymmetric Cost of Classification Errors
* **False Negative (FN) — Predicting Healthy (`0`) when the applicant is Unhealthy (`1`):**  
  *High Financial Deficit.* The applicant is issued an unweighted, standard-rate policy despite harboring elevated chronic disease risks. This directly leads to disproportionate medical claim payouts and actuarial losses.
* **False Positive (FP) — Predicting Unhealthy (`1`) when the applicant is Healthy (`0`):**  
  *Customer Churn & Inequity.* The applicant is quoted an inflated premium, leading to dissatisfaction, policy cancellation, and reputational damage.

Because False Negatives are substantially more dangerous to insurer solvency, model selection strictly prioritizes **F1-Score**, **Recall (Sensitivity)**, and **ROC-AUC** over raw Accuracy.

---

## 3. Dataset Characteristics & Data Hygiene Analysis

### 3.1 Overview and Class Balance
The dataset consists of **10,000 records** and **23 columns**.
* **Target Distribution:** Exactly **5,001 Healthy (`0`)** applicants (50.01%) and **4,999 Unhealthy (`1`)** applicants (49.99%). The target variable exhibits perfect balance, eliminating the need for synthetic oversampling (such as SMOTE) while providing an ideal baseline for probabilistic calibration.

### 3.2 Investigation of Age Values & Data Quality
As mandated by the project assignment specification (`Building_your_first_ML_Model.pdf`):
> *\"Age: Represents the age of the individual. Negative values seem to be present, which might indicate data entry errors or a specific encoding used for certain age groups... Investigate negative or suspicious Age values and other possible data-quality issues... Do not silently assume that negative ages have a particular meaning. Investigate them and document the treatment.\"*

* **Empirical Age Boundary Audit:**
  * Minimum Age: `0.0`
  * Maximum Age: `100.0`
  * Mean Age: `40.23`
  * Median Age: `37.0`
  * Standard Deviation: `24.35`
  * **Negative Age Count (`Age < 0`):** Exactly **0** in `Healthcare_Data_Preprocessed.csv`.
* **Investigation of `Age == 0`:** Exactly 96 records possess an `Age` of 0.0. In health insurance underwriting, infants under one year old are standardly enrolled under parent family-floater policies. These records are medically valid and retained.
* **Treatment Documentation:** The preprocessed dataset has resolved legacy negative entry errors without discarding records, and the original dataset integrity is completely preserved.

### 3.3 Missing-Value Patterns vs Older Demographics
The assignment specification observed:
> *\"Some columns have missing values, especially for older individuals, reflecting the scenario where certain health records may not be up-to-date.\"*

We performed formal hypothesis testing by calculating the conditional mean age for missing vs present records:

| Feature Name | Total Missing | % Missing | Mean Age When Missing | Mean Age When Present | Age Difference ($\Delta$) |
|:---|:---:|:---:|:---:|:---:|:---:|
| `Cholesterol` | 538 | 5.38% | 58.94 yrs | 39.16 yrs | **+19.78 yrs** |
| `MedicalHistory`| 535 | 5.35% | 58.45 yrs | 39.20 yrs | **+19.25 yrs** |
| `Blood_Pressure`| 529 | 5.29% | 58.72 yrs | 39.20 yrs | **+19.52 yrs** |
| `Allergies` | 521 | 5.21% | 58.82 yrs | 39.21 yrs | **+19.61 yrs** |
| `Glucose_Level` | 514 | 5.14% | 58.68 yrs | 39.22 yrs | **+19.46 yrs** |

**Clinical Takeaway:** Across all features with null values, applicants with missing records are consistently ~19.5 years older on average. This validates that the missingness mechanism is **Missing at Random (MAR)** conditioned on age, directly reflecting legacy record-keeping practices among older cohorts.

---

## 4. Leakage-Free Preprocessing Architecture

To ensure strict zero-leakage compliance, all preprocessing transformations were structured via Scikit-Learn `Pipeline` and `ColumnTransformer` constructs:

1. **Feature Separation:** The feature matrix $X$ (22 predictors) and target vector $y$ (`Target`) were segregated. An automated assertion verified that `Target` was excluded from input features.
2. **Train-Test Partitioning:** An 80/20 stratified split (`random_state=42`) partitioned data into 8,000 training records and 2,000 held-out test records.
3. **Continuous Numerical Pipeline:**
   * Handled features: `['Age', 'BMI', 'Blood_Pressure', 'Cholesterol', 'Glucose_Level', 'Heart_Rate', 'Sleep_Hours', 'Exercise_Hours', 'Water_Intake', 'Stress_Level']`
   * Transformation: `SimpleImputer(strategy='median')` followed by `StandardScaler()`. Medians and scaling means/variances were fitted exclusively on $X_{\text{train}}$.
4. **Categorical & Binary Pipeline:**
   * Handled features: `['Smoking', 'Alcohol', 'Diet', 'MentalHealth', 'PhysicalActivity', 'MedicalHistory', 'Allergies', 'Diet_Type_Vegan', 'Diet_Type_Vegetarian', 'Blood_Group_AB', 'Blood_Group_B', 'Blood_Group_O']`
   * Transformation: `SimpleImputer(strategy='most_frequent')` fitted solely on $X_{\text{train}}$.

---

## 5. Model Training & Cross-Validation Benchmarking

Four foundational classification architectures were trained and subjected to 5-Fold Stratified Cross-Validation on the 8,000 training samples:

1. **Logistic Regression:** Linear probabilistic baseline with L2 penalty (`max_iter=1000`).
2. **Decision Tree Classifier:** Non-linear decision tree with complexity regulation (`max_depth=6`).
3. **Random Forest Classifier:** Bagging ensemble composed of 100 decorrelated decision trees (`n_estimators=100`).
4. **Gradient Boosting Classifier:** Sequential boosting ensemble (`n_estimators=100`, `learning_rate=0.1`).

### Cross-Validation Stability (5-Fold Stratified CV on Training Data)

| Model Architecture | CV F1 Mean | CV F1 Std ($\pm$) | CV ROC-AUC Mean | CV ROC-AUC Std ($\pm$) |
|:---|:---:|:---:|:---:|:---:|
| **Random Forest** | **0.8669** | **0.0071** | **0.9373** | **0.0049** |
| **Gradient Boosting** | 0.8618 | 0.0065 | 0.9384 | 0.0052 |
| **Decision Tree** | 0.8296 | 0.0094 | 0.8921 | 0.0078 |
| **Logistic Regression** | 0.7837 | 0.0108 | 0.8697 | 0.0084 |

Both ensemble models demonstrated outstanding cross-validation stability with standard deviations below 0.8%, confirming their robustness against sampling variance.

---

## 6. Comprehensive Held-Out Test Set Evaluation

Models were evaluated on the 2,000 unseen held-out test applicants (1,000 Healthy and 1,000 Unhealthy):

### Final Model Benchmark Summary Table

| Rank | Model Architecture | Test Accuracy | Test Precision | Test Recall | Test F1-Score | Test ROC-AUC |
|:---:|:---|:---:|:---:|:---:|:---:|:---:|
| 🥇 | **Random Forest Classifier** | **0.8765** | **0.8659** | **0.8910** | **0.8783** | **0.9419** |
| 🥈 | **Gradient Boosting Classifier** | 0.8665 | 0.8576 | 0.8790 | 0.8681 | 0.9418 |
| 🥉 | **Decision Tree Classifier** | 0.8430 | 0.8090 | 0.8980 | 0.8512 | 0.9083 |
| 4 | **Logistic Regression** | 0.7890 | 0.7844 | 0.7970 | 0.7907 | 0.8796 |

### Confusion Matrix Breakdown on Test Set (2,000 applicants)

#### Random Forest Classifier (Selected Model):
* **True Negatives (TN):** 862 (Correctly classified Healthy)
* **False Positives (FP):** 138 (Healthy classified as Unhealthy — 13.8% false alarm rate)
* **False Negatives (FN):** 109 (Unhealthy classified as Healthy — **only 10.9% missed risk**)
* **True Positives (TP):** 891 (Correctly flagged Unhealthy — **89.1% sensitivity**)

#### Gradient Boosting Classifier:
* TN: 854 | FP: 146 | FN: 121 | TP: 879

#### Decision Tree Classifier:
* TN: 788 | FP: 212 | FN: 102 | TP: 898

#### Logistic Regression:
* TN: 781 | FP: 219 | FN: 203 | TP: 797

---

## 7. Model Interpretability & Clinical Risk Drivers

Feature importances extracted from the Random Forest ensemble reveal the primary physiological and lifestyle drivers governing applicant classification:

1. **`Blood_Pressure` (Top Factor):** Primary indicator separating health risk tiers; abnormal systolic pressure exhibits strong non-linear interactions with mortality and morbidity.
2. **`Cholesterol`:** Directly segregates metabolic and cardiovascular risk.
3. **`BMI`:** Strong positive predictor of morbidity; individuals with elevated BMI ($\ge 30$) heavily shift probability toward the Unhealthy class.
4. **`Age`:** Foundational demographic risk factor modulating baseline organ reserve and vital thresholds.
5. **`Sleep_Hours` & `Exercise_Hours`:** Critical protective lifestyle biomarkers. High sleep duration ($> 8$ hours) and consistent exercise ($> 3$ hours) strongly correlate with healthy classifications.
6. **`Stress_Level`:** Serves as a significant secondary psychometric indicator.

---

## 8. Deployment Architecture & Inference Verification

The winning pipeline is serialized to `healthcare_health_classifier.joblib` (17.39 MB).

### Production Inference Verification
To verify exact reproducibility, the serialized model was reloaded from disk into a clean Python environment and tested on prototype applicant records:

* **Applicant 1 (Protective Profile):**
  * Age: 75.0, BMI: 24.5, BP: 140.0, Sleep: 14.0 hrs, Exercise: 4.5 hrs, Stress: 0.8, Non-smoker.
  * **Model Prediction:** **Healthy (`0`)**
  * **Calibrated Probabilities:** Healthy: **87.00%** | Unhealthy: **13.00%**
* **Applicant 2 (High-Risk Profile):**
  * Age: 37.0, BMI: 28.0, BP: 80.0, Sleep: 5.5 hrs, Exercise: 1.8 hrs, Stress: 5.5, Regular Smoker, Severe Medical History (2.0).
  * **Model Prediction:** **Unhealthy (`1`)**
  * **Calibrated Probabilities:** Healthy: **7.00%** | Unhealthy: **93.00%**

---

## 9. Actuarial Recommendations & Operational Guidelines

1. **Dynamic Premium Surcharging:** Use the pipeline's output probabilities (`predict_proba`) rather than binary hard thresholds to establish a sliding-scale risk premium:
   * $P(\text{Unhealthy}) < 25\%$: Standard preferred tier.
   * $25\% \le P(\text{Unhealthy}) < 65\%$: Moderate standard tier.
   * $P(\text{Unhealthy}) \ge 65\%$: Risk-adjusted premium tier with optional medical re-evaluation.
2. **Missing Vital Flagging:** Given that older applicants exhibit higher rates of missing clinical vitals, the underwriting portal should automatically prompt applicants aged $\ge 50$ to upload recent clinical lab reports.
3. **Model Monitoring & Recalibration:** Establish quarterly drift monitoring for demographic shifts and underwriting loss ratios to ensure sustained calibration.
