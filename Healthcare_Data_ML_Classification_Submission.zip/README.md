# Healthcare Data ML Classification Project: Anova Insurance Health Status Prediction

An end-to-end, reproducible, leakage-free Supervised Machine Learning Classification project developed for **Anova Insurance** to classify insurance applicants as **Healthy (`0`)** or **Unhealthy (`1`)** for dynamic premium pricing and underwriting risk optimization.

[![Python](https://img.shields.io/badge/Python-3.14%2B-blue.svg)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-1.9.1-orange.svg)](https://scikit-learn.org/)
[![Pandas](https://img.shields.io/badge/pandas-3.0.5-150458.svg)](https://pandas.pydata.org/)
[![Status](https://img.shields.io/badge/Status-Complete%20%26%20Submission--Ready-brightgreen.svg)]()

---

## 1. Project Overview & Business Objective

### 1.1 Business Context
**Anova Insurance**, a global health insurance provider, seeks to modernize its underwriting protocol by leveraging machine learning to predict the underlying health status of insurance applicants. Health status classification directly influences two core operational decisions:
1. **Coverage Eligibility Determination:** Establishing whether an individual meets medical underwriting thresholds for standard health insurance policies.
2. **Actuarial Premium Surcharging:** Pricing premiums accurately based on actuarial risk. High-risk applicants require risk-weighted premiums to safeguard insurer solvency, whereas low-risk applicants must be offered competitive rates to prevent customer attrition.

### 1.2 Clinical & Financial Trade-offs
* **False Negative (FN) — Predicting Healthy (`0`) when an applicant is Unhealthy (`1`):**  
  *Extremely high financial risk.* The insurer underprices the risk and issues standard premiums to individuals with elevated chronic disease risks, resulting in disproportionate claim payouts and actuarial deficits.
* **False Positive (FP) — Predicting Unhealthy (`1`) when an applicant is Healthy (`0`):**  
  *Customer retention risk.* The insurer levies unnecessary premium surcharges on healthy individuals, prompting churn to competitor insurers and brand erosion.

Consequently, model selection cannot rely on raw **Accuracy** alone. Evaluation prioritizes **F1-Score**, **Recall (Sensitivity)**, and **ROC-AUC** to maximize high-risk applicant detection while maintaining balanced calibration.

---

## 2. Dataset Overview & Data Dictionary

The project utilizes the actual provided dataset: `Healthcare_Data_Preprocessed.csv`.
* **Total Observations:** 10,000 applicant records
* **Total Features:** 22 input features (10 continuous numerical vitals, 7 ordinal lifestyle/clinical factors, 5 dummy-encoded categorical indicators)
* **Target Column:** `Target` (`0` = Healthy, `1` = Unhealthy)
* **Class Balance:** Perfectly balanced (5,001 Healthy [50.01%] vs 4,999 Unhealthy [49.99%])

### Clinical Feature Dictionary

| Feature Name | Type | Unit / Encoding | Clinical Reference & Description |
|:---|:---|:---|:---|
| `Age` | Float | Years (0.0 – 100.0) | Age of applicant. Average is 40.23 years. |
| `BMI` | Float | $kg/m^2$ (19.0 – 32.0) | Body Mass Index. Normal: 18.5–24.9; Overweight: 25.0–29.9; Obese: $\ge 30$. |
| `Blood_Pressure` | Float | mmHg (22.0 – 225.0) | Systolic blood pressure. Normal: $\le 120$ mmHg; Stage 1 hypertension: $\ge 130$. |
| `Cholesterol` | Float | mg/dL (192.0 – 207.0) | Total serum cholesterol level. Desirable threshold: $< 200$ mg/dL. |
| `Glucose_Level` | Float | mg/dL (93.0 – 107.0) | Fasting blood glucose concentration. Normal fasting: 70–99 mg/dL. |
| `Heart_Rate` | Float | bpm (67.0 – 80.0) | Resting heart rate in beats per minute. Normal adult range: 60–100 bpm. |
| `Sleep_Hours` | Float | Hours/day (0.0 – 16.0) | Average daily sleep duration. |
| `Exercise_Hours` | Float | Hours/day (0.0 – 5.0) | Average daily exercise duration. |
| `Water_Intake` | Float | Liters/day (0.6 – 4.6) | Average daily water consumption. |
| `Stress_Level` | Float | Scale (0.0 – 10.0) | Psychometric stress level score. |
| `Smoking` | Integer | 0, 1, 2 | 0 = Non-smoker, 1 = Occasional smoker, 2 = Regular smoker. |
| `Alcohol` | Integer | 0, 1, 2 | 0 = Non-drinker, 1 = Moderate drinker, 2 = Regular drinker. |
| `Diet` | Integer | 0, 1, 2 | Dietary habit score: 0 = Poor diet quality, 2 = Good diet quality. |
| `MentalHealth` | Integer | 0, 1, 2 | Mental health severity: 0 = Fine/normal, 2 = Severe issues. |
| `PhysicalActivity` | Integer | 0, 1, 2 | Activity level: 0 = Sedentary, 1 = Moderately active, 2 = Regularly active. |
| `MedicalHistory` | Float | 0, 1, 2 | Chronic conditions: 0 = None, 1 = Moderate condition, 2 = Severe condition. |
| `Allergies` | Float | 0, 1, 2 | Allergy severity: 0 = None, 1 = Mild allergies, 2 = Severe allergies. |
| `Diet_Type_Vegan` | Boolean | True / False | Dietary classification indicator for Vegan diet. |
| `Diet_Type_Vegetarian`| Boolean | True / False | Dietary classification indicator for Vegetarian diet. |
| `Blood_Group_AB` | Boolean | True / False | Indicator for ABO Blood Group AB. |
| `Blood_Group_B` | Boolean | True / False | Indicator for ABO Blood Group B. |
| `Blood_Group_O` | Boolean | True / False | Indicator for ABO Blood Group O (reference baseline: Blood Group A). |
| `Target` | Integer | 0, 1 | **Target Variable:** `0` = Healthy, `1` = Unhealthy. |

---

## 3. Data Cleaning & Exploratory Findings

### 3.1 Investigation of `Age` and Suspicious Values
As highlighted in the project assignment specification (`Building_your_first_ML_Model.pdf`):
> *\"Age: Represents the age of the individual. Negative values seem to be present, which might indicate data entry errors or a specific encoding used for certain age groups... Investigate negative or suspicious Age values and other possible data-quality issues... Do not silently assume that negative ages have a particular meaning.\"*

* **Empirical Finding:** In `Healthcare_Data_Preprocessed.csv`, the age values span cleanly from `0.0` to `100.0` years (mean: 40.23 years, median: 37.0 years). Exactly `0` negative values exist (`Age < 0` count: 0).
* **Investigation of `Age == 0`:** Exactly 96 records have `Age == 0.0`. In family health insurance portfolios, newborns / pediatric dependents under 1 year old are routinely insured under parental umbrella policies.
* **Treatment Documentation:** The data retains all valid applicant records without arbitrary row deletion.

### 3.2 Missing-Value Analysis & Hypothesis Validation
The assignment documentation states:
> *\"Some columns have missing values, especially for older individuals, reflecting the scenario where certain health records may not be up-to-date.\"*

We empirically evaluated missingness against applicant age:
* `Cholesterol`: 538 missing values (5.38%)
* `MedicalHistory`: 535 missing values (5.35%)
* `Blood_Pressure`: 529 missing values (5.29%)
* `Allergies`: 521 missing values (5.21%)
* `Glucose_Level`: 514 missing values (5.14%)

**Statistical Validation:**
* Mean age when `Blood_Pressure` is **missing**: **58.72 years**
* Mean age when `Blood_Pressure` is **present**: **39.20 years**
* Difference: **+19.52 years older** for applicants with missing vitals.

This proves that missingness is not purely random (MCAR) but Missing at Random (MAR) conditioned on age, validating that older applicants often possess legacy health documentation.

---

## 4. Modeling Pipeline Architecture

To prevent **data leakage**, all data transformations are encapsulated inside a Scikit-Learn `Pipeline` combined with a `ColumnTransformer`. 

```
                                      Raw Input Data (22 Features)
                                                   │
                   ┌───────────────────────────────┴───────────────────────────────┐
                   ▼                                                               ▼
        Continuous Numerical Vitals                                    Categorical / Binary
    ['Age', 'BMI', 'Blood_Pressure', ...]                        ['Smoking', 'Alcohol', 'MedicalHistory', ...]
                   │                                                               │
                   ▼                                                               ▼
       Median SimpleImputer                                            Most Frequent SimpleImputer
     (Learned strictly from X_train)                                  (Learned strictly from X_train)
                   │                                                               │
                   ▼                                                               │
            StandardScaler                                                         │
     (Learned strictly from X_train)                                               │
                   │                                                               │
                   └───────────────────────────────┬───────────────────────────────┘
                                                   ▼
                                       ColumnTransformer Matrix
                                                   │
                                                   ▼
                                  Fitted Classifier (Random Forest)
                                                   │
                                                   ▼
                              Prediction: [0: Healthy] or [1: Unhealthy]
                                   Calibrated Class Probabilities
```

* **No Data Leakage:** Preprocessing parameters (medians, modes, scaling means, variances) are fitted exclusively on the 8,000 training instances (`X_train`) and merely applied to the held-out 2,000 test instances (`X_test`).
* **No Target Leakage:** `Target` is strictly isolated before any transformation.

---

## 5. Model Evaluation & Benchmark Results

All models were evaluated on the **2,000 held-out test applicants** using stratified splitting (`random_state=42`). In addition, **5-Fold Stratified Cross-Validation** was computed across the training set to verify generalization consistency.

### Benchmark Comparison Table

| Rank | Model Architecture | Accuracy | Precision | Recall (Sensitivity) | F1-Score | ROC-AUC | 5-Fold CV F1 Mean | 5-Fold CV AUC Mean |
|:---:|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 🥇 | **Random Forest Classifier** | **0.8765** | **0.8659** | **0.8910** | **0.8783** | **0.9419** | **0.8669** | **0.9373** |
| 🥈 | **Gradient Boosting Classifier** | 0.8665 | 0.8576 | 0.8790 | 0.8681 | 0.9418 | 0.8618 | 0.9384 |
| 🥉 | **Decision Tree Classifier** | 0.8430 | 0.8090 | 0.8980 | 0.8512 | 0.9083 | 0.8296 | 0.8921 |
| 4 | **Logistic Regression** | 0.7890 | 0.7844 | 0.7970 | 0.7907 | 0.8796 | 0.7837 | 0.8697 |

### Detailed Performance Analysis of the Selected Model (Random Forest):
* **Accuracy (87.65%):** Outperforms linear baselines by +8.75% absolute points.
* **Recall (89.10%):** Successfully identifies 891 out of 1,000 actual unhealthy applicants in the test set.
* **Precision (86.59%):** Out of all applicants flagged as Unhealthy, 86.6% are true high-risk cases.
* **F1-Score (87.83%):** Highest harmonic mean of precision and recall.
* **ROC-AUC (0.9419):** Outstanding discrimination across varying underwriting cut-offs.

---

## 6. Feature Importance & Clinical Interpretation

Intrinsic Gini feature importance (Mean Decrease in Impurity) extracted from the top-performing ensemble highlights the primary clinical and lifestyle drivers:

1. **`Blood_Pressure` (Top continuous driver):** Blood pressure variance provides strong risk signals for cardiovascular and hypertensive conditions.
2. **`Cholesterol`:** Directly separates metabolic and arterial risk.
3. **`BMI`:** Strong positive correlation with health risk; elevated BMI ($\ge 30$) heavily weights toward the Unhealthy class.
4. **`Age`:** Significant demographic factor influencing baseline risk and clinical vital expectations.
5. **`Sleep_Hours` & `Exercise_Hours`:** Key protective lifestyle factors; high sleep and exercise correlate strongly with healthy policyholders.
6. **`Stress_Level`:** Psychosomatic stress acts as an effective secondary indicator.

---

## 7. Model Serialization & Production Inference

The winning pipeline is serialized to **`healthcare_health_classifier.joblib`**. The saved artifact contains the complete preprocessing pipeline (`ColumnTransformer`), encoders, and the trained estimator.

### How to Load and Run Inference in Python

```python
import joblib
import pandas as pd

# 1. Load the serialized pipeline artifact
pipeline = joblib.load('healthcare_health_classifier.joblib')

# 2. Prepare new applicant records (adhering to the feature schema)
new_applicant = pd.DataFrame([{
    'Age': 35.0,
    'BMI': 23.5,
    'Blood_Pressure': 120.0,
    'Cholesterol': 195.0,
    'Glucose_Level': 95.0,
    'Heart_Rate': 70.0,
    'Sleep_Hours': 8.5,
    'Exercise_Hours': 3.0,
    'Water_Intake': 2.5,
    'Stress_Level': 2.0,
    'Smoking': 0,
    'Alcohol': 0,
    'Diet': 2,
    'MentalHealth': 0,
    'PhysicalActivity': 2,
    'MedicalHistory': 0.0,
    'Allergies': 0.0,
    'Diet_Type_Vegan': True,
    'Diet_Type_Vegetarian': False,
    'Blood_Group_AB': False,
    'Blood_Group_B': False,
    'Blood_Group_O': True
}])

# 3. Predict class and class probabilities
prediction = pipeline.predict(new_applicant)[0]
probabilities = pipeline.predict_proba(new_applicant)[0]

status = "Unhealthy (1)" if prediction == 1 else "Healthy (0)"
print(f"Predicted Health Status : {status}")
print(f"Healthy Probability     : {probabilities[0] * 100:.2f}%")
print(f"Unhealthy Probability   : {probabilities[1] * 100:.2f}%")
```

---

## 8. Repository Structure

```
├── Healthcare_Data_ML_Classification.ipynb  # Primary, fully executed 19-section Jupyter Notebook
├── Healthcare_Data_Preprocessed.csv         # Verified, complete healthcare dataset (10,000 rows)
├── Building_your_first_ML_Model.pdf         # Original assignment project specification
├── healthcare_health_classifier.joblib      # Production-ready serialized pipeline artifact
├── model_evaluation_summary.csv             # Benchmark comparison metrics across all models
├── README.md                                # Comprehensive project documentation
```

---

## 9. How to Run the Project Locally

### Prerequisites
* Python 3.10+
* Standard scientific Python stack (`scikit-learn`, `pandas`, `numpy`, `matplotlib`, `seaborn`, `joblib`)

### Installation & Execution
```bash
# 1. Clone or navigate to the project directory
cd "d:\Projects\Analytics vidhya\Healthcare Data ML Classification Project"

# 2. Install dependencies (if not already installed)
pip install scikit-learn pandas numpy matplotlib seaborn joblib nbformat nbclient

# 3. Launch Jupyter Notebook or JupyterLab
jupyter notebook Healthcare_Data_ML_Classification.ipynb
```
The notebook is self-contained and pre-executed. All plots, classification tables, and evaluation metrics will display immediately. You can also re-execute from top to bottom (`Cell -> Run All`) without manual intervention.
