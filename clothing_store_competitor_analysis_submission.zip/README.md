# RetailPulse AI: Clothing Store Competitor Analysis Agent
### *Autonomous Conversational AI Pipeline for Apparel Retail Intelligence in Koramangala, Bangalore*

---

## 📌 Project Overview

**RetailPulse AI** is an enterprise-grade Conversational AI system engineered using **Python, LangChain, and Streamlit**. It automates competitive intelligence and market benchmarking for clothing store retailers in **Koramangala, Bangalore** (and configurable to other retail corridors). 

The pipeline discovers apparel competitors, profiles store specializations and price tiers, evaluates public sentiment and rating distributions, analyzes customer footfall patterns and peak hours, and synthesizes structured, executive-ready business intelligence reports.

### 🛡️ Strict Footfall Truthfulness & Epistemological Policy
Retail intelligence projects frequently suffer from LLM hallucinations—specifically the invention of precise visitor metrics (e.g., claiming "2,500 people visited on Saturday"). 

**RetailPulse AI strictly enforces zero-hallucination data governance:**
1. **Never Fabricates Metrics:** In-store visitor counts, camera turnstile telemetry, and sensor data are confidential corporate assets. When not publicly reported by verified corporate sources, they are strictly and explicitly labeled as **`Unavailable`**.
2. **Proprietary Telemetry Acknowledgment:** The agent explicitly discloses that live Google Maps Popular Times telemetry and private sensor graphs are proprietary and cannot be queried via standard public web search APIs.
3. **Three-Tier Epistemological Classification:** All intelligence is categorized into:
   - **`[VERIFIED FACTS]`**: Officially registered addresses, operating hours, official product lines.
   - **`[THIRD-PARTY ESTIMATES]`**: Aggregator review counts (Google Maps, Justdial), star ratings, customer review crowd descriptions.
   - **`[ANALYTICAL INFERENCES]`**: Locality context, dining/nightlife spillover, anchor tenant gravity (e.g., Nexus Koramangala Mall).

---

## 🏗️ System Architecture

```mermaid
flowchart TD
    User([User / Retail Strategist]) --> Streamlit[Streamlit Web Application (app.py)]
    Streamlit --> Pipeline[Conversational AI Pipeline (agent/pipeline.py)]
    
    subgraph LangChain / LangGraph Engine
        Pipeline --> Memory[(Chat Conversation Memory)]
        Pipeline --> LLM{LLM Available?}
        LLM -- Yes --> ReAct[LangGraph ReAct Agent]
        LLM -- No (Graceful Fallback) --> Deterministic[Deterministic Analytical Engine]
    end

    subgraph Custom LangChain Tools (@tool)
        ReAct & Deterministic --> Tool1["discover_clothing_competitors"]
        ReAct & Deterministic --> Tool2["analyze_competitor_details"]
        ReAct & Deterministic --> Tool3["generate_competitor_report"]
    end

    subgraph Multi-Tier Search & Knowledge Layer
        Tool1 & Tool2 --> SearchService[Search Service (agent/search_service.py)]
        SearchService --> Tier1[Tier 1: Tavily AI Search API]
        SearchService --> Tier2[Tier 2: DuckDuckGo Live Search]
        SearchService --> Tier3[Tier 3: Curated Public Store Knowledge Base]
    end

    subgraph Report & Artifacts
        Tool3 --> ReportGen[CompetitorReportGenerator (agent/report_generator.py)]
        ReportGen --> Rep[8-Section Executive Markdown Report]
        Rep --> Download[Download .md / .txt]
    end
```

---

## 🛠️ Key Components & Workflow

### 1. Custom LangChain Tools (`agent/tools.py`)
- **`@tool discover_clothing_competitors(locality, category)`**: Queries the multi-tier search layer to discover clothing brands, addresses, clothing categories, review metrics, source URLs, and peak-hour statuses.
- **`@tool analyze_competitor_details(store_name, locality)`**: Executes a deep dive into an individual brand (e.g., *Fabindia Experience Centre*, *Manyavar & Mohey*, *Rare Rabbit*, *Westside*, *Zara*), structuring output into Verified Facts, Third-Party Estimates, and Analytical Inferences.
- **`@tool generate_competitor_report(locality, category)`**: Compiles the comprehensive 8-section executive report with Markdown comparison tables, market opportunities, and sourced reference links.

### 2. Multi-Provider LLM & Graceful Degradation (`agent/config.py`)
Supports automatic detection of whichever credentials are configured in `.env` or input via the Streamlit UI:
- **OpenAI** (`gpt-4o-mini`, `gpt-4o`) via `langchain-openai`
- **Google Gemini** (`gemini-1.5-flash`, `gemini-2.0-flash`) via `langchain-google-genai`
- **Groq** (`llama-3.3-70b-versatile`) via `langchain-groq`
- **Offline / Zero-Key Fallback**: Fully functional deterministic analytical engine that routes tools, computes comparative metrics, and generates reports even without an LLM key.

### 3. Multi-Tier Search Layer (`agent/search_service.py`)
- **Primary**: Tavily AI Search client with advanced search depth.
- **Secondary**: DuckDuckGo search integration (`ddgs`) requiring zero credentials.
- **Tertiary**: Curated, verified public dataset of Koramangala apparel retailers with real addresses, verified categories, and verified review counts.

---

## 📂 Project Structure

```
Creating a Conversational AI/
├── agent/
│   ├── __init__.py              # Package exports
│   ├── config.py                # Environment management, LLM provider factory
│   ├── models.py                # Pydantic schemas (CompetitorInfo, SearchResult)
│   ├── search_service.py        # Tavily + DuckDuckGo + Curated Public fallback
│   ├── tools.py                 # Custom LangChain @tool definitions
│   ├── report_generator.py      # 8-section report generator enforcing truthfulness
│   └── pipeline.py              # Conversational agent with memory & fallback router
├── tests/
│   ├── __init__.py
│   ├── test_tools.py            # Unit tests for discovery & analysis tools
│   ├── test_footfall_policy.py  # Tests verifying strict footfall truthfulness
│   ├── test_report.py           # Tests for report structure and mandatory sections
│   └── test_agent.py            # Tests for conversational memory and missing API keys
├── app.py                       # Modern, aesthetic Streamlit Web Interface
├── sample_report.md             # Complete sample report for Koramangala
├── requirements.txt             # Project dependencies
├── .env.example                 # Environment variables template
└── README.md                    # Project documentation
```

---

## 🚀 Installation & Setup

### 1. Prerequisites
- Python 3.10+ (tested and verified on Python 3.14)
- Internet connection for search tools and LLM APIs

### 2. Clone / Navigate to Directory
```bash
cd "d:/Projects/Analytics vidhya/Creating a Conversational AI"
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure API Keys (`.env`)
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Open `.env` in a text editor and add your credentials:
```env
# Tavily Search API (https://tavily.com)
TAVILY_API_KEY=tvly-your_tavily_api_key_here

# At least one LLM Provider:
OPENAI_API_KEY=sk-your_openai_api_key_here
# OR
GOOGLE_API_KEY=your_gemini_api_key_here
# OR
GROQ_API_KEY=gsk_your_groq_api_key_here
```
> **Note:** If no API keys are provided, the system gracefully operates in offline analytical mode with DuckDuckGo and the verified public knowledge base. You can also input or override keys directly in the Streamlit web sidebar!

---

## 💻 Running the Application

### Launch Streamlit Web UI
```bash
streamlit run app.py
```
Or with Python launcher:
```bash
py -m streamlit run app.py
```
Open [http://localhost:8501](http://localhost:8501) in your browser.

---

## 🧪 Running the Automated Test Suite

A comprehensive test suite of 20 unit and integration tests verifies the entire pipeline:
```bash
pytest tests -v
```
Or via the Python launcher:
```bash
py -m pytest tests -v
```

### Test Coverage Highlights:
- ✅ **`test_tools.py`**: Validates discovery output schema, empty input handling, arbitrary store web profiling, and report generation tools.
- ✅ **`test_footfall_policy.py`**: Strictly asserts that all store profiles mark footfall as `Unavailable`, checks that peak hours are labeled as review estimates, and verifies non-hallucination disclaimers.
- ✅ **`test_report.py`**: Verifies that all 8 mandatory sections (Executive Summary, Competitor Matrix, Footfall Insights, Peak Hours, Market Opportunities, Marketing Strategies, Limitations, Sourced Links) are generated with valid dates and URLs.
- ✅ **`test_agent.py`**: Tests graceful initialization without credentials, conversational memory across multiple turns, and error handling.

---

## 💡 Example Conversational Queries

Users can ask natural language questions in the Streamlit chat interface:
1. **Competitor Discovery:**
   > *"What clothing stores are located in Koramangala, and what are their ratings?"*
2. **Category-Specific Inquiries:**
   > *"Which store is the best competitor for men's ethnic and wedding wear?"*
3. **Footfall & Peak Hours:**
   > *"What are the observed peak hours for Fabindia and Manyavar, and what is their footfall status?"*
4. **Competitive Strategy:**
   > *"What marketing strategy would you recommend for an independent clothing boutique opening on 80 Feet Road to compete with Westside and Rare Rabbit?"*
5. **Full Report Compilation:**
   > *"Generate a complete competitor analysis report for Koramangala clothing retail."*

---

## 📊 Structured Report Deliverable

The agent produces a comprehensive business intelligence report containing:
1. **Executive Summary**
2. **Competitor Comparison Matrix** (Markdown table with store names, addresses, categories, price tiers, ratings, footfall status, peak hours status, and source links)
3. **Available Footfall Insights** (Explaining private turnstile sensor realities and distinguishing verified facts vs review estimates vs inferences)
4. **Peak-Hour Analysis** (Shopper review patterns vs unavailable sensor distributions)
5. **Detailed Competitor Profiles** (3-tier epistemological breakdown)
6. **Market Opportunities in Koramangala** (Gaps in sustainable Gen-Z apparel, fast bespoke tailoring, and experiential retail)
7. **Recommended Marketing & Merchandising Strategies** (Hyperlocal geotargeted social ads, weekend evening activations, quick-commerce delivery)
8. **Limitations & Data Caveats** (Data currency, aggregator bias, absence of hardware sensor telemetry)
9. **Sourced Reference Links & Retrieval Log** (Entity, URL, engine, and retrieval timestamp)

A ready-to-inspect pre-generated report is included in [sample_report.md](file:///d:/Projects/Analytics%20vidhya/Creating%20a%20Conversational%20AI/sample_report.md).

---

## 📄 License & Attribution
Developed for Analytics Vidhya Conversational AI Assignment. Built with LangChain, LangGraph, Streamlit, and Python.
