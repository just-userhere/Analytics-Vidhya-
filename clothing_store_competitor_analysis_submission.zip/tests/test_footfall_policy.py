"""Tests validating strict Footfall Truthfulness and Epistemological Integrity."""

import pytest
from agent.search_service import CompetitorSearchService, VERIFIED_KORAMANGALA_STORES
from agent.tools import analyze_competitor_details, generate_competitor_report
from agent.pipeline import CompetitorAnalysisPipeline


def test_footfall_status_is_strictly_unavailable_in_knowledge_base():
    """Validates that all stores in the knowledge base strictly designate footfall as Unavailable."""
    for store in VERIFIED_KORAMANGALA_STORES:
        assert store["footfall_status"] == "Unavailable"
        assert "Unavailable" in store["reported_footfall"]
        # Ensure no fabricated claims of raw sensor counts (e.g. '1500 visitors/day')
        assert "per day" not in store["reported_footfall"].lower()
        assert "exact" in store["reported_footfall"].lower() or "not" in store["reported_footfall"].lower()


def test_peak_hours_status_distinguishes_estimates_from_counts():
    """Validates that peak hours do not claim exact counts and are labeled as review estimates."""
    for store in VERIFIED_KORAMANGALA_STORES:
        assert store["peak_hours_status"] in [
            "Estimated from customer review patterns",
            "Estimated from mall review patterns",
            "Unavailable"
        ]
        assert "Unavailable" in store["peak_hours"]


def test_competitor_analysis_output_truthfulness():
    """Tests that analyze_competitor_details clearly warns that footfall is not fabricated."""
    output = analyze_competitor_details.invoke({"store_name": "Fabindia", "locality": "Koramangala, Bangalore"})
    assert "Reported Footfall: Unavailable" in output
    assert "Data Integrity: Exact footfall counts were not fabricated" in output
    assert "VERIFIED FACTS" in output
    assert "THIRD-PARTY ESTIMATES" in output
    assert "ANALYTICAL INFERENCES" in output


def test_report_includes_footfall_integrity_notice():
    """Validates that the generated report contains the explicit data disclosure notice."""
    report = generate_competitor_report.invoke({"locality": "Koramangala, Bangalore", "category": "All"})
    assert "Data Disclosure & Integrity Notice" in report
    assert "no footfall counts, turnstile numbers, or pedestrian sensor data have been fabricated" in report
    assert "private, proprietary" in report
    assert "Google Maps Popular Times telemetry is proprietary and inaccessible" in report


def test_pipeline_footfall_query_truthfulness():
    """Tests that user questions directly asking about footfall yield truthful, non-hallucinated answers."""
    pipeline = CompetitorAnalysisPipeline()
    response = pipeline.run_query("What is the exact footfall count for Zara and Fabindia in Koramangala?")
    assert "Unavailable" in response
    assert "Sensor Footfall Data" in response
    assert "Proprietary" in response or "proprietary" in response
