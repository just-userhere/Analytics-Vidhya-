"""Unit tests for LangChain competitor discovery and analysis tools."""

import json
import pytest
from agent.tools import (
    discover_clothing_competitors,
    analyze_competitor_details,
    generate_competitor_report,
)


def test_discover_clothing_competitors_default():
    """Tests discovery tool with default Koramangala parameters."""
    res_str = discover_clothing_competitors.invoke({"locality": "Koramangala, Bangalore", "category": "All"})
    assert isinstance(res_str, str)
    data = json.loads(res_str)
    
    assert data["locality"] == "Koramangala, Bangalore"
    assert "stores" in data
    assert len(data["stores"]) > 0
    
    # Verify first store attributes
    first_store = data["stores"][0]
    assert "store_name" in first_store
    assert "address" in first_store
    assert "clothing_category" in first_store
    assert "footfall_status" in first_store
    assert first_store["footfall_status"] == "Unavailable"
    assert "source_urls" in first_store


def test_discover_clothing_competitors_category_filter():
    """Tests discovery tool when filtering by Ethnic category."""
    res_str = discover_clothing_competitors.invoke({"locality": "Koramangala, Bangalore", "category": "Ethnic"})
    data = json.loads(res_str)
    store_names = [s["store_name"] for s in data["stores"]]
    assert any("Fabindia" in name or "Manyavar" in name for name in store_names)


def test_discover_empty_locality_fallback():
    """Tests graceful handling when locality is empty."""
    res_str = discover_clothing_competitors.invoke({"locality": "", "category": ""})
    data = json.loads(res_str)
    assert data["locality"] == "Koramangala, Bangalore"
    assert len(data["stores"]) > 0


def test_analyze_competitor_details_existing_store():
    """Tests deep-dive analysis on Fabindia in Koramangala."""
    res = analyze_competitor_details.invoke({"store_name": "Fabindia", "locality": "Koramangala, Bangalore"})
    assert "COMPETITIVE INTELLIGENCE PROFILE: Fabindia" in res
    assert "1. VERIFIED FACTS" in res
    assert "2. THIRD-PARTY ESTIMATES" in res
    assert "3. ANALYTICAL INFERENCES" in res
    assert "Unavailable" in res
    assert "Source Links:" in res
    assert "Retrieval Date:" in res


def test_analyze_competitor_details_empty_input():
    """Tests graceful error handling for empty store name."""
    res = analyze_competitor_details.invoke({"store_name": "", "locality": "Koramangala, Bangalore"})
    assert "Error:" in res


def test_analyze_competitor_details_arbitrary_store():
    """Tests analysis of a non-curated store name through web search profiling."""
    res = analyze_competitor_details.invoke({"store_name": "Bespoke Koramangala Studio", "locality": "Koramangala, Bangalore"})
    assert "COMPETITIVE INTELLIGENCE PROFILE: Bespoke Koramangala Studio" in res
    assert "Unavailable" in res
    assert "1. VERIFIED FACTS" in res


def test_generate_competitor_report_tool():
    """Tests invocation of report generator tool."""
    report = generate_competitor_report.invoke({"locality": "Koramangala, Bangalore", "category": "All"})
    assert isinstance(report, str)
    assert "# AI-Powered Competitor Analysis Report" in report
    assert "Executive Summary" in report
    assert "Competitor Comparison Matrix" in report
    assert "Available Footfall Insights" in report
