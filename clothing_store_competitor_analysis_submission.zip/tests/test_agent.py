"""Unit tests for the Conversational AI Pipeline and memory management."""

import pytest
from agent.pipeline import CompetitorAnalysisPipeline
from agent.config import AppConfig


def test_pipeline_initialization_with_missing_keys():
    """Validates graceful degradation when no live LLM API keys are provided."""
    pipeline = CompetitorAnalysisPipeline()
    # When keys are absent, is_llm_active returns False, but pipeline is fully functional
    assert isinstance(pipeline, CompetitorAnalysisPipeline)


def test_pipeline_conversation_turn_and_memory():
    """Validates multi-turn conversational interaction and memory retention."""
    pipeline = CompetitorAnalysisPipeline()
    
    # Turn 1: General discovery
    resp1 = pipeline.run_query("List clothing competitors in Koramangala")
    assert len(resp1) > 0
    assert "Fabindia" in resp1 or "Manyavar" in resp1
    assert len(pipeline.chat_history) == 2  # user + assistant

    # Turn 2: Follow-up question about a specific store
    resp2 = pipeline.run_query("Tell me more about Fabindia")
    assert len(resp2) > 0
    assert "Fabindia" in resp2
    assert len(pipeline.chat_history) == 4  # 2 user + 2 assistant


def test_pipeline_report_generation_query():
    """Validates user query explicitly asking for a business report."""
    pipeline = CompetitorAnalysisPipeline()
    resp = pipeline.run_query("Can you generate a full report on Koramangala clothing competitors?")
    assert "Executive Summary" in resp
    assert "Competitor Comparison Matrix" in resp


def test_pipeline_empty_query():
    """Validates that empty inputs return a polite prompt rather than raising an exception."""
    pipeline = CompetitorAnalysisPipeline()
    resp = pipeline.run_query("   ")
    assert "Please provide a query" in resp


def test_credentials_status_dictionary():
    """Validates AppConfig credentials status reporting."""
    status = AppConfig.get_credentials_status()
    assert isinstance(status, dict)
    assert "TAVILY_API_KEY" in status
    assert "OPENAI_API_KEY" in status
    assert "GOOGLE_API_KEY" in status
    assert "GROQ_API_KEY" in status
