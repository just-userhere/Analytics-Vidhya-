"""Unit tests for the structured Competitor Intelligence Report generator."""

import pytest
from datetime import datetime
from agent.report_generator import CompetitorReportGenerator
from agent.search_service import CompetitorSearchService


def test_report_contains_all_mandatory_sections():
    """Validates that all required business report sections are present."""
    service = CompetitorSearchService()
    stores = service.get_curated_competitors()
    report = CompetitorReportGenerator.generate_report(
        competitors=stores,
        locality="Koramangala, Bangalore",
        category_filter="All"
    )

    # 1. Executive Summary
    assert "## 1. Executive Summary" in report
    # 2. Competitor Comparison Matrix
    assert "## 2. Competitor Comparison Matrix" in report
    # 3. Available Footfall Insights
    assert "## 3. Available Footfall Insights" in report
    # 4. Peak-Hour Analysis
    assert "## 4. Peak-Hour Analysis" in report
    # 5. Detailed Competitor Profiles
    assert "## 5. Detailed Competitor Profiles" in report
    # 6. Market Opportunities
    assert "## 6. Market Opportunities in Koramangala" in report
    # 7. Recommended Marketing Strategies
    assert "## 7. Recommended Marketing & Merchandising Strategies" in report
    # 8. Limitations & Data Caveats
    assert "## 8. Limitations & Data Caveats" in report
    # 9. Source links
    assert "## 9. Sourced Reference Links & Retrieval Log" in report


def test_report_table_structure_and_columns():
    """Validates table columns and markdown alignment in competitor comparison matrix."""
    service = CompetitorSearchService()
    stores = service.get_curated_competitors()
    report = CompetitorReportGenerator.generate_report(stores)

    assert "| Store Name | Specific Location | Clothing Category | Price Tier | Rating & Reviews | Reported Footfall | Peak Hours Status | Primary Source Link |" in report
    assert "| **Fabindia Experience Centre**" in report
    assert "| **Manyavar & Mohey**" in report
    assert "| **Rare Rabbit**" in report


def test_report_includes_source_links_and_dates():
    """Validates inclusion of clickable source links and current retrieval dates."""
    service = CompetitorSearchService()
    stores = service.get_curated_competitors()
    today_str = datetime.now().strftime("%Y-%m-%d")
    report = CompetitorReportGenerator.generate_report(stores, retrieval_date=today_str)

    assert today_str in report
    assert "https://www.fabindia.com" in report
    assert "https://www.manyavar.com" in report
    assert "https://thehouseofrare.com" in report
