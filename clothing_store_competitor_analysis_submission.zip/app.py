"""Streamlit Web Application for AI-Powered Clothing Store Competitor Analysis."""

import os
from datetime import datetime
import streamlit as st
from agent.config import AppConfig, DEFAULT_LOCALITY
from agent.pipeline import CompetitorAnalysisPipeline
from agent.search_service import CompetitorSearchService
from agent.report_generator import CompetitorReportGenerator
from agent.models import CompetitorInfo

# Page configuration
st.set_page_config(
    page_title="RetailPulse AI | Clothing Competitor Intelligence",
    page_icon="🛍️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom Styling
st.markdown("""
<style>
    /* Global Styles */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    /* Header hero styling */
    .hero-container {
        background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #312e81 100%);
        border-radius: 16px;
        padding: 28px 32px;
        color: white;
        margin-bottom: 24px;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.15), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .hero-title {
        font-size: 2.1rem;
        font-weight: 800;
        letter-spacing: -0.025em;
        margin-bottom: 8px;
        color: #ffffff;
    }
    
    .hero-subtitle {
        font-size: 1.05rem;
        color: #cbd5e1;
        max-width: 850px;
        line-height: 1.5;
    }
    
    .hero-badge {
        display: inline-block;
        background: rgba(99, 102, 241, 0.3);
        border: 1px solid rgba(165, 180, 252, 0.4);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        color: #e0e7ff;
        margin-bottom: 12px;
    }
    
    /* Metric Cards */
    .metric-card {
        background: #ffffff;
        border-radius: 12px;
        padding: 18px 20px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .metric-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
    }
    .metric-label {
        font-size: 0.85rem;
        color: #64748b;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    .metric-value {
        font-size: 1.6rem;
        font-weight: 700;
        color: #0f172a;
        margin: 4px 0;
    }
    .metric-sub {
        font-size: 0.8rem;
        color: #10b981;
        font-weight: 500;
    }
    .metric-sub.warning {
        color: #f59e0b;
    }

    /* Classification Badges */
    .badge-fact {
        background-color: #ecfdf5;
        color: #065f46;
        border: 1px solid #a7f3d0;
        padding: 3px 8px;
        border-radius: 6px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .badge-estimate {
        background-color: #eff6ff;
        color: #1e40af;
        border: 1px solid #bfdbfe;
        padding: 3px 8px;
        border-radius: 6px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .badge-inference {
        background-color: #fef3c7;
        color: #92400e;
        border: 1px solid #fde68a;
        padding: 3px 8px;
        border-radius: 6px;
        font-size: 0.75rem;
        font-weight: 600;
    }

    /* Footfall Policy Banner */
    .policy-banner {
        background-color: #f8fafc;
        border-left: 4px solid #6366f1;
        padding: 12px 18px;
        border-radius: 0 8px 8px 0;
        margin: 16px 0;
        font-size: 0.88rem;
        color: #334155;
    }
</style>
""", unsafe_allow_html=True)


# Initialize Session State
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "pipeline" not in st.session_state:
    st.session_state.pipeline = CompetitorAnalysisPipeline()
if "last_locality" not in st.session_state:
    st.session_state.last_locality = DEFAULT_LOCALITY
if "generated_report" not in st.session_state:
    st.session_state.generated_report = None


# Sidebar Navigation & Settings
with st.sidebar:
    st.markdown("### 🛍️ RetailPulse Settings")
    st.markdown("Configure target market locality and AI intelligence parameters.")

    # Target Locality
    locality = st.text_input(
        "📍 Target Locality",
        value=DEFAULT_LOCALITY,
        help="Specify the target retail hub (e.g., Koramangala, Bangalore)."
    )

    # Apparel Category Filter
    category_options = [
        "All",
        "Ethnic, Handloom & Wedding Wear",
        "Men's Premium & Smart Casuals",
        "Global Fast Fashion & Department Stores",
        "Youth Casualwear & Denim",
    ]
    selected_category = st.selectbox(
        "🏷️ Apparel Category",
        options=category_options,
        index=0,
    )
    mapped_category = "All" if selected_category == "All" else selected_category.split("&")[0].strip()

    st.markdown("---")
    st.markdown("### 🔑 API & Engine Status")
    
    # Check credentials
    cred_status = AppConfig.get_credentials_status()
    tavily_ok = cred_status["TAVILY_API_KEY"]
    llm_ok = AppConfig.has_any_llm_key()

    if tavily_ok:
        st.success("✅ Tavily Search API: Active")
    else:
        st.info("ℹ️ Tavily API: Missing (Using DDG & Verified Data Fallback)")

    if llm_ok:
        st.success(f"✅ LLM: Connected ({AppConfig.get_active_llm_provider().upper()})")
    else:
        st.info("ℹ️ LLM: Offline Analytical Engine (Deterministic ReAct)")

    with st.expander("⚙️ Override API Credentials"):
        tavily_input = st.text_input("Tavily API Key", type="password", value=os.getenv("TAVILY_API_KEY", ""))
        openai_input = st.text_input("OpenAI API Key", type="password", value=os.getenv("OPENAI_API_KEY", ""))
        google_input = st.text_input("Google / Gemini API Key", type="password", value=os.getenv("GOOGLE_API_KEY", ""))
        groq_input = st.text_input("Groq API Key", type="password", value=os.getenv("GROQ_API_KEY", ""))

        if st.button("Apply API Keys"):
            if tavily_input:
                os.environ["TAVILY_API_KEY"] = tavily_input
            if openai_input:
                os.environ["OPENAI_API_KEY"] = openai_input
            if google_input:
                os.environ["GOOGLE_API_KEY"] = google_input
            if groq_input:
                os.environ["GROQ_API_KEY"] = groq_input
            # Reinitialize pipeline
            st.session_state.pipeline = CompetitorAnalysisPipeline()
            st.rerun()

    st.markdown("---")
    if st.button("🗑️ Clear Chat History", use_container_width=True):
        st.session_state.chat_history = []
        st.session_state.pipeline.chat_history = []
        st.rerun()


# Hero Header
st.markdown(f"""
<div class="hero-container">
    <div class="hero-badge">AI RETAIL COMPETITIVE INTELLIGENCE • BANGALORE</div>
    <div class="hero-title">Clothing Store Competitor Analysis Agent</div>
    <div class="hero-subtitle">
        Autonomous conversational AI pipeline evaluating apparel retail competitors in <b>{locality}</b>.
        Synthesizes verified store locations, ratings, category positioning, peak-hour review patterns,
        and strictly truthful footfall intelligence into actionable business strategy.
    </div>
</div>
""", unsafe_allow_html=True)


# Main Tabs
tab_matrix, tab_report, tab_chat, tab_policy = st.tabs([
    "📊 Competitor Matrix & Discovery",
    "📑 Executive Business Report",
    "💬 Conversational AI Agent",
    "🛡️ Truthfulness & Data Governance"
])


# -------------------------------------------------------------
# TAB 1: COMPETITOR MATRIX & DISCOVERY
# -------------------------------------------------------------
with tab_matrix:
    st.markdown("### 🏬 Verified Competitor Landscape")
    st.markdown(f"Analyzed apparel retail brands operating in **{locality}**.")

    competitors = st.session_state.pipeline.get_competitor_list(locality=locality, category=mapped_category)

    # Top KPI Metrics Row
    col_m1, col_m2, col_m3, col_m4 = st.columns(4)
    with col_m1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Stores Profiled</div>
            <div class="metric-value">{len(competitors)}</div>
            <div class="metric-sub">Active in {locality.split(',')[0]}</div>
        </div>
        """, unsafe_allow_html=True)
    with col_m2:
        avg_rating = round(sum(c.rating for c in competitors if c.rating) / len(competitors), 2) if competitors else 0.0
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Average Rating</div>
            <div class="metric-value">{avg_rating} ⭐</div>
            <div class="metric-sub">Google / Justdial Aggregated</div>
        </div>
        """, unsafe_allow_html=True)
    with col_m3:
        total_revs = sum(c.review_count for c in competitors if c.review_count)
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Total Public Reviews</div>
            <div class="metric-value">{total_revs:,}</div>
            <div class="metric-sub">Verified customer feedback</div>
        </div>
        """, unsafe_allow_html=True)
    with col_m4:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">In-Store Footfall Status</div>
            <div class="metric-value" style="font-size: 1.3rem; color: #d97706;">Unavailable</div>
            <div class="metric-sub warning">Zero Hallucination Enforced</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Competitor Comparison Table
    table_data = []
    for c in competitors:
        table_data.append({
            "Store Name": c.store_name,
            "Address / Street": c.address,
            "Category": c.clothing_category,
            "Price Tier": c.price_tier,
            "Rating": f"{c.rating} ⭐ ({c.review_count:,})" if c.rating else "N/A",
            "Reported Footfall": c.footfall_status,
            "Peak Hours": c.peak_hours_status,
            "Source URL": c.source_urls[0] if c.source_urls else "N/A"
        })
    st.dataframe(table_data, use_container_width=True)

    st.markdown("---")
    st.markdown("### 🔍 Store Deep-Dive & Three-Tier Epistemology")
    store_names = [c.store_name for c in competitors]
    selected_store_name = st.selectbox("Select a competitor to inspect evidentiary breakdown:", store_names)
    
    selected_store = next((c for c in competitors if c.store_name == selected_store_name), None)
    if selected_store:
        col_d1, col_d2 = st.columns([1, 1])
        with col_d1:
            st.markdown(f"#### 🏷️ **{selected_store.store_name}**")
            st.markdown(f"**Category:** {selected_store.clothing_category} | **Tier:** {selected_store.price_tier}")
            st.markdown(f"**Address:** {selected_store.address}")
            st.markdown(f"**Rating:** {selected_store.rating} / 5.0 ({selected_store.review_count:,} reviews via {selected_store.rating_source})")
            st.markdown(f"**Reported Footfall:** `{selected_store.reported_footfall}`")
            st.markdown(f"**Peak Hours:** `{selected_store.peak_hours}`")

        with col_d2:
            st.markdown("#### 🧩 **Epistemological Classification**")
            st.markdown("**1. Verified Facts:** <span class='badge-fact'>Publicly Confirmed</span>", unsafe_allow_html=True)
            for f in selected_store.verified_facts:
                st.markdown(f"- {f}")

            st.markdown("**2. Third-Party Estimates:** <span class='badge-estimate'>Aggregator Data</span>", unsafe_allow_html=True)
            for e in selected_store.third_party_estimates:
                st.markdown(f"- {e}")

            st.markdown("**3. Analytical Inferences:** <span class='badge-inference'>Expert Deduction</span>", unsafe_allow_html=True)
            for i in selected_store.analytical_inferences:
                st.markdown(f"- {i}")

        st.markdown(f"**Source Provenance:** " + ", ".join([f"[{u}]({u})" for u in selected_store.source_urls]))


# -------------------------------------------------------------
# TAB 2: EXECUTIVE BUSINESS REPORT
# -------------------------------------------------------------
with tab_report:
    st.markdown("### 📑 Strategic Intelligence Report")
    st.markdown("Comprehensive 8-section market intelligence analysis generated via LangChain tools.")

    col_btn1, col_btn2 = st.columns([1, 3])
    with col_btn1:
        if st.button("🔄 Generate Fresh Report", use_container_width=True):
            with st.spinner("Compiling multi-source competitor report..."):
                report = st.session_state.pipeline.generate_full_report(
                    locality=locality, category=mapped_category
                )
                st.session_state.generated_report = report

    if not st.session_state.generated_report:
        # Load from disk if available or generate on first load
        if os.path.exists("sample_report.md"):
            with open("sample_report.md", "r", encoding="utf-8") as f:
                st.session_state.generated_report = f.read()
        else:
            st.session_state.generated_report = st.session_state.pipeline.generate_full_report(
                locality=locality, category=mapped_category
            )

    # Render Report
    st.markdown(st.session_state.generated_report)

    # Download Buttons
    st.markdown("---")
    d_col1, d_col2 = st.columns(2)
    with d_col1:
        st.download_button(
            label="📥 Download Report (.md)",
            data=st.session_state.generated_report,
            file_name=f"clothing_competitor_report_{locality.split(',')[0].lower()}.md",
            mime="text/markdown",
            use_container_width=True,
        )
    with d_col2:
        st.download_button(
            label="📥 Download Report (.txt)",
            data=st.session_state.generated_report,
            file_name=f"clothing_competitor_report_{locality.split(',')[0].lower()}.txt",
            mime="text/plain",
            use_container_width=True,
        )


# -------------------------------------------------------------
# TAB 3: CONVERSATIONAL AI AGENT
# -------------------------------------------------------------
with tab_chat:
    st.markdown("### 💬 Conversational Competitor Analyst")
    st.markdown("Ask natural language questions about Koramangala clothing competitors. The agent leverages LangChain tools and maintains conversational memory for follow-up questions.")

    # Suggested Prompts
    st.markdown("**Suggested Questions:**")
    prompt_cols = st.columns(4)
    suggested_queries = [
        "What are the peak hours for Fabindia?",
        "Compare Manyavar and Rare Rabbit positioning",
        "Are exact footfall counts available for Zara?",
        "What marketing strategy can beat Westside?",
    ]
    
    clicked_prompt = None
    for idx, sq in enumerate(suggested_queries):
        with prompt_cols[idx]:
            if st.button(sq, key=f"sq_{idx}", use_container_width=True):
                clicked_prompt = sq

    # Render Chat History
    chat_container = st.container()
    with chat_container:
        for msg in st.session_state.chat_history:
            if msg["role"] == "user":
                with st.chat_message("user"):
                    st.write(msg["content"])
            else:
                with st.chat_message("assistant"):
                    st.markdown(msg["content"])

    # Chat Input
    user_input = st.chat_input("Ask a competitor analysis question...")
    query_to_run = clicked_prompt or user_input

    if query_to_run:
        # Display user message
        with st.chat_message("user"):
            st.write(query_to_run)
        
        # Run through pipeline
        with st.chat_message("assistant"):
            with st.spinner("Analyzing competitors using LangChain tools..."):
                response = st.session_state.pipeline.run_query(query_to_run)
                st.markdown(response)

        st.rerun()


# -------------------------------------------------------------
# TAB 4: TRUTHFULNESS & DATA GOVERNANCE
# -------------------------------------------------------------
with tab_policy:
    st.markdown("### 🛡️ Strict Footfall Truthfulness Policy")
    
    st.markdown("""
    <div class="policy-banner">
        <b>Zero-Hallucination Policy:</b> Our conversational AI strictly refuses to invent footfall numbers,
        turnstile counts, or daily visitor totals. When exact metrics are not published by official corporate sources,
        they are explicitly labeled as <code>Unavailable</code>.
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    #### 1. Why is In-Store Footfall Data Marked 'Unavailable'?
    - **Proprietary Sensor Networks:** Physical visitor counters (thermal cameras, overhead break-beam sensors, and in-store Wi-Fi sniffers) are confidential corporate assets. Neither Zara, Tata Trent (Westside), nor Fabindia publish raw store visitor turnstile telemetry publicly.
    - **Google Maps Popular Times Limitations:** Google Maps displays qualitative live busyness bars on its mobile app, but this real-time graph is **proprietary** and is not licensed or exposed via standard open web search APIs.
    - **Ethical AI Commitment:** Fabricating a plausible-sounding number (e.g., claiming "Manyavar sees 1,200 visitors on Saturday") is fraudulent in business consulting. We strictly flag it as `Unavailable (Not publicly reported)`.

    ---

    #### 2. The Three-Tier Epistemological Model
    Every piece of intelligence in our pipeline is sorted into one of three rigorous tiers:

    1. **Verified Facts:**
       - Registered legal store addresses and physical street corridors (80ft Road, 100ft Road, Hosur Road).
       - Officially published opening and closing hours.
       - Verified product category specialization and brand parentage (e.g., Westside owned by Trent / Tata Group).

    2. **Third-Party Estimates:**
       - Public aggregator ratings and review counts on Google Maps, Justdial, and mall directories.
       - Customer review mentions describing fitting room queues and billing delays during weekend rush hours.

    3. **Analytical Inferences:**
       - Proximity-based pedestrian traffic inferences (e.g., dining spillover from Koramangala 4th Block restaurants).
       - Mall-dependent dwell time effects versus high-street destination shopping dynamics.
    """)

    st.markdown("---")
    st.markdown(f"**Data Retrieval Timestamp:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`")
