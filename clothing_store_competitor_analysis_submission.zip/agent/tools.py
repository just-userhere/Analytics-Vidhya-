"""Custom LangChain tools for competitor discovery and intelligence analysis."""

import json
from datetime import datetime
from typing import Optional
from langchain_core.tools import tool
from agent.search_service import CompetitorSearchService
from agent.report_generator import CompetitorReportGenerator
from agent.models import CompetitorInfo

search_service = CompetitorSearchService()


@tool
def discover_clothing_competitors(locality: str = "Koramangala, Bangalore", category: str = "All") -> str:
    """
    Discovers clothing stores and apparel competitors in the specified locality.
    Collects store names, locations, clothing categories, available ratings, review counts,
    source URLs, reported footfall status, and peak hours.
    
    Args:
        locality: Target geographical area (e.g., 'Koramangala, Bangalore').
        category: Specific apparel category filter or 'All' (e.g., 'Ethnic', 'Fast Fashion', 'Menswear').
        
    Returns:
        JSON string containing verified competitor store profiles and public sources.
    """
    if not locality or not locality.strip():
        locality = "Koramangala, Bangalore"
    if not category or not category.strip():
        category = "All"

    stores = search_service.get_curated_competitors(locality=locality, category=category)
    
    # Also perform a web search query for additional live signals
    query = f"clothing apparel stores {category if category != 'All' else ''} in {locality}"
    web_results = search_service.search(query, max_results=3)
    
    output = {
        "locality": locality,
        "category_filter": category,
        "total_stores_found": len(stores),
        "data_retrieval_date": datetime.now().strftime("%Y-%m-%d"),
        "footfall_data_governance": "Strict Truthfulness: Physical sensor footfall counts are proprietary and marked 'Unavailable'",
        "stores": [s.to_dict() for s in stores],
        "supplementary_web_sources": [r.model_dump() for r in web_results]
    }
    return json.dumps(output, indent=2)


@tool
def analyze_competitor_details(store_name: str, locality: str = "Koramangala, Bangalore") -> str:
    """
    Performs deep-dive competitive analysis on a specific clothing store in the given locality.
    Strictly categorizes data into Verified Facts, Third-Party Estimates, and Analytical Inferences.
    Never fabricates footfall or visitor counts; marks unavailable data as 'Unavailable'.
    
    Args:
        store_name: Name of the clothing store (e.g., 'Fabindia', 'Manyavar', 'Westside', 'Rare Rabbit').
        locality: Locality where the store is located (e.g., 'Koramangala, Bangalore').
        
    Returns:
        Detailed structured analysis text with facts, estimates, inferences, and sources.
    """
    if not store_name or not store_name.strip():
        return "Error: Please provide a valid store_name to analyze."

    s_name_clean = store_name.strip().lower()
    stores = search_service.get_curated_competitors(locality=locality, category="All")
    
    matched: Optional[CompetitorInfo] = None
    for s in stores:
        if s_name_clean in s.store_name.lower() or s.store_name.lower() in s_name_clean:
            matched = s
            break
            
    # If not found in curated stores, build a dynamic profile from web search
    if not matched:
        web_results = search_service.search(f"{store_name} clothing store {locality}", max_results=4)
        sources = [r.url for r in web_results if r.url]
        snippets = " ".join([r.snippet for r in web_results])
        matched = CompetitorInfo(
            store_name=store_name,
            locality=locality,
            address=f"{store_name}, {locality}",
            clothing_category="Apparel Retail",
            price_tier="Mid-Range",
            rating=None,
            review_count=None,
            rating_source="Web Search Aggregator",
            reported_footfall="Unavailable (Exact visitor statistics not publicly disclosed)",
            footfall_status="Unavailable",
            peak_hours="Unavailable (Hourly visitor distribution not publicly reported)",
            peak_hours_status="Unavailable",
            verified_facts=[
                f"Retail store presence identified in {locality}.",
                f"Web search summary: {snippets[:200]}..." if snippets else "Basic online listing present."
            ],
            third_party_estimates=[
                "Third-party review counts and numerical ratings unavailable or inconclusive from public index."
            ],
            analytical_inferences=[
                f"Likely targets general consumer segment shopping in {locality} commercial district."
            ],
            source_urls=sources or ["https://www.google.com/maps"],
        )

    # Format into rigorous epistemological output
    facts = "\n".join([f"- [VERIFIED FACT] {f}" for f in matched.verified_facts])
    estimates = "\n".join([f"- [THIRD-PARTY ESTIMATE] {e}" for e in matched.third_party_estimates])
    inferences = "\n".join([f"- [ANALYTICAL INFERENCE] {i}" for i in matched.analytical_inferences])
    sources_str = ", ".join(matched.source_urls) if matched.source_urls else "Public web directory"

    analysis_text = f"""
COMPETITIVE INTELLIGENCE PROFILE: {matched.store_name}
Target Locality: {matched.locality}
Physical Address: {matched.address}
Clothing Category & Positioning: {matched.clothing_category} ({matched.price_tier})
Public Rating: {matched.rating or 'N/A'} / 5.0 ({matched.review_count or 0} reviews via {matched.rating_source})
Reported Footfall: {matched.reported_footfall} [Status: {matched.footfall_status}]
Observed Peak Hours: {matched.peak_hours} [Status: {matched.peak_hours_status}]

--- EPISTEMOLOGICAL BREAKDOWN ---
1. VERIFIED FACTS:
{facts}

2. THIRD-PARTY ESTIMATES:
{estimates}

3. ANALYTICAL INFERENCES:
{inferences}

--- PROVENANCE ---
Source Links: {sources_str}
Retrieval Date: {matched.retrieval_date}
Data Integrity: Exact footfall counts were not fabricated; unavailable metrics are explicitly labeled.
"""
    return analysis_text.strip()


@tool
def generate_competitor_report(locality: str = "Koramangala, Bangalore", category: str = "All") -> str:
    """
    Generates a full 8-section structured business intelligence report for clothing competitors in the locality.
    Contains: Executive Summary, Competitor Comparison, Available Footfall Insights, Peak-Hour Analysis,
    Market Opportunities, Recommended Marketing Strategies, Limitations & Data Caveats, and Sourced References.
    
    Args:
        locality: Locality to report on (e.g., 'Koramangala, Bangalore').
        category: Category filter or 'All'.
        
    Returns:
        Complete Markdown business intelligence report.
    """
    stores = search_service.get_curated_competitors(locality=locality, category=category)
    return CompetitorReportGenerator.generate_report(competitors=stores, locality=locality, category_filter=category)


ALL_TOOLS = [discover_clothing_competitors, analyze_competitor_details, generate_competitor_report]
