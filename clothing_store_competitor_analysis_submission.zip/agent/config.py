"""Configuration and environment management for the Competitor Analysis Agent."""

import os
from typing import Optional, Dict, Any
from dotenv import load_dotenv

# Load environment variables from .env file if available
load_dotenv()

DEFAULT_LOCALITY = "Koramangala, Bangalore"
DEFAULT_CATEGORY = "All"

class AppConfig:
    """Manages application settings, API keys, and model parameters."""

    @staticmethod
    def get_tavily_api_key() -> Optional[str]:
        return os.getenv("TAVILY_API_KEY") or None

    @staticmethod
    def get_openai_api_key() -> Optional[str]:
        return os.getenv("OPENAI_API_KEY") or None

    @staticmethod
    def get_google_api_key() -> Optional[str]:
        return os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY") or None

    @staticmethod
    def get_groq_api_key() -> Optional[str]:
        return os.getenv("GROQ_API_KEY") or None

    @classmethod
    def get_credentials_status(cls) -> Dict[str, bool]:
        """Returns the presence status of key environment variables."""
        return {
            "TAVILY_API_KEY": bool(cls.get_tavily_api_key()),
            "OPENAI_API_KEY": bool(cls.get_openai_api_key()),
            "GOOGLE_API_KEY": bool(cls.get_google_api_key()),
            "GROQ_API_KEY": bool(cls.get_groq_api_key()),
        }

    @classmethod
    def has_any_llm_key(cls) -> bool:
        return any([
            cls.get_openai_api_key(),
            cls.get_google_api_key(),
            cls.get_groq_api_key(),
        ])

    @classmethod
    def get_active_llm_provider(cls) -> Optional[str]:
        """Detects the first available LLM provider based on set environment variables."""
        if cls.get_openai_api_key():
            return "openai"
        if cls.get_google_api_key():
            return "google"
        if cls.get_groq_api_key():
            return "groq"
        return None


def get_llm(
    provider: Optional[str] = None,
    model_name: Optional[str] = None,
    temperature: float = 0.2,
    api_key_override: Optional[str] = None,
) -> Any:
    """
    Factory function to instantiate an LLM based on available credentials.
    Returns None if no LLM credentials are provided, allowing graceful degradation.
    """
    chosen_provider = provider or AppConfig.get_active_llm_provider()

    # 1. OpenAI
    if chosen_provider == "openai" or (api_key_override and provider == "openai"):
        key = api_key_override or AppConfig.get_openai_api_key()
        if key:
            from langchain_openai import ChatOpenAI
            return ChatOpenAI(
                model=model_name or "gpt-4o-mini",
                api_key=key,
                temperature=temperature,
            )

    # 2. Google Gemini
    if chosen_provider in ["google", "gemini"] or (api_key_override and provider in ["google", "gemini"]):
        key = api_key_override or AppConfig.get_google_api_key()
        if key:
            from langchain_google_genai import ChatGoogleGenerativeAI
            return ChatGoogleGenerativeAI(
                model=model_name or "gemini-1.5-flash",
                google_api_key=key,
                temperature=temperature,
            )

    # 3. Groq
    if chosen_provider == "groq" or (api_key_override and provider == "groq"):
        key = api_key_override or AppConfig.get_groq_api_key()
        if key:
            from langchain_groq import ChatGroq
            return ChatGroq(
                model_name=model_name or "llama-3.3-70b-versatile",
                groq_api_key=key,
                temperature=temperature,
            )

    # If specific provider wasn't found, try auto-detecting any available
    if not chosen_provider:
        if AppConfig.get_openai_api_key():
            from langchain_openai import ChatOpenAI
            return ChatOpenAI(model="gpt-4o-mini", api_key=AppConfig.get_openai_api_key(), temperature=temperature)
        if AppConfig.get_google_api_key():
            from langchain_google_genai import ChatGoogleGenerativeAI
            return ChatGoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=AppConfig.get_google_api_key(), temperature=temperature)
        if AppConfig.get_groq_api_key():
            from langchain_groq import ChatGroq
            return ChatGroq(model_name="llama-3.3-70b-versatile", groq_api_key=AppConfig.get_groq_api_key(), temperature=temperature)

    return None
