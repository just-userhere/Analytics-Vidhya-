"""Data models and schemas for Competitor Intelligence."""

from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class SearchResult(BaseModel):
    """Schema for individual web search results."""
    title: str
    url: str
    snippet: str
    retrieval_date: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d"))
    source_engine: str = "Tavily"


class CompetitorInfo(BaseModel):
    """
    Structured profile of a competitor clothing store.
    Strictly differentiates between Verified Facts, Third-Party Estimates, and Analytical Inferences.
    Enforces truthfulness: footfall numbers are NEVER fabricated.
    """
    store_name: str
    locality: str = "Koramangala, Bangalore"
    address: str = "Address not publicly listed"
    clothing_category: str = "General Apparel"
    price_tier: str = "Mid-Range"  # Budget, Mid-Range, Premium, Luxury
    rating: Optional[float] = None
    review_count: Optional[int] = None
    rating_source: str = "Public review aggregator"
    
    # Strict Footfall & Peak-Hour Policy
    reported_footfall: str = "Unavailable (Physical in-store sensor data is not publicly published)"
    footfall_status: str = "Unavailable"
    
    peak_hours: str = "Evenings (6:00 PM - 9:00 PM) and Weekends based on customer reviews; exact hourly counts Unavailable"
    peak_hours_status: str = "Estimated from customer review patterns"  # or "Unavailable"
    
    # Three-Tier Epistemological Categorization
    verified_facts: List[str] = Field(default_factory=list)
    third_party_estimates: List[str] = Field(default_factory=list)
    analytical_inferences: List[str] = Field(default_factory=list)
    
    source_urls: List[str] = Field(default_factory=list)
    retrieval_date: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d"))

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump()


class LocalityMarketAnalysis(BaseModel):
    """Summary analysis of the entire locality clothing retail market."""
    locality: str
    total_competitors_analyzed: int
    categories_present: List[str]
    competitors: List[CompetitorInfo]
    market_gaps: List[str]
    retrieval_date: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d"))
